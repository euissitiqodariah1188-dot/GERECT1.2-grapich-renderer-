/* =====================================================================
 * GERECT 1.2 - Mesh Builders (procedural primitives)
 * All builders allocate exactly once from the supplied GerMemPool.
 * Called at layout-creation time only, never inside the render loop.
 * =====================================================================
 */
#include "ger3d/ger3d.h"

static GerVertex MakeVertex(float px, float py, float pz,
                             float nx, float ny, float nz,
                             float u, float v, GerColor color) {
    GerVertex vert;
    vert.position = gerVec3Make(px, py, pz);
    vert.normal = gerVec3Make(nx, ny, nz);
    vert.uv = (GerVec2){ u, v };
    vert.color = color;
    return vert;
}

GerResult gerMeshBuildLine(GerMesh *mesh, GerMemPool *pool, GerVec3 a, GerVec3 b) {
    if (!mesh || !pool) return GER_ERR_NULLPTR;

    mesh->vertices = (GerVertex *)gerMemPoolAlloc(pool, sizeof(GerVertex) * 2);
    mesh->indices  = (uint32_t *)gerMemPoolAlloc(pool, sizeof(uint32_t) * 2);
    if (!mesh->vertices || !mesh->indices) return GER_ERR_OUT_OF_MEMORY;

    GerVec3 dir = gerVec3Normalize(gerVec3Sub(b, a));
    mesh->vertices[0] = MakeVertex(a.x, a.y, a.z, dir.x, dir.y, dir.z, 0.0f, 0.0f, GER_COLOR_RGB(255,255,255));
    mesh->vertices[1] = MakeVertex(b.x, b.y, b.z, dir.x, dir.y, dir.z, 1.0f, 1.0f, GER_COLOR_RGB(255,255,255));
    mesh->indices[0] = 0;
    mesh->indices[1] = 1;
    mesh->vertexCount = 2;
    mesh->indexCount = 2; /* index count of 2 signals "line list" to the rasterizer */
    return GER_OK;
}

GerResult gerMeshBuildCube(GerMesh *mesh, GerMemPool *pool, float sx, float sy, float sz) {
    if (!mesh || !pool) return GER_ERR_NULLPTR;

    float hx = sx * 0.5f, hy = sy * 0.5f, hz = sz * 0.5f;
    mesh->vertices = (GerVertex *)gerMemPoolAlloc(pool, sizeof(GerVertex) * 24);
    mesh->indices  = (uint32_t *)gerMemPoolAlloc(pool, sizeof(uint32_t) * 36);
    if (!mesh->vertices || !mesh->indices) return GER_ERR_OUT_OF_MEMORY;

    GerColor white = GER_COLOR_RGB(255,255,255);
    int vi = 0;

    /* +Z face */
    mesh->vertices[vi++] = MakeVertex(-hx,-hy, hz, 0,0,1, 0,1, white);
    mesh->vertices[vi++] = MakeVertex( hx,-hy, hz, 0,0,1, 1,1, white);
    mesh->vertices[vi++] = MakeVertex( hx, hy, hz, 0,0,1, 1,0, white);
    mesh->vertices[vi++] = MakeVertex(-hx, hy, hz, 0,0,1, 0,0, white);
    /* -Z face */
    mesh->vertices[vi++] = MakeVertex( hx,-hy,-hz, 0,0,-1, 0,1, white);
    mesh->vertices[vi++] = MakeVertex(-hx,-hy,-hz, 0,0,-1, 1,1, white);
    mesh->vertices[vi++] = MakeVertex(-hx, hy,-hz, 0,0,-1, 1,0, white);
    mesh->vertices[vi++] = MakeVertex( hx, hy,-hz, 0,0,-1, 0,0, white);
    /* +X face */
    mesh->vertices[vi++] = MakeVertex(hx,-hy, hz, 1,0,0, 0,1, white);
    mesh->vertices[vi++] = MakeVertex(hx,-hy,-hz, 1,0,0, 1,1, white);
    mesh->vertices[vi++] = MakeVertex(hx, hy,-hz, 1,0,0, 1,0, white);
    mesh->vertices[vi++] = MakeVertex(hx, hy, hz, 1,0,0, 0,0, white);
    /* -X face */
    mesh->vertices[vi++] = MakeVertex(-hx,-hy,-hz, -1,0,0, 0,1, white);
    mesh->vertices[vi++] = MakeVertex(-hx,-hy, hz, -1,0,0, 1,1, white);
    mesh->vertices[vi++] = MakeVertex(-hx, hy, hz, -1,0,0, 1,0, white);
    mesh->vertices[vi++] = MakeVertex(-hx, hy,-hz, -1,0,0, 0,0, white);
    /* +Y face */
    mesh->vertices[vi++] = MakeVertex(-hx, hy, hz, 0,1,0, 0,1, white);
    mesh->vertices[vi++] = MakeVertex( hx, hy, hz, 0,1,0, 1,1, white);
    mesh->vertices[vi++] = MakeVertex( hx, hy,-hz, 0,1,0, 1,0, white);
    mesh->vertices[vi++] = MakeVertex(-hx, hy,-hz, 0,1,0, 0,0, white);
    /* -Y face */
    mesh->vertices[vi++] = MakeVertex(-hx,-hy,-hz, 0,-1,0, 0,1, white);
    mesh->vertices[vi++] = MakeVertex( hx,-hy,-hz, 0,-1,0, 1,1, white);
    mesh->vertices[vi++] = MakeVertex( hx,-hy, hz, 0,-1,0, 1,0, white);
    mesh->vertices[vi++] = MakeVertex(-hx,-hy, hz, 0,-1,0, 0,0, white);

    int ii = 0, face;
    for (face = 0; face < 6; face++) {
        uint32_t base = (uint32_t)(face * 4);
        mesh->indices[ii++] = base + 0;
        mesh->indices[ii++] = base + 1;
        mesh->indices[ii++] = base + 2;
        mesh->indices[ii++] = base + 0;
        mesh->indices[ii++] = base + 2;
        mesh->indices[ii++] = base + 3;
    }

    mesh->vertexCount = vi;
    mesh->indexCount = ii;
    return GER_OK;
}

GerResult gerMeshBuildPlane(GerMesh *mesh, GerMemPool *pool, float sizeX, float sizeZ, int subdivisions) {
    if (!mesh || !pool) return GER_ERR_NULLPTR;
    if (subdivisions < 1) subdivisions = 1;

    int gridSize = subdivisions + 1;
    int vertexCount = gridSize * gridSize;
    int quadCount = subdivisions * subdivisions;
    int indexCount = quadCount * 6;

    if (vertexCount > GER_MESH_MAX_VERTICES || indexCount > GER_MESH_MAX_INDICES) {
        return GER_ERR_LIMIT_REACHED;
    }

    mesh->vertices = (GerVertex *)gerMemPoolAlloc(pool, sizeof(GerVertex) * (size_t)vertexCount);
    mesh->indices  = (uint32_t *)gerMemPoolAlloc(pool, sizeof(uint32_t) * (size_t)indexCount);
    if (!mesh->vertices || !mesh->indices) return GER_ERR_OUT_OF_MEMORY;

    GerColor white = GER_COLOR_RGB(255,255,255);
    int x, z, vi = 0;
    for (z = 0; z < gridSize; z++) {
        for (x = 0; x < gridSize; x++) {
            float u = (float)x / (float)subdivisions;
            float v = (float)z / (float)subdivisions;
            float px = (u - 0.5f) * sizeX;
            float pz = (v - 0.5f) * sizeZ;
            mesh->vertices[vi++] = MakeVertex(px, 0.0f, pz, 0, 1, 0, u, v, white);
        }
    }

    int ii = 0;
    for (z = 0; z < subdivisions; z++) {
        for (x = 0; x < subdivisions; x++) {
            uint32_t i0 = (uint32_t)(z * gridSize + x);
            uint32_t i1 = i0 + 1;
            uint32_t i2 = (uint32_t)((z + 1) * gridSize + x);
            uint32_t i3 = i2 + 1;
            mesh->indices[ii++] = i0;
            mesh->indices[ii++] = i2;
            mesh->indices[ii++] = i1;
            mesh->indices[ii++] = i1;
            mesh->indices[ii++] = i2;
            mesh->indices[ii++] = i3;
        }
    }

    mesh->vertexCount = vi;
    mesh->indexCount = ii;
    return GER_OK;
}

GerResult gerMeshBuildSphere(GerMesh *mesh, GerMemPool *pool, float radius, int rings, int segments) {
    if (!mesh || !pool) return GER_ERR_NULLPTR;
    if (rings < 2) rings = 2;
    if (segments < 3) segments = 3;

    int vertexCount = (rings + 1) * (segments + 1);
    int indexCount = rings * segments * 6;

    if (vertexCount > GER_MESH_MAX_VERTICES || indexCount > GER_MESH_MAX_INDICES) {
        return GER_ERR_LIMIT_REACHED;
    }

    mesh->vertices = (GerVertex *)gerMemPoolAlloc(pool, sizeof(GerVertex) * (size_t)vertexCount);
    mesh->indices  = (uint32_t *)gerMemPoolAlloc(pool, sizeof(uint32_t) * (size_t)indexCount);
    if (!mesh->vertices || !mesh->indices) return GER_ERR_OUT_OF_MEMORY;

    GerColor white = GER_COLOR_RGB(255,255,255);
    int ring, seg, vi = 0;
    for (ring = 0; ring <= rings; ring++) {
        float v = (float)ring / (float)rings;
        float theta = v * (float)GER_PI; /* 0..pi */
        float sinTheta = sinf(theta), cosTheta = cosf(theta);

        for (seg = 0; seg <= segments; seg++) {
            float u = (float)seg / (float)segments;
            float phi = u * 2.0f * (float)GER_PI;
            float sinPhi = sinf(phi), cosPhi = cosf(phi);

            float nx = sinTheta * cosPhi;
            float ny = cosTheta;
            float nz = sinTheta * sinPhi;

            mesh->vertices[vi++] = MakeVertex(
                radius * nx, radius * ny, radius * nz,
                nx, ny, nz, u, v, white
            );
        }
    }

    int ii = 0;
    int stride = segments + 1;
    for (ring = 0; ring < rings; ring++) {
        for (seg = 0; seg < segments; seg++) {
            uint32_t i0 = (uint32_t)(ring * stride + seg);
            uint32_t i1 = i0 + 1;
            uint32_t i2 = (uint32_t)((ring + 1) * stride + seg);
            uint32_t i3 = i2 + 1;

            mesh->indices[ii++] = i0;
            mesh->indices[ii++] = i2;
            mesh->indices[ii++] = i1;
            mesh->indices[ii++] = i1;
            mesh->indices[ii++] = i2;
            mesh->indices[ii++] = i3;
        }
    }

    mesh->vertexCount = vi;
    mesh->indexCount = ii;
    return GER_OK;
}

GerResult gerMeshBuildPyramid(GerMesh *mesh, GerMemPool *pool, float baseSize, float height) {
    if (!mesh || !pool) return GER_ERR_NULLPTR;

    float h = baseSize * 0.5f;
    mesh->vertices = (GerVertex *)gerMemPoolAlloc(pool, sizeof(GerVertex) * 16);
    mesh->indices  = (uint32_t *)gerMemPoolAlloc(pool, sizeof(uint32_t) * 18);
    if (!mesh->vertices || !mesh->indices) return GER_ERR_OUT_OF_MEMORY;

    GerColor white = GER_COLOR_RGB(255,255,255);
    GerVec3 apex = gerVec3Make(0.0f, height, 0.0f);
    GerVec3 base[4] = {
        gerVec3Make(-h, 0.0f, -h),
        gerVec3Make( h, 0.0f, -h),
        gerVec3Make( h, 0.0f,  h),
        gerVec3Make(-h, 0.0f,  h)
    };

    int vi = 0, ii = 0, i;

    /* 4 triangular side faces, each with its own normal */
    for (i = 0; i < 4; i++) {
        GerVec3 p0 = base[i];
        GerVec3 p1 = base[(i + 1) % 4];
        GerVec3 edge1 = gerVec3Sub(p1, p0);
        GerVec3 edge2 = gerVec3Sub(apex, p0);
        GerVec3 normal = gerVec3Normalize(gerVec3Cross(edge1, edge2));

        uint32_t baseIdx = (uint32_t)vi;
        mesh->vertices[vi++] = MakeVertex(p0.x, p0.y, p0.z, normal.x, normal.y, normal.z, 0, 1, white);
        mesh->vertices[vi++] = MakeVertex(p1.x, p1.y, p1.z, normal.x, normal.y, normal.z, 1, 1, white);
        mesh->vertices[vi++] = MakeVertex(apex.x, apex.y, apex.z, normal.x, normal.y, normal.z, 0.5f, 0, white);

        mesh->indices[ii++] = baseIdx + 0;
        mesh->indices[ii++] = baseIdx + 1;
        mesh->indices[ii++] = baseIdx + 2;
    }

    /* base quad (normal pointing down) */
    uint32_t baseQuadIdx = (uint32_t)vi;
    mesh->vertices[vi++] = MakeVertex(base[0].x, base[0].y, base[0].z, 0,-1,0, 0,1, white);
    mesh->vertices[vi++] = MakeVertex(base[1].x, base[1].y, base[1].z, 0,-1,0, 1,1, white);
    mesh->vertices[vi++] = MakeVertex(base[2].x, base[2].y, base[2].z, 0,-1,0, 1,0, white);
    mesh->vertices[vi++] = MakeVertex(base[3].x, base[3].y, base[3].z, 0,-1,0, 0,0, white);

    mesh->indices[ii++] = baseQuadIdx + 0;
    mesh->indices[ii++] = baseQuadIdx + 2;
    mesh->indices[ii++] = baseQuadIdx + 1;
    mesh->indices[ii++] = baseQuadIdx + 0;
    mesh->indices[ii++] = baseQuadIdx + 3;
    mesh->indices[ii++] = baseQuadIdx + 2;

    mesh->vertexCount = vi;
    mesh->indexCount = ii;
    return GER_OK;
}
