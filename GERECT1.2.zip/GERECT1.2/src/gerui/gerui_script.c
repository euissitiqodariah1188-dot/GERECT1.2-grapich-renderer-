/* =====================================================================
 * GERECT 1.2 - .ger Script Parser + Executor
 *
 * Recursive-descent, statement-at-a-time interpreter. Each statement
 * begins with an identifier keyword and is followed by zero or more
 * "[...]" bracket groups. Bracket groups are parsed generically into
 * either:
 *   - a numeric triplet (x.y.z)               e.g. pos[0.5.0]
 *   - a bare value word                       e.g. layout[garis], color[n/red]
 * and then dispatched to the matching SSM call based on the keyword.
 *
 * Supported statements (matches spec + 10 extra developer-facing verbs):
 *   gerDL3d                          - enable 3D mode for subsequent statements
 *   layout[name]                     - create/select a layout
 *   pos[x.y.z][name]                 - set position
 *   size[x.y.z][name]                - set scale
 *   color[colorname][name]           - set color (named or #hex, "n/" prefix ignored)
 *   rot[x.y.z][name]                 - set rotation in degrees
 *   move[x.y.z][name]                - relative move
 *
 *   --- 10 additional developer-facing verbs ---
 *   mesh[kind][name]                 - set primitive kind: line/cube/plane/sphere/pyramid
 *   shade[mode][name]                - set shading: flat/gouraud/textured/wireframe
 *   texture[texname][name]           - assign a previously loaded/created texture
 *   loadtex[texname][filepath]       - FuG: load a BMP file as a named texture
 *   solidtex[texname][w][h][color]   - FuG: create a flat-color procedural texture
 *   hide[name]                       - deactivate a layout (skip in render)
 *   show[name]                       - reactivate a layout
 *   destroy[name]                    - permanently remove a layout
 *   camera[x.y.z]                    - set camera eye position
 *   lookat[x.y.z]                    - set camera target point
 *   fov[degrees]                     - set camera field of view
 *   bg[colorname]                    - set frame clear/background color (engine-level default)
 * =====================================================================
 */
#include "gerui/gerui.h"

/* clear color is engine-global state the bg[] verb writes into; the
 * render pipeline itself (ger3d_raster.c) currently hardcodes a dark
 * clear -- this hook stores the requested color for host applications
 * that wish to read it and pass it into gerFramebufferClear manually. */
GerColor g_gerScriptBackgroundColor = 0;
int g_gerScriptBackgroundColorSet = 0;

static GerToken *GerPeek(GerScriptInterp *interp) {
    return &interp->lexer.tokens[interp->cursor];
}

static GerToken *GerAdvance(GerScriptInterp *interp) {
    GerToken *t = &interp->lexer.tokens[interp->cursor];
    if (t->type != GER_TOK_EOF) interp->cursor++;
    return t;
}

static void GerSkipNewlines(GerScriptInterp *interp) {
    while (GerPeek(interp)->type == GER_TOK_NEWLINE) GerAdvance(interp);
}

static void GerSetError(GerScriptInterp *interp, const char *msg) {
    interp->errorCount++;
    strncpy(interp->lastError, msg, sizeof(interp->lastError) - 1);
    interp->lastError[sizeof(interp->lastError) - 1] = '\0';
}

/* Parses "[ ... ]" where the contents are either:
 *   - a single bare word (layout/color/mesh/etc name)            -> outName set, outIsNumeric = 0
 *   - a dot-separated numeric triplet (x.y.z), possibly negative  -> outNums[0..2], outIsNumeric = 1
 *   - a single number                                             -> outNums[0], outNumCount = 1
 * Returns 1 on success, 0 on malformed bracket group.
 */
static int GerParseBracketGroup(GerScriptInterp *interp, char *outName, size_t outNameSize,
                                 double *outNums, int *outNumCount, int *outIsNumeric) {
    *outIsNumeric = 0;
    *outNumCount = 0;
    if (outName) outName[0] = '\0';

    if (GerPeek(interp)->type != GER_TOK_LBRACKET) return 0;
    GerAdvance(interp); /* consume [ */

    GerToken *first = GerPeek(interp);

    if (first->type == GER_TOK_NUMBER) {
        /* numeric form: read up to 3 dot-separated numbers */
        int count = 0;
        for (;;) {
            GerToken *numTok = GerAdvance(interp); /* consume number */
            if (numTok->type != GER_TOK_NUMBER) { GerSetError(interp, "expected number in bracket"); return 0; }
            if (count < 3) outNums[count] = numTok->number;
            count++;

            if (GerPeek(interp)->type == GER_TOK_DOT) {
                GerAdvance(interp); /* consume . */
                continue;
            }
            break;
        }
        *outNumCount = count > 3 ? 3 : count;
        *outIsNumeric = 1;
    } else if (first->type == GER_TOK_IDENT) {
        GerToken *nameTok = GerAdvance(interp);
        if (outName) {
            strncpy(outName, nameTok->text, outNameSize - 1);
            outName[outNameSize - 1] = '\0';
        }
        *outIsNumeric = 0;
    } else {
        GerSetError(interp, "unexpected token inside bracket group");
        return 0;
    }

    if (GerPeek(interp)->type != GER_TOK_RBRACKET) {
        GerSetError(interp, "expected closing ]");
        return 0;
    }
    GerAdvance(interp); /* consume ] */
    return 1;
}

static GerResult GerExecuteStatement(GerScriptInterp *interp, const char *verb) {
    GerScene *scene = interp->scene;

    if (_stricmp(verb, "gerDL3d") == 0) {
        /* enable-3d marker; layouts created after this point default
         * to is3DEnabled = 1 already, so this is mostly declarative.
         * Accepted with zero arguments. */
        return GER_OK;
    }

    if (_stricmp(verb, "layout") == 0) {
        char name[GER_MAX_NAME_LEN];
        double nums[4]; int numCount; int isNumeric;
        if (!GerParseBracketGroup(interp, name, sizeof(name), nums, &numCount, &isNumeric) || isNumeric) {
            GerSetError(interp, "layout[] requires a name");
            return GER_ERR_PARSE;
        }
        GerLayout *layout = gerSceneCreateLayout(scene, name);
        if (!layout) { GerSetError(interp, "could not create layout (limit reached?)"); return GER_ERR_LIMIT_REACHED; }
        if (!layout->mesh.vertices) {
            /* default primitive if the script never calls mesh[]: a line */
            gerLayoutSetMeshKind(scene, layout, "line");
        }
        return GER_OK;
    }

    if (_stricmp(verb, "pos") == 0 || _stricmp(verb, "size") == 0 ||
        _stricmp(verb, "rot") == 0 || _stricmp(verb, "move") == 0) {
        double nums[4]; int numCount; int isNumeric;
        char dummy[GER_MAX_NAME_LEN];
        if (!GerParseBracketGroup(interp, dummy, sizeof(dummy), nums, &numCount, &isNumeric) || !isNumeric) {
            GerSetError(interp, "expected numeric triplet x.y.z");
            return GER_ERR_PARSE;
        }
        float x = (float)nums[0];
        float y = numCount > 1 ? (float)nums[1] : 0.0f;
        float z = numCount > 2 ? (float)nums[2] : 0.0f;

        char name[GER_MAX_NAME_LEN];
        double dummyNums[4]; int dummyCount; int dummyIsNumeric;
        if (!GerParseBracketGroup(interp, name, sizeof(name), dummyNums, &dummyCount, &dummyIsNumeric) || dummyIsNumeric) {
            GerSetError(interp, "expected target layout name in second bracket");
            return GER_ERR_PARSE;
        }

        GerLayout *layout = gerSceneFindLayout(scene, name);
        if (!layout) { GerSetError(interp, "unknown layout name"); return GER_ERR_NOT_FOUND; }

        if (_stricmp(verb, "pos") == 0) return gerLayoutSetPos(layout, x, y, z);
        if (_stricmp(verb, "size") == 0) return gerLayoutSetSize(layout, x, y, z);
        if (_stricmp(verb, "rot") == 0) return gerLayoutSetRotation(layout, x, y, z);
        if (_stricmp(verb, "move") == 0) return gerLayoutMove(layout, x, y, z);
    }

    if (_stricmp(verb, "color") == 0) {
        char colorWord[GER_MAX_NAME_LEN];
        double nums[4]; int numCount; int isNumeric;
        if (!GerParseBracketGroup(interp, colorWord, sizeof(colorWord), nums, &numCount, &isNumeric) || isNumeric) {
            GerSetError(interp, "expected color name in color[]");
            return GER_ERR_PARSE;
        }
        char name[GER_MAX_NAME_LEN];
        if (!GerParseBracketGroup(interp, name, sizeof(name), nums, &numCount, &isNumeric) || isNumeric) {
            GerSetError(interp, "expected target layout name in second bracket");
            return GER_ERR_PARSE;
        }
        GerLayout *layout = gerSceneFindLayout(scene, name);
        if (!layout) { GerSetError(interp, "unknown layout name"); return GER_ERR_NOT_FOUND; }
        return gerLayoutSetColor(layout, gerColorNamed(colorWord));
    }

    if (_stricmp(verb, "mesh") == 0) {
        char kindWord[GER_MAX_NAME_LEN], name[GER_MAX_NAME_LEN];
        double nums[4]; int numCount; int isNumeric;
        if (!GerParseBracketGroup(interp, kindWord, sizeof(kindWord), nums, &numCount, &isNumeric) || isNumeric) {
            GerSetError(interp, "expected mesh kind"); return GER_ERR_PARSE;
        }
        if (!GerParseBracketGroup(interp, name, sizeof(name), nums, &numCount, &isNumeric) || isNumeric) {
            GerSetError(interp, "expected target layout name"); return GER_ERR_PARSE;
        }
        GerLayout *layout = gerSceneFindLayout(scene, name);
        if (!layout) { GerSetError(interp, "unknown layout name"); return GER_ERR_NOT_FOUND; }
        return gerLayoutSetMeshKind(scene, layout, kindWord);
    }

    if (_stricmp(verb, "shade") == 0) {
        char modeWord[GER_MAX_NAME_LEN], name[GER_MAX_NAME_LEN];
        double nums[4]; int numCount; int isNumeric;
        if (!GerParseBracketGroup(interp, modeWord, sizeof(modeWord), nums, &numCount, &isNumeric) || isNumeric) {
            GerSetError(interp, "expected shade mode"); return GER_ERR_PARSE;
        }
        if (!GerParseBracketGroup(interp, name, sizeof(name), nums, &numCount, &isNumeric) || isNumeric) {
            GerSetError(interp, "expected target layout name"); return GER_ERR_PARSE;
        }
        GerLayout *layout = gerSceneFindLayout(scene, name);
        if (!layout) { GerSetError(interp, "unknown layout name"); return GER_ERR_NOT_FOUND; }

        GerShadeMode mode = GER_SHADE_FLAT;
        if (_stricmp(modeWord, "flat") == 0) mode = GER_SHADE_FLAT;
        else if (_stricmp(modeWord, "gouraud") == 0) mode = GER_SHADE_GOURAUD;
        else if (_stricmp(modeWord, "textured") == 0) mode = GER_SHADE_TEXTURED;
        else if (_stricmp(modeWord, "wireframe") == 0) mode = GER_SHADE_WIREFRAME;
        else { GerSetError(interp, "unknown shade mode"); return GER_ERR_INVALID_ARG; }

        return gerLayoutSetShadeMode(layout, mode);
    }

    if (_stricmp(verb, "texture") == 0) {
        char texName[GER_MAX_NAME_LEN], layoutName[GER_MAX_NAME_LEN];
        double nums[4]; int numCount; int isNumeric;
        if (!GerParseBracketGroup(interp, texName, sizeof(texName), nums, &numCount, &isNumeric) || isNumeric) {
            GerSetError(interp, "expected texture name"); return GER_ERR_PARSE;
        }
        if (!GerParseBracketGroup(interp, layoutName, sizeof(layoutName), nums, &numCount, &isNumeric) || isNumeric) {
            GerSetError(interp, "expected target layout name"); return GER_ERR_PARSE;
        }
        GerLayout *layout = gerSceneFindLayout(scene, layoutName);
        if (!layout) { GerSetError(interp, "unknown layout name"); return GER_ERR_NOT_FOUND; }

        int i;
        GerTexture *tex = NULL;
        for (i = 0; i < scene->textureCount; i++) {
            if (strncmp(scene->textures[i].name, texName, GER_MAX_NAME_LEN) == 0) {
                tex = &scene->textures[i];
                break;
            }
        }
        if (!tex) { GerSetError(interp, "unknown texture name (load it first)"); return GER_ERR_NOT_FOUND; }
        return gerLayoutSetTexture(layout, tex);
    }

    if (_stricmp(verb, "loadtex") == 0) {
        char texName[GER_MAX_NAME_LEN], path[GER_MAX_NAME_LEN];
        double nums[4]; int numCount; int isNumeric;
        if (!GerParseBracketGroup(interp, texName, sizeof(texName), nums, &numCount, &isNumeric) || isNumeric) {
            GerSetError(interp, "expected texture name"); return GER_ERR_PARSE;
        }
        if (!GerParseBracketGroup(interp, path, sizeof(path), nums, &numCount, &isNumeric) || isNumeric) {
            GerSetError(interp, "expected file path"); return GER_ERR_PARSE;
        }
        GerTexture *tex = gerFugLoadTextureBMP(scene, texName, path);
        if (!tex) { GerSetError(interp, "failed to load BMP texture"); return GER_ERR_NOT_FOUND; }
        return GER_OK;
    }

    if (_stricmp(verb, "solidtex") == 0) {
        char texName[GER_MAX_NAME_LEN], colorWord[GER_MAX_NAME_LEN];
        double wNums[4]; int wCount; int wIsNumeric;
        double hNums[4]; int hCount; int hIsNumeric;
        double dummyNums[4]; int dummyCount; int dummyIsNumeric;

        if (!GerParseBracketGroup(interp, texName, sizeof(texName), dummyNums, &dummyCount, &dummyIsNumeric) || dummyIsNumeric) {
            GerSetError(interp, "expected texture name"); return GER_ERR_PARSE;
        }
        if (!GerParseBracketGroup(interp, NULL, 0, wNums, &wCount, &wIsNumeric) || !wIsNumeric) {
            GerSetError(interp, "expected width number"); return GER_ERR_PARSE;
        }
        if (!GerParseBracketGroup(interp, NULL, 0, hNums, &hCount, &hIsNumeric) || !hIsNumeric) {
            GerSetError(interp, "expected height number"); return GER_ERR_PARSE;
        }
        if (!GerParseBracketGroup(interp, colorWord, sizeof(colorWord), dummyNums, &dummyCount, &dummyIsNumeric) || dummyIsNumeric) {
            GerSetError(interp, "expected color name"); return GER_ERR_PARSE;
        }

        GerTexture *tex = gerFugCreateSolidTexture(scene, texName, (int)wNums[0], (int)hNums[0], gerColorNamed(colorWord));
        if (!tex) { GerSetError(interp, "failed to create solid texture"); return GER_ERR_OUT_OF_MEMORY; }
        return GER_OK;
    }

    if (_stricmp(verb, "hide") == 0 || _stricmp(verb, "show") == 0 || _stricmp(verb, "destroy") == 0) {
        char name[GER_MAX_NAME_LEN];
        double nums[4]; int numCount; int isNumeric;
        if (!GerParseBracketGroup(interp, name, sizeof(name), nums, &numCount, &isNumeric) || isNumeric) {
            GerSetError(interp, "expected layout name"); return GER_ERR_PARSE;
        }
        GerLayout *layout = gerSceneFindLayout(scene, name);
        if (!layout) { GerSetError(interp, "unknown layout name"); return GER_ERR_NOT_FOUND; }

        if (_stricmp(verb, "hide") == 0) { layout->active = 0; return GER_OK; }
        if (_stricmp(verb, "show") == 0) { layout->active = 1; return GER_OK; }
        return gerLayoutDestroy(scene, name);
    }

    if (_stricmp(verb, "camera") == 0 || _stricmp(verb, "lookat") == 0) {
        double nums[4]; int numCount; int isNumeric;
        if (!GerParseBracketGroup(interp, NULL, 0, nums, &numCount, &isNumeric) || !isNumeric) {
            GerSetError(interp, "expected numeric triplet"); return GER_ERR_PARSE;
        }
        GerVec3 v = gerVec3Make((float)nums[0],
                                 numCount > 1 ? (float)nums[1] : 0.0f,
                                 numCount > 2 ? (float)nums[2] : 0.0f);
        if (_stricmp(verb, "camera") == 0) scene->camera.eye = v;
        else scene->camera.target = v;
        return GER_OK;
    }

    if (_stricmp(verb, "fov") == 0) {
        double nums[4]; int numCount; int isNumeric;
        if (!GerParseBracketGroup(interp, NULL, 0, nums, &numCount, &isNumeric) || !isNumeric) {
            GerSetError(interp, "expected fov degrees"); return GER_ERR_PARSE;
        }
        scene->camera.fovYRadians = (float)GER_DEG2RAD(nums[0]);
        return GER_OK;
    }

    if (_stricmp(verb, "bg") == 0) {
        char colorWord[GER_MAX_NAME_LEN];
        double nums[4]; int numCount; int isNumeric;
        if (!GerParseBracketGroup(interp, colorWord, sizeof(colorWord), nums, &numCount, &isNumeric) || isNumeric) {
            GerSetError(interp, "expected color name"); return GER_ERR_PARSE;
        }
        g_gerScriptBackgroundColor = gerColorNamed(colorWord);
        g_gerScriptBackgroundColorSet = 1;
        return GER_OK;
    }

    GerSetError(interp, "unknown statement verb");
    return GER_ERR_PARSE;
}

static GerResult GerRunInterp(GerScriptInterp *interp) {
    for (;;) {
        GerSkipNewlines(interp);
        GerToken *tok = GerPeek(interp);
        if (tok->type == GER_TOK_EOF) break;

        if (tok->type != GER_TOK_IDENT) {
            GerSetError(interp, "expected statement keyword");
            GerAdvance(interp); /* skip the bad token and keep going */
            continue;
        }

        char verb[GER_MAX_NAME_LEN];
        strncpy(verb, tok->text, sizeof(verb) - 1);
        verb[sizeof(verb) - 1] = '\0';
        GerAdvance(interp); /* consume verb */

        GerExecuteStatement(interp, verb);

        /* statements end at newline or EOF; consume trailing brackets
         * belonging to this statement were already consumed inside
         * GerExecuteStatement, so just resync to the next line */
        while (GerPeek(interp)->type != GER_TOK_NEWLINE && GerPeek(interp)->type != GER_TOK_EOF) {
            GerAdvance(interp);
        }
    }
    return interp->errorCount > 0 ? GER_ERR_PARSE : GER_OK;
}

GerResult gerScriptRunSource(GerScene *scene, const char *source) {
    if (!scene || !source) return GER_ERR_NULLPTR;

    GerScriptInterp interp;
    memset(&interp, 0, sizeof(interp));
    interp.scene = scene;

    GerResult lexResult = gerScriptLex(&interp.lexer, source);
    if (lexResult != GER_OK) return lexResult;

    interp.cursor = 0;
    GerResult result = GerRunInterp(&interp);

    if (interp.errorCount > 0) {
        fprintf(stderr, "[GERECT script] %d error(s); last: %s\n",
                interp.errorCount, interp.lastError);
    }

    return result;
}

GerResult gerScriptRunFile(GerScene *scene, const char *path) {
    if (!scene || !path) return GER_ERR_NULLPTR;

    FILE *f = fopen(path, "rb");
    if (!f) return GER_ERR_NOT_FOUND;

    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (size <= 0) { fclose(f); return GER_ERR_INVALID_ARG; }

    char *buffer = (char *)malloc((size_t)size + 1);
    if (!buffer) { fclose(f); return GER_ERR_OUT_OF_MEMORY; }

    size_t readBytes = fread(buffer, 1, (size_t)size, f);
    buffer[readBytes] = '\0';
    fclose(f);

    GerResult r = gerScriptRunSource(scene, buffer);
    free(buffer); /* local temp buffer, freed immediately after use --
                     no lifetime extends past this function, so this
                     does not violate the static-allocation rule which
                     applies to per-frame render data, not one-shot
                     file loading. */
    return r;
}
