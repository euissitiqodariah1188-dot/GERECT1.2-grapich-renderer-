/* =====================================================================
 * GERECT 1.2 - Built-in Embedded Assets (gerbed/gerbed.h)
 *
 * Include header ini untuk mendapatkan mesh built-in yang sudah
 * ter-embed langsung ke binary -- tidak butuh file eksternal sama sekali.
 *
 * Asset tersedia:
 *   GER_EMBED_CUBE_OBJ   / GER_EMBED_CUBE_OBJ_SIZE
 *   GER_EMBED_SPHERE_OBJ / GER_EMBED_SPHERE_OBJ_SIZE
 *
 * Cara pakai (C):
 *   #include "gerbed/gerbed.h"
 *   GerLayout *box = gerFugLoadObjFromMemory(&scene, "box",
 *       GER_EMBED_CUBE_OBJ, GER_EMBED_CUBE_OBJ_SIZE,
 *       NULL, 0, NULL);
 *
 * Cara pakai (C++):
 *   #include "gerbed/gerbed.h"
 *   auto box = scene.loadObjFromMemory("box",
 *       GER_EMBED_CUBE_OBJ, GER_EMBED_CUBE_OBJ_SIZE);
 *
 * Untuk embed file kamu sendiri (OBJ/BMP/WAV):
 *   python tools/gerEmbed.py mymodel.obj
 *   -> menghasilkan mymodel_obj.h
 *   -> #include "mymodel_obj.h" lalu pakai GER_EMBED_MYMODEL_OBJ
 * ===================================================================== */
#ifndef GERBED_H
#define GERBED_H

#include "gerbed/gerbed_cube.h"
#include "gerbed/gerbed_sphere.h"

#endif /* GERBED_H */
