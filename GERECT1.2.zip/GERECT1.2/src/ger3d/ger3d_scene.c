/* =====================================================================
 * GERECT 1.2 - Scene Management (SSM: Sistem Scene/Mesh)
 * Layout creation, transform setters (pos/size/rot/move/color),
 * texture loading (FuG), scene lifecycle.
 * =====================================================================
 */
#include "ger3d/ger3d.h"

GerResult gerSceneInit(GerScene *scene, int width, int height, int threadCount) {
    if (!scene) return GER_ERR_NULLPTR;
    memset(scene, 0, sizeof(GerScene));

    /* Single static memory pool sized generously for mesh data across
     * the whole scene lifetime: GER_MAX_LAYOUTS layouts * worst-case
     * sphere mesh size, rounded up. Allocated once here. */
    size_t poolSize = (size_t)GER_MAX_LAYOUTS * (size_t)(GER_MESH_MAX_VERTICES / 64) * sizeof(GerVertex);
    if (poolSize < (size_t)64 * 1024 * 1024) poolSize = (size_t)64 * 1024 * 1024; /* floor 64MB */

    GerResult r = gerMemPoolInit(&scene->pool, poolSize);
    if (r != GER_OK) return r;

    r = gerFramebufferInit(&scene->framebuffer, width, height);
    if (r != GER_OK) {
        gerMemPoolDestroy(&scene->pool);
        return r;
    }

    gerCameraInit(&scene->camera);
    gerEffectsCompileAll(&scene->effects);
    gerFrmInit(&scene->frameTimer);

    scene->threadPool = gerPmtgCreate(threadCount);
    if (!scene->threadPool) {
        gerFramebufferDestroy(&scene->framebuffer);
        gerMemPoolDestroy(&scene->pool);
        return GER_ERR_THREAD;
    }

    InitializeCriticalSection(&scene->sceneLock);
    scene->layoutCount = 0;
    scene->textureCount = 0;

    return GER_OK;
}

void gerSceneDestroy(GerScene *scene) {
    if (!scene) return;

    if (scene->threadPool) {
        gerPmtgDestroy(scene->threadPool);
        scene->threadPool = NULL;
    }

    int i;
    for (i = 0; i < scene->textureCount; i++) {
        if (scene->textures[i].pixels) {
            VirtualFree(scene->textures[i].pixels, 0, MEM_RELEASE);
            scene->textures[i].pixels = NULL;
        }
    }

    gerFramebufferDestroy(&scene->framebuffer);
    gerMemPoolDestroy(&scene->pool);
    DeleteCriticalSection(&scene->sceneLock);

    memset(scene, 0, sizeof(GerScene));
}

GerLayout *gerSceneFindLayout(GerScene *scene, const char *name) {
    if (!scene || !name) return NULL;
    int i;
    for (i = 0; i < scene->layoutCount; i++) {
        if (scene->layouts[i].active && strncmp(scene->layouts[i].name, name, GER_MAX_NAME_LEN) == 0) {
            return &scene->layouts[i];
        }
    }
    return NULL;
}

GerLayout *gerSceneCreateLayout(GerScene *scene, const char *name) {
    if (!scene || !name) return NULL;

    GerLayout *existing = gerSceneFindLayout(scene, name);
    if (existing) return existing;

    if (scene->layoutCount >= GER_MAX_LAYOUT_OBJECTS) return NULL;

    EnterCriticalSection(&scene->sceneLock);
    GerLayout *layout = &scene->layouts[scene->layoutCount++];
    memset(layout, 0, sizeof(GerLayout));
    strncpy(layout->name, name, GER_MAX_NAME_LEN - 1);
    layout->position = gerVec3Make(0.0f, 0.0f, 0.0f);
    layout->rotationRad = gerVec3Make(0.0f, 0.0f, 0.0f);
    layout->scale = gerVec3Make(1.0f, 1.0f, 1.0f);
    layout->color = GER_COLOR_RGB(255, 255, 255);
    layout->shadeMode = GER_SHADE_FLAT;
    layout->texture = NULL;
    layout->active = 1;
    layout->is3DEnabled = 1; /* set true by gerDL3d at the script level */
    LeaveCriticalSection(&scene->sceneLock);

    return layout;
}

GerResult gerLayoutSetPos(GerLayout *layout, float x, float y, float z) {
    if (!layout) return GER_ERR_NULLPTR;
    layout->position = gerVec3Make(x, y, z);
    return GER_OK;
}

GerResult gerLayoutSetSize(GerLayout *layout, float x, float y, float z) {
    if (!layout) return GER_ERR_NULLPTR;
    layout->scale = gerVec3Make(x, y, z);
    return GER_OK;
}

GerResult gerLayoutSetColor(GerLayout *layout, GerColor color) {
    if (!layout) return GER_ERR_NULLPTR;
    layout->color = color;
    return GER_OK;
}

GerResult gerLayoutSetRotation(GerLayout *layout, float rx, float ry, float rz) {
    if (!layout) return GER_ERR_NULLPTR;
    layout->rotationRad = gerVec3Make(
        (float)GER_DEG2RAD(rx), (float)GER_DEG2RAD(ry), (float)GER_DEG2RAD(rz)
    );
    return GER_OK;
}

GerResult gerLayoutMove(GerLayout *layout, float dx, float dy, float dz) {
    if (!layout) return GER_ERR_NULLPTR;
    layout->position = gerVec3Add(layout->position, gerVec3Make(dx, dy, dz));
    return GER_OK;
}

GerResult gerLayoutSetShadeMode(GerLayout *layout, GerShadeMode mode) {
    if (!layout) return GER_ERR_NULLPTR;
    if (mode < 0 || mode >= GER_SHADE_COUNT) return GER_ERR_INVALID_ARG;
    layout->shadeMode = mode;
    return GER_OK;
}

GerResult gerLayoutSetTexture(GerLayout *layout, GerTexture *tex) {
    if (!layout) return GER_ERR_NULLPTR;
    layout->texture = tex;
    if (tex) layout->shadeMode = GER_SHADE_TEXTURED;
    return GER_OK;
}

GerResult gerLayoutSetMeshKind(GerScene *scene, GerLayout *layout, const char *kind) {
    if (!scene || !layout || !kind) return GER_ERR_NULLPTR;

    if (_stricmp(kind, "line") == 0) {
        return gerMeshBuildLine(&layout->mesh, &scene->pool,
                                 gerVec3Make(0,0,0), gerVec3Make(1,0,0));
    } else if (_stricmp(kind, "cube") == 0) {
        return gerMeshBuildCube(&layout->mesh, &scene->pool, 1.0f, 1.0f, 1.0f);
    } else if (_stricmp(kind, "plane") == 0) {
        return gerMeshBuildPlane(&layout->mesh, &scene->pool, 1.0f, 1.0f, 8);
    } else if (_stricmp(kind, "sphere") == 0) {
        return gerMeshBuildSphere(&layout->mesh, &scene->pool, 0.5f, 16, 16);
    } else if (_stricmp(kind, "pyramid") == 0) {
        return gerMeshBuildPyramid(&layout->mesh, &scene->pool, 1.0f, 1.0f);
    }

    return GER_ERR_INVALID_ARG;
}

GerResult gerLayoutDestroy(GerScene *scene, const char *name) {
    if (!scene || !name) return GER_ERR_NULLPTR;
    GerLayout *layout = gerSceneFindLayout(scene, name);
    if (!layout) return GER_ERR_NOT_FOUND;

    EnterCriticalSection(&scene->sceneLock);
    layout->active = 0; /* logical removal; mesh memory stays in the
                            pool (pool is reclaimed wholesale at scene
                            destroy, never per-object, by design) */
    LeaveCriticalSection(&scene->sceneLock);
    return GER_OK;
}

/* ---------------------------------------------------------------------
 * FuG: texture / asset loading. BMP loader implemented from scratch
 * (no external image library) so the SDK has zero extra dependencies
 * beyond Win32.
 * --------------------------------------------------------------------- */
#pragma pack(push, 1)
typedef struct GerBmpFileHeader {
    uint16_t type;
    uint32_t size;
    uint16_t reserved1;
    uint16_t reserved2;
    uint32_t offBits;
} GerBmpFileHeader;

typedef struct GerBmpInfoHeader {
    uint32_t size;
    int32_t  width;
    int32_t  height;
    uint16_t planes;
    uint16_t bitCount;
    uint32_t compression;
    uint32_t sizeImage;
    int32_t  xPelsPerMeter;
    int32_t  yPelsPerMeter;
    uint32_t clrUsed;
    uint32_t clrImportant;
} GerBmpInfoHeader;
#pragma pack(pop)

static GerTexture *GerAllocTextureSlot(GerScene *scene, const char *name) {
    if (scene->textureCount >= GER_MAX_TEXTURES) return NULL;
    GerTexture *tex = &scene->textures[scene->textureCount++];
    memset(tex, 0, sizeof(GerTexture));
    strncpy(tex->name, name, GER_MAX_NAME_LEN - 1);
    return tex;
}

GerTexture *gerFugLoadTextureBMP(GerScene *scene, const char *name, const char *bmpPath) {
    if (!scene || !name || !bmpPath) return NULL;

    FILE *f = fopen(bmpPath, "rb");
    if (!f) return NULL;

    GerBmpFileHeader fh;
    GerBmpInfoHeader ih;
    if (fread(&fh, sizeof(fh), 1, f) != 1 || fh.type != 0x4D42) { fclose(f); return NULL; }
    if (fread(&ih, sizeof(ih), 1, f) != 1) { fclose(f); return NULL; }
    if (ih.bitCount != 24 && ih.bitCount != 32) { fclose(f); return NULL; }

    int width = ih.width;
    int height = ih.height < 0 ? -ih.height : ih.height;
    int topDown = ih.height < 0;
    int bytesPerPixel = ih.bitCount / 8;
    int rowSize = ((width * bytesPerPixel + 3) / 4) * 4; /* BMP row padding */

    fseek(f, fh.offBits, SEEK_SET);

    size_t pixelBytes = (size_t)width * (size_t)height * sizeof(uint32_t);
    uint32_t *pixels = (uint32_t *)VirtualAlloc(NULL, pixelBytes,
                                                 MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!pixels) { fclose(f); return NULL; }

    uint8_t *rowBuf = (uint8_t *)malloc((size_t)rowSize);
    if (!rowBuf) { VirtualFree(pixels, 0, MEM_RELEASE); fclose(f); return NULL; }

    int y;
    for (y = 0; y < height; y++) {
        if (fread(rowBuf, 1, (size_t)rowSize, f) != (size_t)rowSize) {
            free(rowBuf);
            VirtualFree(pixels, 0, MEM_RELEASE);
            fclose(f);
            return NULL;
        }
        int destRow = topDown ? y : (height - 1 - y);
        int x;
        for (x = 0; x < width; x++) {
            uint8_t b = rowBuf[x * bytesPerPixel + 0];
            uint8_t g = rowBuf[x * bytesPerPixel + 1];
            uint8_t r = rowBuf[x * bytesPerPixel + 2];
            uint8_t a = (bytesPerPixel == 4) ? rowBuf[x * bytesPerPixel + 3] : 255;
            pixels[(size_t)destRow * width + x] = GER_COLOR_RGBA(r, g, b, a);
        }
    }

    free(rowBuf);
    fclose(f);

    GerTexture *tex = GerAllocTextureSlot(scene, name);
    if (!tex) { VirtualFree(pixels, 0, MEM_RELEASE); return NULL; }

    tex->pixels = pixels;
    tex->width = width;
    tex->height = height;
    tex->inUse = 1;
    return tex;
}

GerTexture *gerFugCreateSolidTexture(GerScene *scene, const char *name, int w, int h, GerColor color) {
    if (!scene || !name || w <= 0 || h <= 0) return NULL;

    size_t pixelBytes = (size_t)w * (size_t)h * sizeof(uint32_t);
    uint32_t *pixels = (uint32_t *)VirtualAlloc(NULL, pixelBytes,
                                                 MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!pixels) return NULL;

    int i;
    for (i = 0; i < w * h; i++) pixels[i] = color;

    GerTexture *tex = GerAllocTextureSlot(scene, name);
    if (!tex) { VirtualFree(pixels, 0, MEM_RELEASE); return NULL; }

    tex->pixels = pixels;
    tex->width = w;
    tex->height = h;
    tex->inUse = 1;
    return tex;
}
