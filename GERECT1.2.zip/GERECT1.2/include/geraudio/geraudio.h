/* =====================================================================
 * GERECT 1.2 - Audio Header (geraudio/geraudio.h)
 *
 * Sound playback via the Windows Multimedia API (winmm.lib), no
 * external audio library required. Two layers:
 *
 *   - gerAudioPlaySoundSimple(): fire-and-forget WAV playback via
 *     PlaySound(), good for quick one-shot SFX. Only one such sound
 *     can play at a time per call style (Win32 PlaySound replaces the
 *     previous one unless SND_ASYNC | SND_NOSTOP semantics are used --
 *     here we use independent MCI device aliases instead for proper
 *     overlapping playback, see below).
 *
 *   - GerSoundHandle / gerAudioLoad/Play/Stop(): MCI-based handles
 *     that support loading multiple distinct sounds (WAV or MP3) and
 *     playing several of them simultaneously (each gets its own MCI
 *     device alias), plus volume and looping control. This is the
 *     recommended API for games with more than one concurrent sound
 *     (footsteps + music + UI blips, etc).
 *
 * All MCI aliases are opened once at gerAudioLoad() time and closed
 * exactly once in gerAudioUnload()/gerAudioShutdownAll() -- no
 * per-frame device open/close churn, matching the engine's anti-leak
 * philosophy.
 * =====================================================================
 */
#ifndef GERAUDIO_H
#define GERAUDIO_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ger/ger.h"

#define GER_AUDIO_MAX_SOUNDS 64

typedef struct GerSoundHandle {
    char alias[GER_MAX_NAME_LEN]; /* unique MCI device alias for this sound */
    char path[260];
    int  loaded;
    int  looping;
} GerSoundHandle;

/* ----------------------------------------------------------------------
 * Simple one-shot playback (PlaySound wrapper). Good for short UI
 * blips where you don't need a persistent handle.
 * ---------------------------------------------------------------------- */
GER_API GerResult gerAudioPlaySoundSimple(const char *wavPath, int loop);
GER_API void       gerAudioStopSimple(void);

/* ----------------------------------------------------------------------
 * Handle-based playback (MCI). Supports WAV and MP3, overlapping
 * playback of multiple distinct sounds, volume, and looping.
 * ---------------------------------------------------------------------- */
GER_API GerResult gerAudioInit(void);   /* no-op currently, reserved for future mixer setup */
GER_API void       gerAudioShutdownAll(void); /* stops and closes every loaded sound handle */

/* Loads (opens an MCI alias for) a sound file. `name` is the handle's
 * lookup key (independent of the file path) so callers can refer to
 * it by a friendly identifier from script code. Returns GER_OK or an
 * error code; does not start playback. */
GER_API GerResult gerAudioLoad(GerSoundHandle *outHandles, int *handleCount,
                                const char *name, const char *filePath);

GER_API GerSoundHandle *gerAudioFind(GerSoundHandle *handles, int handleCount, const char *name);

GER_API GerResult gerAudioPlay(GerSoundHandle *handle, int loop);
GER_API GerResult gerAudioStop(GerSoundHandle *handle);
GER_API GerResult gerAudioPause(GerSoundHandle *handle);
GER_API GerResult gerAudioResume(GerSoundHandle *handle);
GER_API GerResult gerAudioSetVolume(GerSoundHandle *handle, float volume0to1);
GER_API GerResult gerAudioUnload(GerSoundHandle *handle); /* closes the MCI alias */

#ifdef __cplusplus
}
#endif

#endif /* GERAUDIO_H */
