/* =====================================================================
 * GERECT 1.2 - Collision Header (ger3d/gercollision.h)
 *
 * Lightweight AABB and sphere collision queries operating on
 * GerLayout world transforms. No broad-phase/spatial partitioning is
 * implemented (out of scope for this engine's size) -- all tests are
 * O(1) pairwise; callers loop over their own layout lists for
 * O(n^2) scene-wide checks, which is fine for the scene sizes this
 * engine targets (hundreds, not tens of thousands, of objects).
 *
 * Bounding volumes are derived from each layout's mesh vertex extents
 * (computed once when the mesh is built, cached on the layout) scaled
 * by the layout's current `scale` and offset by its current
 * `position`. Rotation is intentionally ignored for AABBs (the AABB
 * is recomputed as an axis-aligned box around the *unrotated* local
 * extents translated to world space) to keep this O(1) and
 * allocation-free; use sphere collision for rotation-invariant checks.
 * =====================================================================
 */
#ifndef GERCOLLISION_H
#define GERCOLLISION_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ger/ger.h"
#include "ger3d/ger3d.h"

typedef struct GerAABB {
    GerVec3 min;
    GerVec3 max;
} GerAABB;

typedef struct GerSphere {
    GerVec3 center;
    float   radius;
} GerSphere;

/* Computes the *local* (untransformed, mesh-space) AABB once from a
 * mesh's vertex positions. Call this right after building/loading a
 * mesh; the result should be cached (e.g. stored alongside the layout
 * by the host application) since it never changes unless the mesh
 * geometry itself changes. */
GER_API GerAABB gerMeshComputeLocalAABB(const GerMesh *mesh);

/* Transforms a local AABB into world space using the layout's current
 * position and scale (rotation ignored, see file header note). */
GER_API GerAABB gerLayoutGetWorldAABB(const GerLayout *layout, GerAABB localAABB);

/* Derives a bounding sphere from a layout's position, the local AABB's
 * extents, and the layout's scale (uses the largest scale axis times
 * the AABB's bounding radius, so the sphere always fully contains the
 * scaled mesh regardless of rotation). */
GER_API GerSphere gerLayoutGetWorldSphere(const GerLayout *layout, GerAABB localAABB);

/* ----------------------------------------------------------------------
 * Intersection tests
 * ---------------------------------------------------------------------- */
GER_API int   gerCollideAABBvsAABB(GerAABB a, GerAABB b);
GER_API int   gerCollideSphereVsSphere(GerSphere a, GerSphere b);
GER_API int   gerCollideAABBvsSphere(GerAABB box, GerSphere sphere);
GER_API int   gerCollidePointInAABB(GerVec3 point, GerAABB box);
GER_API int   gerCollidePointInSphere(GerVec3 point, GerSphere sphere);

/* Ray vs AABB (slab method). Returns 1 on hit and writes the entry
 * distance along the ray direction to outDistance (NULL-safe to skip).
 * `dir` need not be normalized; outDistance is in units of `dir`'s
 * own length if not normalized, so normalize dir for a true distance. */
GER_API int gerCollideRayVsAABB(GerVec3 origin, GerVec3 dir, GerAABB box, float *outDistance);

/* Ray vs sphere. Same distance convention as above. */
GER_API int gerCollideRayVsSphere(GerVec3 origin, GerVec3 dir, GerSphere sphere, float *outDistance);

#ifdef __cplusplus
}
#endif

#endif /* GERCOLLISION_H */
