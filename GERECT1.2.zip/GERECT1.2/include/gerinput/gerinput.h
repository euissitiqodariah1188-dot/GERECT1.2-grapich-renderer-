/* =====================================================================
 * GERECT 1.2 - Input Header (gerinput/gerinput.h)
 *
 * Keyboard + mouse state tracking, fed by Win32 messages forwarded
 * from GerWndProc (see gerui_window.c). All state lives in a single
 * fixed-size struct allocated once (embedded in GerWindow) -- no
 * dynamic allocation, no per-frame churn.
 *
 * Usage pattern (typical game loop):
 *
 *   while (gerWindowPollEvents(&win)) {
 *       gerInputBeginFrame(&win.input);   // promotes "just pressed" -> "held"
 *       gerWindowPollEvents(&win);        // already called above; messages
 *                                         // update win.input via WndProc
 *       if (gerInputKeyPressed(&win.input, GER_KEY_SPACE)) { ... }
 *       if (gerInputKeyHeld(&win.input, GER_KEY_W)) { move forward }
 *       GerVec2 mouse = gerInputGetMousePos(&win.input);
 *       ...
 *       gerSceneRenderFrame(&scene);
 *       gerWindowPresent(&win);
 *   }
 *
 * Note on ordering: call gerInputBeginFrame() once per frame BEFORE
 * gerWindowPollEvents() so that "pressed this frame" flags set by the
 * upcoming PeekMessage/DispatchMessage calls survive until your game
 * logic reads them, and are cleared at the start of the *next* frame.
 * =====================================================================
 */
#ifndef GERINPUT_H
#define GERINPUT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ger/ger.h"

/* ----------------------------------------------------------------------
 * Key codes: a curated subset mapped 1:1 from Win32 virtual-key codes
 * for the keys games actually use, so callers don't need <windows.h>
 * VK_* constants directly (keeps gerinput.h usable standalone-ish).
 * ---------------------------------------------------------------------- */
typedef enum GerKey {
    GER_KEY_UNKNOWN = 0,

    GER_KEY_A, GER_KEY_B, GER_KEY_C, GER_KEY_D, GER_KEY_E, GER_KEY_F,
    GER_KEY_G, GER_KEY_H, GER_KEY_I, GER_KEY_J, GER_KEY_K, GER_KEY_L,
    GER_KEY_M, GER_KEY_N, GER_KEY_O, GER_KEY_P, GER_KEY_Q, GER_KEY_R,
    GER_KEY_S, GER_KEY_T, GER_KEY_U, GER_KEY_V, GER_KEY_W, GER_KEY_X,
    GER_KEY_Y, GER_KEY_Z,

    GER_KEY_0, GER_KEY_1, GER_KEY_2, GER_KEY_3, GER_KEY_4,
    GER_KEY_5, GER_KEY_6, GER_KEY_7, GER_KEY_8, GER_KEY_9,

    GER_KEY_SPACE, GER_KEY_ENTER, GER_KEY_ESCAPE, GER_KEY_TAB,
    GER_KEY_BACKSPACE, GER_KEY_SHIFT, GER_KEY_CTRL, GER_KEY_ALT,

    GER_KEY_LEFT, GER_KEY_RIGHT, GER_KEY_UP, GER_KEY_DOWN,

    GER_KEY_F1, GER_KEY_F2, GER_KEY_F3, GER_KEY_F4, GER_KEY_F5, GER_KEY_F6,
    GER_KEY_F7, GER_KEY_F8, GER_KEY_F9, GER_KEY_F10, GER_KEY_F11, GER_KEY_F12,

    GER_KEY_COUNT
} GerKey;

typedef enum GerMouseButton {
    GER_MOUSE_LEFT = 0,
    GER_MOUSE_RIGHT,
    GER_MOUSE_MIDDLE,
    GER_MOUSE_BUTTON_COUNT
} GerMouseButton;

/* ----------------------------------------------------------------------
 * Per-key/button state: 'down' is the raw live state; 'pressedFrame'
 * and 'releasedFrame' are edge-triggered flags valid for exactly one
 * frame (cleared in gerInputBeginFrame).
 * ---------------------------------------------------------------------- */
typedef struct GerInputState {
    uint8_t keyDown[GER_KEY_COUNT];
    uint8_t keyPressedThisFrame[GER_KEY_COUNT];
    uint8_t keyReleasedThisFrame[GER_KEY_COUNT];

    uint8_t mouseDown[GER_MOUSE_BUTTON_COUNT];
    uint8_t mousePressedThisFrame[GER_MOUSE_BUTTON_COUNT];
    uint8_t mouseReleasedThisFrame[GER_MOUSE_BUTTON_COUNT];

    int   mouseX, mouseY;          /* client-area pixel coords */
    int   mouseDeltaX, mouseDeltaY; /* movement since last BeginFrame */
    int   mouseWheelDelta;          /* accumulated wheel notches since last BeginFrame */

    int   prevMouseX, prevMouseY;
    int   hasPrevMouse;
} GerInputState;

/* ----------------------------------------------------------------------
 * Lifecycle / frame management
 * ---------------------------------------------------------------------- */
GER_API void gerInputInit(GerInputState *input);
GER_API void gerInputBeginFrame(GerInputState *input); /* clears edge flags, computes mouse delta */

/* ----------------------------------------------------------------------
 * Win32 message feed (called internally by GerWndProc; exposed in case
 * a host application wants to drive input from its own message loop)
 * ---------------------------------------------------------------------- */
GER_API GerKey gerInputVKToGerKey(unsigned int vkCode); /* maps Win32 VK_* -> GerKey */
GER_API void   gerInputOnKeyDown(GerInputState *input, unsigned int vkCode);
GER_API void   gerInputOnKeyUp(GerInputState *input, unsigned int vkCode);
GER_API void   gerInputOnMouseMove(GerInputState *input, int x, int y);
GER_API void   gerInputOnMouseButtonDown(GerInputState *input, GerMouseButton button);
GER_API void   gerInputOnMouseButtonUp(GerInputState *input, GerMouseButton button);
GER_API void   gerInputOnMouseWheel(GerInputState *input, int delta);

/* ----------------------------------------------------------------------
 * Query API
 * ---------------------------------------------------------------------- */
GER_API int gerInputKeyHeld(const GerInputState *input, GerKey key);
GER_API int gerInputKeyPressed(const GerInputState *input, GerKey key);  /* true for exactly one frame */
GER_API int gerInputKeyReleased(const GerInputState *input, GerKey key); /* true for exactly one frame */

GER_API int gerInputMouseHeld(const GerInputState *input, GerMouseButton button);
GER_API int gerInputMousePressed(const GerInputState *input, GerMouseButton button);
GER_API int gerInputMouseReleased(const GerInputState *input, GerMouseButton button);

GER_API GerVec2 gerInputGetMousePos(const GerInputState *input);
GER_API GerVec2 gerInputGetMouseDelta(const GerInputState *input);
GER_API int     gerInputGetMouseWheelDelta(const GerInputState *input);

#ifdef __cplusplus
}
#endif

#endif /* GERINPUT_H */
