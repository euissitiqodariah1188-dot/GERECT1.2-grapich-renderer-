/* =====================================================================
 * GERECT 1.2 - Demo Application Entry Point
 *
 * Boots the engine, creates a Win32 window, loads a .ger script (or
 * falls back to a built-in scene if none is given), then runs the
 * main loop: poll events -> apply pending resize -> run scene render
 * (SSM -> FRM -> PMTG) -> present to the window.
 * =====================================================================
 */
#include "ger/ger.h"
#include "gersys64/gersys64.h"
#include "ger3d/ger3d.h"
#include "gerui/gerui.h"

static void GerBuildFallbackScene(GerScene *scene) {
    /* Equivalent to running:
     *   gerDL3d
     *   layout[garis]
     *   pos[0.5.0]      (n/a, default 0,0,0)
     *   size[0.10.0][garis]
     *   color[n/red][garis]
     *
     * plus a rotating cube and a textured plane so the demo shows
     * the full pipeline (lines, lit triangles, textures) at once.
     */
    GerLayout *line = gerSceneCreateLayout(scene, "garis");
    gerLayoutSetMeshKind(scene, line, "line");
    gerLayoutSetColor(line, gerColorNamed("n/red"));
    gerLayoutSetPos(line, 0.0f, 0.0f, 0.0f);

    GerLayout *cube = gerSceneCreateLayout(scene, "demo_cube");
    gerLayoutSetMeshKind(scene, cube, "cube");
    gerLayoutSetColor(cube, gerColorNamed("cyan"));
    gerLayoutSetShadeMode(cube, GER_SHADE_GOURAUD);
    gerLayoutSetPos(cube, -1.2f, 0.0f, 0.0f);

    GerLayout *pyramid = gerSceneCreateLayout(scene, "demo_pyramid");
    gerLayoutSetMeshKind(scene, pyramid, "pyramid");
    gerLayoutSetColor(pyramid, gerColorNamed("gold"));
    gerLayoutSetShadeMode(pyramid, GER_SHADE_FLAT);
    gerLayoutSetPos(pyramid, 1.2f, -0.3f, 0.0f);

    GerLayout *sphere = gerSceneCreateLayout(scene, "demo_sphere");
    gerLayoutSetMeshKind(scene, sphere, "sphere");
    gerLayoutSetColor(sphere, gerColorNamed("lime"));
    gerLayoutSetShadeMode(sphere, GER_SHADE_GOURAUD);
    gerLayoutSetPos(sphere, 0.0f, 1.2f, 1.0f);

    GerTexture *checker = gerFugCreateSolidTexture(scene, "checker_tex", 2, 2, gerColorNamed("white"));
    if (checker) {
        checker->pixels[1] = gerColorNamed("black");
        checker->pixels[2] = gerColorNamed("black");
    }
    GerLayout *plane = gerSceneCreateLayout(scene, "demo_floor");
    gerLayoutSetMeshKind(scene, plane, "plane");
    gerLayoutSetSize(plane, 6.0f, 1.0f, 6.0f);
    gerLayoutSetPos(plane, 0.0f, -1.0f, 0.0f);
    gerLayoutSetTexture(plane, checker);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    LPSTR lpCmdLine, int nCmdShow) {
    (void)hPrevInstance; (void)nCmdShow;

    if (gerInit() != GER_OK) {
        MessageBox(NULL, "Failed to initialize GERECT core (timer init)", "GERECT 1.2", MB_ICONERROR);
        return 1;
    }

    GerScene scene;
    if (gerSceneInit(&scene, 1024, 768, 0 /* auto-detect up to 8 cores */) != GER_OK) {
        MessageBox(NULL, "Failed to initialize GERECT scene", "GERECT 1.2", MB_ICONERROR);
        gerShutdown();
        return 1;
    }

    /* If a .ger script path is passed on the command line, run it;
     * otherwise build the built-in demo scene that exercises every
     * subsystem (lines, shaded cube, textured plane, sphere). */
    if (lpCmdLine && lpCmdLine[0] != '\0') {
        GerResult r = gerScriptRunFile(&scene, lpCmdLine);
        if (r != GER_OK) {
            char msg[512];
            sprintf(msg, "Failed to run script '%s' (code %d). Falling back to demo scene.",
                    lpCmdLine, (int)r);
            MessageBox(NULL, msg, "GERECT 1.2", MB_ICONWARNING);
            GerBuildFallbackScene(&scene);
        }
    } else {
        GerBuildFallbackScene(&scene);
    }

    GerWindow window;
    char title[128];
    sprintf(title, "GERECT %d.%d - Win32 Software 3D Renderer (%d threads)",
            GER_VERSION_MAJOR, GER_VERSION_MINOR, gerPmtgGetThreadCount(scene.threadPool));

    if (gerWindowCreate(&window, hInstance, title, 1024, 768) != GER_OK) {
        MessageBox(NULL, "Failed to create GERECT window", "GERECT 1.2", MB_ICONERROR);
        gerSceneDestroy(&scene);
        gerShutdown();
        return 1;
    }
    gerWindowBindScene(&window, &scene);

    double startTime = gerGetTimeSeconds();

    while (gerWindowPollEvents(&window)) {
        gerWindowApplyPendingResize(&window);

        /* simple built-in animation: spin the demo objects so the
         * pipeline visibly exercises rot/move every frame without
         * requiring user input -- harmless no-op if layouts from a
         * custom script don't share these names. */
        double t = gerGetTimeSeconds() - startTime;
        GerLayout *cube = gerSceneFindLayout(&scene, "demo_cube");
        if (cube) gerLayoutSetRotation(cube, (float)(t * 40.0), (float)(t * 60.0), 0.0f);
        GerLayout *pyramid = gerSceneFindLayout(&scene, "demo_pyramid");
        if (pyramid) gerLayoutSetRotation(pyramid, 0.0f, (float)(t * -50.0), 0.0f);
        GerLayout *sphere = gerSceneFindLayout(&scene, "demo_sphere");
        if (sphere) gerLayoutSetRotation(sphere, (float)(t * 20.0), (float)(t * 20.0), 0.0f);

        gerSceneRenderFrame(&scene);
        gerWindowPresent(&window);

        /* light frame pacing: avoid pegging a core at 100% when vsync
         * isn't available from plain GDI BitBlt */
        gerSleepMs(1);
    }

    gerWindowDestroy(&window);
    gerSceneDestroy(&scene);
    gerShutdown();
    return 0;
}
