# GERECT 1.2

Software 3D renderer SDK ditulis murni dalam C, memakai Win32 API saja
(GDI DIB section untuk presentasi layar). Tidak ada OpenGL, DirectX,
SDL, atau SFML di mana pun dalam codebase ini.

## Struktur

```
GERECT1.2/
  include/
    ger/ger.h          - tipe dasar, vector/matrix math, memory pool anti-leak
    gersys64/gersys64.h - PMTG (thread pool multi-core) + FRM (frame timer)
    ger3d/ger3d.h       - SSM (scene/mesh), framebuffer, rasterizer, shader table
    gerui/gerui.h       - window Win32 + interpreter script .ger
  src/
    ger/ger.c
    gersys64/gersys64.c
    ger3d/ger3d_core.c    - framebuffer, kamera, precompiled shader table
    ger3d/ger3d_mesh.c    - builder primitif (line, cube, plane, sphere, pyramid)
    ger3d/ger3d_scene.c   - manajemen layout, loader tekstur BMP (FuG)
    ger3d/ger3d_raster.c  - transform pipeline + rasterizer paralel (PMTG)
    gerui/gerui_window.c  - window Win32, DIB blit
    gerui/gerui_lexer.c   - lexer .ger
    gerui/gerui_script.c  - parser + executor .ger
  examples/
    main.c       - aplikasi demo (WinMain, render loop)
    demo.ger     - contoh script DSL
  Makefile
```

## Alur Render (sesuai spesifikasi)

```
FuG (load tekstur/asset) -> SSM (transform & bin scene)
   -> FRM (frame timing) -> PMTG (rasterisasi paralel sampai 8 core)
   -> selesai, blit ke window
```

Implementasi: `gerSceneRenderFrame()` di `ger3d_raster.c` menjalankan
urutan ini setiap frame. Tidak ada `malloc`/`realloc` di dalam loop ini;
semua buffer (framebuffer, Z-buffer, triangle batch, mesh data)
dialokasikan sekali di awal lewat `VirtualAlloc` atau `GerMemPool`.

## Build (MSYS2 / MinGW)

```sh
make
./gerect_demo.exe
```

Atau jalankan dengan script custom:

```sh
./gerect_demo.exe examples/demo.ger
```

## Sintaks .ger DSL

```
gerDL3d

layout[garis]
pos[0.5.0][garis]
size[0.10.0][garis]
color[n/red][garis]
rot[0.-10.0][garis]
move[1.0.0][garis]
```

### Verb tambahan (10 fungsi developer)

| Verb | Kegunaan |
|---|---|
| `mesh[kind][name]` | set primitif: `line`, `cube`, `plane`, `sphere`, `pyramid` |
| `shade[mode][name]` | set shading: `flat`, `gouraud`, `textured`, `wireframe` |
| `texture[texname][name]` | pasang tekstur yang sudah dimuat ke layout |
| `loadtex[texname][path.bmp]` | load tekstur BMP dari file (FuG) |
| `solidtex[texname][w][h][color]` | buat tekstur warna solid prosedural |
| `hide[name]` | sembunyikan layout (skip render) |
| `show[name]` | tampilkan kembali layout |
| `destroy[name]` | hapus layout permanen |
| `camera[x.y.z]` | set posisi mata kamera |
| `lookat[x.y.z]` | set titik target kamera |
| `fov[degrees]` | set field of view kamera |
| `bg[colorname]` | set warna background frame |

## Warna

Format BGRA little-endian, byte order dalam memori: B, G, R, A.
Nama warna built-in: `red`, `green`, `blue`, `white`, `black`, `yellow`,
`cyan`, `magenta`, `orange`, `purple`, `gray`, `pink`, `brown`, `lime`,
`navy`, `gold`, `silver`, `transparent`. Prefix `n/` (mis. `n/red`)
diterima dan diabaikan. Hex juga didukung: `#RRGGBB` atau `#RRGGBBAA`.

## Threading (PMTG)

Thread pool persisten dibuat sekali (`gerPmtgCreate`), worker thread
diparkir lewat `CONDITION_VARIABLE` dan dibangunkan tiap frame --- tidak
ada `CreateThread`/`CloseHandle` per frame. Setiap frame, baris
framebuffer dibagi jadi beberapa chunk dan diambil oleh worker yang
kosong lewat counter atomic (work-stealing), otomatis menyeimbangkan
beban hingga 8 core logis.

## Anti Memory Leak

- Framebuffer & Z-buffer: `VirtualAlloc` sekali di `gerSceneInit`,
  `VirtualFree` sekali di `gerSceneDestroy`.
- Mesh data: dialokasikan dari `GerMemPool` (satu blok `VirtualAlloc`
  besar) saat layout dibuat; tidak pernah realloc per frame.
- GDI objects (`HBITMAP`, `HDC`): dibuat sekali per ukuran window,
  dibersihkan sebelum dibuat ulang saat resize, dan dibebaskan total
  di `gerWindowDestroy`.
- `BeginPaint`/`EndPaint` selalu berpasangan di `WM_PAINT`.
- Setiap path `return` awal pada fungsi loader (BMP, dsb) membebaskan
  buffer yang sudah dialokasikan sebelum keluar.
