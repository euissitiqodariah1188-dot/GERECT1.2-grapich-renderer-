/* =====================================================================
 * GERECT 1.2 - OBJ Loader + Lighting + Shadow Header (ger3d/gerlight.h)
 *
 * Berisi:
 *  1. OBJ/MTL Loader  - parse Wavefront .obj + .mtl ke GerMesh
 *  2. GerLight system - directional, point, spotlight
 *  3. Shadow map      - software depth-only render pass dari posisi light
 *                       lalu shadow test di rasterizer utama (PCF 2x2)
 * =====================================================================
 */
#ifndef GERLIGHT_H
#define GERLIGHT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ger/ger.h"
#include "ger3d/ger3d.h"

/* -----------------------------------------------------------------------
 * 1.  OBJ / MTL Loader
 * ----------------------------------------------------------------------- */

/* Material parsed from .mtl file */
typedef struct GerObjMaterial {
    char     name[GER_MAX_NAME_LEN];
    GerVec3  Ka;          /* ambient  RGB 0..1 */
    GerVec3  Kd;          /* diffuse  RGB 0..1 */
    GerVec3  Ks;          /* specular RGB 0..1 */
    float    Ns;          /* specular exponent */
    float    d;           /* dissolve / alpha (1 = opaque) */
    char     map_Kd[260]; /* diffuse texture path, empty if none */
} GerObjMaterial;

#define GER_OBJ_MAX_MATERIALS 64

typedef struct GerObjMaterialLib {
    GerObjMaterial mats[GER_OBJ_MAX_MATERIALS];
    int            count;
} GerObjMaterialLib;

/*
 * Loads a Wavefront .obj file (and its .mtl sidecar if present) into
 * a GerMesh allocated from `pool`.  Vertices are deduplicated and
 * normals are generated (from face normals) if the .obj has none.
 *
 * `outMaterial` is filled with the *first* material found in the
 * accompanying .mtl (if any); pass NULL to ignore.
 *
 * Restrictions (standard for a software renderer of this scope):
 *  - Only triangles and quads (auto-triangulated); n-gons skipped.
 *  - One material group per mesh load call; multi-material .obj files
 *    can be loaded multiple times with different `usemtl` targets via
 *    `targetMaterialName` (NULL = load all faces regardless of material).
 *  - Maximum GER_MESH_MAX_VERTICES vertices per mesh.
 */
GER_API GerResult gerObjLoad(GerMesh *outMesh, GerMemPool *pool,
                              const char *objPath,
                              const char *targetMaterialName, /* NULL = all */
                              GerObjMaterial *outMaterial);   /* NULL = ignore */

/* Parse just the .mtl file into a material library (useful when you
 * want to inspect all materials before deciding which to load). */
GER_API GerResult gerMtlLoad(GerObjMaterialLib *lib, const char *mtlPath);

/* Load OBJ dari memory buffer (untuk embedded assets).
 * `data` adalah isi file .obj sebagai string, `size` panjangnya.
 * `mtlData` adalah isi file .mtl (boleh NULL kalau tidak ada). */
GER_API GerResult gerObjLoadFromMemory(GerMesh *outMesh, GerMemPool *pool,
                                        const char *objData, size_t objSize,
                                        const char *mtlData, size_t mtlSize,
                                        const char *targetMaterialName,
                                        GerObjMaterial *outMaterial);

/* Convenience: embed + load langsung ke layout */
GER_API GerLayout *gerFugLoadObjFromMemory(GerScene *scene,
                                            const char *layoutName,
                                            const char *objData, size_t objSize,
                                            const char *mtlData, size_t mtlSize,
                                            const char *targetMat);

/* Convenience: load .obj directly into a new layout on a scene. */
GER_API GerLayout *gerFugLoadObj(GerScene *scene,
                                  const char *layoutName,
                                  const char *objPath,
                                  const char *targetMaterialName);

/* -----------------------------------------------------------------------
 * 2.  Light system
 * ----------------------------------------------------------------------- */

typedef enum GerLightType {
    GER_LIGHT_DIRECTIONAL = 0,  /* infinite, position ignored, dir used */
    GER_LIGHT_POINT,            /* omnidirectional from position */
    GER_LIGHT_SPOT,             /* cone from position toward direction */
    GER_LIGHT_AMBIENT           /* constant additive term, no direction */
} GerLightType;

typedef struct GerLight {
    GerLightType type;
    int          enabled;

    GerVec3 position;       /* world space (unused for DIRECTIONAL) */
    GerVec3 direction;      /* world space, should be normalized      */

    /* colour / intensity */
    GerVec3 colorAmbient;   /* Ka contribution */
    GerVec3 colorDiffuse;   /* Kd contribution */
    GerVec3 colorSpecular;  /* Ks contribution */
    float   intensity;      /* global multiplier */

    /* attenuation: f = 1/(c + l*d + q*d*d), POINT and SPOT only */
    float attConstant;
    float attLinear;
    float attQuadratic;

    /* spotlight cone, radians, SPOT only */
    float spotInnerAngle;   /* full intensity inside this cone */
    float spotOuterAngle;   /* falls off to zero at outer edge */

    /* shadow */
    int   castShadow;       /* 1 = this light casts shadows */
} GerLight;

#define GER_MAX_LIGHTS 8

/* Preset constructors */
GER_API GerLight gerLightMakeDirectional(GerVec3 dir,
                                          GerVec3 diffuse, float intensity);
GER_API GerLight gerLightMakePoint(GerVec3 pos,
                                    GerVec3 diffuse, float intensity,
                                    float attLin, float attQuad);
GER_API GerLight gerLightMakeSpot(GerVec3 pos, GerVec3 dir,
                                   GerVec3 diffuse, float intensity,
                                   float innerDeg, float outerDeg);
GER_API GerLight gerLightMakeAmbient(GerVec3 color, float intensity);

/* -----------------------------------------------------------------------
 * 3.  Shadow map
 *
 * A GerShadowMap is a standalone depth buffer rendered from one light's
 * point of view.  Only one shadow map is supported per light (shadow
 * maps for each shadow-casting light are stored in GerLightSystem).
 * The map is allocated ONCE in gerShadowMapInit() and reused every
 * frame (memset to far depth, render depth pass, then sample in main
 * pass -- no malloc in the loop).
 * ----------------------------------------------------------------------- */
#define GER_SHADOW_MAP_SIZE 512   /* square, power-of-two for bias math */

typedef struct GerShadowMap {
    float   *depth;            /* GER_SHADOW_MAP_SIZE^2, VirtualAlloc'd once */
    GerMat4  lightViewProj;    /* recalculated every frame from light params */
    int      initialized;
} GerShadowMap;

GER_API GerResult gerShadowMapInit(GerShadowMap *sm);
GER_API void      gerShadowMapDestroy(GerShadowMap *sm);
GER_API void      gerShadowMapClear(GerShadowMap *sm);

/* Builds lightViewProj for a directional or spot light. For point
 * lights a simple "look toward scene center" projection is used. */
GER_API void      gerShadowMapBuildLightMatrix(GerShadowMap *sm,
                                                const GerLight *light,
                                                GerVec3 sceneCenterHint,
                                                float sceneRadius);

/* Sample: returns 0.0 (fully shadowed) .. 1.0 (fully lit).
 * Uses 2x2 PCF (percentage-closer filtering) to soften shadow edges. */
GER_API float gerShadowMapSample(const GerShadowMap *sm,
                                  GerVec3 worldPos, float bias);

/* -----------------------------------------------------------------------
 * 4.  GerLightSystem: owns up to GER_MAX_LIGHTS + their shadow maps,
 *     attached to a GerScene.
 * ----------------------------------------------------------------------- */
typedef struct GerLightSystem {
    GerLight    lights[GER_MAX_LIGHTS];
    int         lightCount;
    GerShadowMap shadowMaps[GER_MAX_LIGHTS]; /* one per light, only init'd if castShadow */
    int          initialized;
} GerLightSystem;

GER_API GerResult gerLightSystemInit(GerLightSystem *ls);
GER_API void      gerLightSystemDestroy(GerLightSystem *ls);

GER_API int  gerLightAdd(GerLightSystem *ls, GerLight light); /* returns light index, -1 on fail */
GER_API void gerLightRemove(GerLightSystem *ls, int index);
GER_API GerLight *gerLightGet(GerLightSystem *ls, int index);

/*
 * Compute the final lit colour for one surface point.
 * Implements full Phong shading across all enabled lights, with
 * optional shadow map sampling per shadow-casting light.
 *
 * materialKa/Kd/Ks/Ns come from GerObjMaterial or from the layout's
 * base colour (engine derives Ka=Kd from the colour, Ks=white, Ns=32
 * if no material data is available).
 */
GER_API GerColor gerLightSystemShade(
    const GerLightSystem *ls,
    GerVec3 worldPos,
    GerVec3 worldNormal,
    GerVec3 viewDir,
    GerVec3 matKa,
    GerVec3 matKd,
    GerVec3 matKs,
    float   matNs,
    float   baseAlpha
);

/*
 * Full shadow + depth pass: for each shadow-casting light, render all
 * active layouts' geometry into that light's GerShadowMap.  Call this
 * BEFORE gerSceneRenderFrame() each frame.  It uses the scene's PMTG
 * thread pool internally.
 */
GER_API void gerLightSystemShadowPass(GerLightSystem *ls,
                                       GerScene *scene);

/* Attach / detach a light system to a scene so the rasterizer can
 * find it.  Scene holds a pointer (not a copy) -- caller owns ls. */
GER_API void gerSceneSetLightSystem(GerScene *scene, GerLightSystem *ls);

#ifdef __cplusplus
}
#endif

#endif /* GERLIGHT_H */
