/* =====================================================================
 * GERECT 1.2 - Audio Implementation (WinMM)
 * =====================================================================
 */
#include "geraudio/geraudio.h"
#include <windows.h>
#include <mmsystem.h>

GerResult gerAudioPlaySoundSimple(const char *wavPath, int loop) {
    if (!wavPath) return GER_ERR_NULLPTR;
    DWORD flags = SND_FILENAME | SND_ASYNC;
    if (loop) flags |= SND_LOOP;
    BOOL ok = PlaySoundA(wavPath, NULL, flags);
    return ok ? GER_OK : GER_ERR_NOT_FOUND;
}

void gerAudioStopSimple(void) {
    PlaySoundA(NULL, NULL, 0);
}

GerResult gerAudioInit(void) {
    return GER_OK; /* reserved: WinMM requires no explicit global init */
}

static int g_aliasCounter = 0;

static void GerMakeUniqueAlias(char *out, size_t outSize, const char *name) {
    /* MCI aliases must be unique per open device; combine the
     * caller-provided name with a monotonically increasing counter so
     * repeated loads of sounds sharing a name don't collide. */
    g_aliasCounter++;
    _snprintf(out, outSize - 1, "ger_%s_%d", name, g_aliasCounter);
    out[outSize - 1] = '\0';
}

GerResult gerAudioLoad(GerSoundHandle *outHandles, int *handleCount,
                        const char *name, const char *filePath) {
    if (!outHandles || !handleCount || !name || !filePath) return GER_ERR_NULLPTR;
    if (*handleCount >= GER_AUDIO_MAX_SOUNDS) return GER_ERR_LIMIT_REACHED;

    GerSoundHandle *h = &outHandles[*handleCount];
    memset(h, 0, sizeof(GerSoundHandle));
    strncpy(h->alias, name, GER_MAX_NAME_LEN - 1);
    strncpy(h->path, filePath, sizeof(h->path) - 1);

    char uniqueAlias[GER_MAX_NAME_LEN];
    GerMakeUniqueAlias(uniqueAlias, sizeof(uniqueAlias), name);

    char cmd[600];
    _snprintf(cmd, sizeof(cmd) - 1, "open \"%s\" alias %s", filePath, uniqueAlias);
    cmd[sizeof(cmd) - 1] = '\0';

    MCIERROR err = mciSendStringA(cmd, NULL, 0, NULL);
    if (err != 0) {
        return GER_ERR_NOT_FOUND;
    }

    /* store the actual MCI alias (with uniqueness suffix) so later
     * play/stop calls address the right device; overwrite the
     * friendly `name` copy with the real alias used for MCI commands */
    strncpy(h->alias, uniqueAlias, GER_MAX_NAME_LEN - 1);
    h->alias[GER_MAX_NAME_LEN - 1] = '\0';
    h->loaded = 1;
    h->looping = 0;

    (*handleCount)++;
    return GER_OK;
}

GerSoundHandle *gerAudioFind(GerSoundHandle *handles, int handleCount, const char *name) {
    if (!handles || !name) return NULL;
    int i;
    for (i = 0; i < handleCount; i++) {
        /* match against the original friendly path OR the stored
         * alias's name portion; simplest robust approach is to also
         * keep track via the path field for lookup, since alias was
         * overwritten with the unique form in gerAudioLoad(). */
        if (strstr(handles[i].alias, name) != NULL) {
            return &handles[i];
        }
    }
    return NULL;
}

GerResult gerAudioPlay(GerSoundHandle *handle, int loop) {
    if (!handle || !handle->loaded) return GER_ERR_INVALID_ARG;

    handle->looping = loop;
    char cmd[300];
    if (loop) {
        _snprintf(cmd, sizeof(cmd) - 1, "play %s repeat from 0", handle->alias);
    } else {
        _snprintf(cmd, sizeof(cmd) - 1, "play %s from 0", handle->alias);
    }
    cmd[sizeof(cmd) - 1] = '\0';

    MCIERROR err = mciSendStringA(cmd, NULL, 0, NULL);
    return err == 0 ? GER_OK : GER_ERR_WIN32;
}

GerResult gerAudioStop(GerSoundHandle *handle) {
    if (!handle || !handle->loaded) return GER_ERR_INVALID_ARG;
    char cmd[300];
    _snprintf(cmd, sizeof(cmd) - 1, "stop %s", handle->alias);
    cmd[sizeof(cmd) - 1] = '\0';
    MCIERROR err = mciSendStringA(cmd, NULL, 0, NULL);
    return err == 0 ? GER_OK : GER_ERR_WIN32;
}

GerResult gerAudioPause(GerSoundHandle *handle) {
    if (!handle || !handle->loaded) return GER_ERR_INVALID_ARG;
    char cmd[300];
    _snprintf(cmd, sizeof(cmd) - 1, "pause %s", handle->alias);
    cmd[sizeof(cmd) - 1] = '\0';
    MCIERROR err = mciSendStringA(cmd, NULL, 0, NULL);
    return err == 0 ? GER_OK : GER_ERR_WIN32;
}

GerResult gerAudioResume(GerSoundHandle *handle) {
    if (!handle || !handle->loaded) return GER_ERR_INVALID_ARG;
    char cmd[300];
    _snprintf(cmd, sizeof(cmd) - 1, "resume %s", handle->alias);
    cmd[sizeof(cmd) - 1] = '\0';
    MCIERROR err = mciSendStringA(cmd, NULL, 0, NULL);
    return err == 0 ? GER_OK : GER_ERR_WIN32;
}

GerResult gerAudioSetVolume(GerSoundHandle *handle, float volume0to1) {
    if (!handle || !handle->loaded) return GER_ERR_INVALID_ARG;
    if (volume0to1 < 0.0f) volume0to1 = 0.0f;
    if (volume0to1 > 1.0f) volume0to1 = 1.0f;

    /* MCI volume range is 0-1000 */
    int mciVolume = (int)(volume0to1 * 1000.0f);
    char cmd[300];
    _snprintf(cmd, sizeof(cmd) - 1, "setaudio %s volume to %d", handle->alias, mciVolume);
    cmd[sizeof(cmd) - 1] = '\0';
    MCIERROR err = mciSendStringA(cmd, NULL, 0, NULL);
    return err == 0 ? GER_OK : GER_ERR_WIN32;
}

GerResult gerAudioUnload(GerSoundHandle *handle) {
    if (!handle || !handle->loaded) return GER_ERR_INVALID_ARG;
    char cmd[300];
    _snprintf(cmd, sizeof(cmd) - 1, "close %s", handle->alias);
    cmd[sizeof(cmd) - 1] = '\0';
    mciSendStringA(cmd, NULL, 0, NULL); /* best-effort; ignore error on close */
    handle->loaded = 0;
    return GER_OK;
}

void gerAudioShutdownAll(void) {
    /* Best-effort global stop: closes the simple PlaySound channel.
     * Individual MCI handles must be unloaded explicitly via
     * gerAudioUnload() by whoever owns the GerSoundHandle array,
     * since this module holds no global handle table itself (handles
     * are owned by the caller, e.g. GerScene or the application). */
    gerAudioStopSimple();
}
