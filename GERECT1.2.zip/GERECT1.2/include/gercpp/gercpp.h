/* =====================================================================
 * GERECT 1.2 - C++ Wrapper (gercpp/gercpp.h)
 *
 * Header-only C++ layer on top of the C API. Semua class pakai RAII:
 * constructor init, destructor cleanup -- tidak ada resource leak
 * selama object lifetime dikelola dengan benar (scope, unique_ptr, dll).
 *
 * Cara pakai di C++:
 *
 *   #include <gercpp/gercpp.h>
 *
 *   int WINAPI WinMain(...) {
 *       ger::Engine engine;
 *       ger::Window window(hInstance, "Game", 1024, 768);
 *       ger::Scene  scene(1024, 768, 0);
 *       window.bindScene(scene);
 *
 *       ger::Layout *cube = scene.createLayout("kubus");
 *       cube->setMesh("cube")
 *            ->setColor("cyan")
 *            ->setShadeMode(GER_SHADE_GOURAUD)
 *            ->setPos(0, 0, 0);
 *
 *       ger::Audio bgm;
 *       bgm.load("music", "bgm.mp3");
 *       bgm.play("music", true);
 *
 *       while (window.pollEvents()) {
 *           ger::Input &input = window.getInput();
 *           input.beginFrame();
 *           if (input.keyPressed(GER_KEY_ESCAPE)) break;
 *           if (input.keyHeld(GER_KEY_W)) cube->move(0, 0, 0.05f);
 *           scene.renderFrame();
 *           window.present();
 *       }
 *   } // destructor semua object dipanggil otomatis
 * =====================================================================
 */
#ifndef GERCPP_H
#define GERCPP_H

#ifndef __cplusplus
#error "gercpp/gercpp.h is a C++ only header. Use the C API headers for C code."
#endif

#include "ger/ger.h"
#include "gersys64/gersys64.h"
#include "ger3d/ger3d.h"
#include "ger3d/gercollision.h"
#include "ger3d/gerlight.h"
#include "gerinput/gerinput.h"
#include "geraudio/geraudio.h"
#include "gerui/gerui.h"

#include <stdexcept>
#include <string>
#include <functional>

namespace ger {

/* =====================================================================
 * Engine: global GERECT lifecycle RAII guard
 * ===================================================================== */
class Engine {
public:
    Engine() {
        if (gerInit() != GER_OK)
            throw std::runtime_error("gerInit() failed");
    }
    ~Engine() {
        gerShutdown();
    }
    Engine(const Engine&) = delete;
    Engine& operator=(const Engine&) = delete;

    double getTime()  const { return gerGetTimeSeconds(); }
    void   sleepMs(unsigned int ms) const { gerSleepMs(ms); }
};

/* =====================================================================
 * Layout: wrapper around GerLayout*, chaining API
 * ===================================================================== */
class Layout {
public:
    explicit Layout(GerLayout *ptr) : m_ptr(ptr) {}

    Layout* setPos(float x, float y, float z) {
        gerLayoutSetPos(m_ptr, x, y, z);
        return this;
    }
    Layout* setSize(float x, float y, float z) {
        gerLayoutSetSize(m_ptr, x, y, z);
        return this;
    }
    Layout* setColor(const char *colorName) {
        gerLayoutSetColor(m_ptr, gerColorNamed(colorName));
        return this;
    }
    Layout* setColor(GerColor color) {
        gerLayoutSetColor(m_ptr, color);
        return this;
    }
    Layout* setRotation(float rx, float ry, float rz) {
        gerLayoutSetRotation(m_ptr, rx, ry, rz);
        return this;
    }
    Layout* move(float dx, float dy, float dz) {
        gerLayoutMove(m_ptr, dx, dy, dz);
        return this;
    }
    Layout* setShadeMode(GerShadeMode mode) {
        gerLayoutSetShadeMode(m_ptr, mode);
        return this;
    }
    Layout* setTexture(GerTexture *tex) {
        gerLayoutSetTexture(m_ptr, tex);
        return this;
    }
    Layout* setMesh(const char *kind, GerScene *scene) {
        gerLayoutSetMeshKind(scene, m_ptr, kind);
        return this;
    }
    Layout* hide()  { if (m_ptr) m_ptr->active = 0; return this; }
    Layout* show()  { if (m_ptr) m_ptr->active = 1; return this; }

    /* Collision convenience */
    GerAABB   getWorldAABB()   const { GerAABB local = gerMeshComputeLocalAABB(&m_ptr->mesh); return gerLayoutGetWorldAABB(m_ptr, local); }
    GerSphere getWorldSphere() const { GerAABB local = gerMeshComputeLocalAABB(&m_ptr->mesh); return gerLayoutGetWorldSphere(m_ptr, local); }

    bool collidesAABB(const Layout &other) const {
        return gerCollideAABBvsAABB(getWorldAABB(), other.getWorldAABB()) != 0;
    }
    bool collidesSphere(const Layout &other) const {
        return gerCollideSphereVsSphere(getWorldSphere(), other.getWorldSphere()) != 0;
    }

    /* Access underlying C struct when needed */
    GerLayout* get()             { return m_ptr; }
    const GerLayout* get() const { return m_ptr; }

    GerVec3 getPos()      const { return m_ptr ? m_ptr->position : GerVec3{0,0,0}; }
    GerVec3 getScale()    const { return m_ptr ? m_ptr->scale    : GerVec3{1,1,1}; }
    GerVec3 getRotation() const { return m_ptr ? m_ptr->rotationRad : GerVec3{0,0,0}; }
    bool    isActive()    const { return m_ptr && m_ptr->active; }

private:
    GerLayout *m_ptr;
};

/* =====================================================================
 * Scene: owns GerScene, provides Layout factory with method chaining
 * ===================================================================== */
class Scene {
public:
    Scene(int width, int height, int threadCount = 0) {
        if (gerSceneInit(&m_scene, width, height, threadCount) != GER_OK)
            throw std::runtime_error("gerSceneInit() failed");
    }
    ~Scene() {
        gerSceneDestroy(&m_scene);
    }
    Scene(const Scene&) = delete;
    Scene& operator=(const Scene&) = delete;

    /* Returns a Layout wrapper (thin pointer holder, no allocation).
     * The wrapper is valid as long as the scene is alive and the
     * layout hasn't been destroy()'d. */
    Layout createLayout(const char *name) {
        GerLayout *l = gerSceneCreateLayout(&m_scene, name);
        if (!l) throw std::runtime_error(std::string("Failed to create layout: ") + name);
        return Layout(l);
    }

    Layout findLayout(const char *name) {
        GerLayout *l = gerSceneFindLayout(&m_scene, name);
        if (!l) throw std::runtime_error(std::string("Layout not found: ") + name);
        return Layout(l);
    }

    bool tryFindLayout(const char *name, Layout &outLayout) {
        GerLayout *l = gerSceneFindLayout(&m_scene, name);
        if (!l) return false;
        outLayout = Layout(l);
        return true;
    }

    void destroyLayout(const char *name) {
        gerLayoutDestroy(&m_scene, name);
    }

    /* Layout factory shorthand: create + set mesh kind in one call */
    Layout makeLayout(const char *name, const char *meshKind,
                       const char *colorName = "white",
                       GerShadeMode shade = GER_SHADE_GOURAUD) {
        GerLayout *l = gerSceneCreateLayout(&m_scene, name);
        if (!l) throw std::runtime_error(std::string("Failed to create layout: ") + name);
        gerLayoutSetMeshKind(&m_scene, l, meshKind);
        gerLayoutSetColor(l, gerColorNamed(colorName));
        gerLayoutSetShadeMode(l, shade);
        return Layout(l);
    }

    /* Script execution */
    GerResult runScript(const char *source) {
        return gerScriptRunSource(&m_scene, source);
    }
    GerResult runScriptFile(const char *path) {
        return gerScriptRunFile(&m_scene, path);
    }

    /* OBJ loader */
    Layout loadObj(const char *layoutName, const char *objPath,
                   const char *targetMat = nullptr) {
        GerLayout *l = gerFugLoadObj(&m_scene, layoutName, objPath, targetMat);
        if (!l) throw std::runtime_error(std::string("Failed to load OBJ: ") + objPath);
        return Layout(l);
    }

    /* Texture loading */
    GerTexture* loadTextureBMP(const char *name, const char *path) {
        return gerFugLoadTextureBMP(&m_scene, name, path);
    }
    GerTexture* createSolidTexture(const char *name, int w, int h, const char *colorName) {
        return gerFugCreateSolidTexture(&m_scene, name, w, h, gerColorNamed(colorName));
    }

    /* Camera control */
    void setCameraEye(float x, float y, float z) {
        m_scene.camera.eye = gerVec3Make(x, y, z);
    }
    void setCameraTarget(float x, float y, float z) {
        m_scene.camera.target = gerVec3Make(x, y, z);
    }
    void setCameraFov(float degrees) {
        m_scene.camera.fovYRadians = (float)GER_DEG2RAD(degrees);
    }

    /* Render */
    void renderFrame() { gerSceneRenderFrame(&m_scene); }

    /* FPS info */
    double getFps()       const { return gerFrmGetFps(&m_scene.frameTimer); }
    double getDeltaTime() const { return gerFrmGetDeltaTime(&m_scene.frameTimer); }

    /* Resize (call from WM_SIZE via window callback) */
    void resize(int w, int h) {
        gerFramebufferResize(&m_scene.framebuffer, w, h);
    }

    GerScene* get() { return &m_scene; }

private:
    GerScene m_scene;
};

/* =====================================================================
 * Input: thin wrapper around GerInputState
 * ===================================================================== */
class Input {
public:
    explicit Input(GerInputState *state) : m_state(state) {}

    void beginFrame() { gerInputBeginFrame(m_state); }

    bool keyHeld(GerKey k)     const { return gerInputKeyHeld(m_state, k) != 0; }
    bool keyPressed(GerKey k)  const { return gerInputKeyPressed(m_state, k) != 0; }
    bool keyReleased(GerKey k) const { return gerInputKeyReleased(m_state, k) != 0; }

    bool mouseHeld(GerMouseButton b)     const { return gerInputMouseHeld(m_state, b) != 0; }
    bool mousePressed(GerMouseButton b)  const { return gerInputMousePressed(m_state, b) != 0; }
    bool mouseReleased(GerMouseButton b) const { return gerInputMouseReleased(m_state, b) != 0; }

    GerVec2 mousePos()   const { return gerInputGetMousePos(m_state); }
    GerVec2 mouseDelta() const { return gerInputGetMouseDelta(m_state); }
    int     mouseWheel() const { return gerInputGetMouseWheelDelta(m_state); }

private:
    GerInputState *m_state;
};

/* =====================================================================
 * Window: RAII Win32 window with embedded Input accessor
 * ===================================================================== */
class Window {
public:
    Window(HINSTANCE hInstance, const char *title, int width, int height) {
        if (gerWindowCreate(&m_window, hInstance, title, width, height) != GER_OK)
            throw std::runtime_error("gerWindowCreate() failed");
    }
    ~Window() {
        gerWindowDestroy(&m_window);
    }
    Window(const Window&) = delete;
    Window& operator=(const Window&) = delete;

    void bindScene(Scene &scene) { gerWindowBindScene(&m_window, scene.get()); }
    void bindScene(GerScene *scene) { gerWindowBindScene(&m_window, scene); }

    bool pollEvents() { return gerWindowPollEvents(&m_window) != 0; }
    void present()    { gerWindowPresent(&m_window); }
    bool shouldClose() const { return gerWindowShouldClose(&m_window) != 0; }
    void applyPendingResize() { gerWindowApplyPendingResize(&m_window); }

    int width()  const { return m_window.width; }
    int height() const { return m_window.height; }

    /* Returns an Input wrapper backed by this window's embedded state.
     * The wrapper is valid as long as the Window object is alive. */
    Input getInput() { return Input(&m_window.input); }

    GerWindow* get() { return &m_window; }

private:
    GerWindow m_window;
};

/* =====================================================================
 * Audio: RAII sound bank owning an array of GerSoundHandle
 * ===================================================================== */
class Audio {
public:
    Audio() : m_count(0) {
        gerAudioInit();
    }
    ~Audio() {
        int i;
        for (i = 0; i < m_count; i++) {
            if (m_handles[i].loaded) gerAudioUnload(&m_handles[i]);
        }
        gerAudioShutdownAll();
    }
    Audio(const Audio&) = delete;
    Audio& operator=(const Audio&) = delete;

    GerResult load(const char *name, const char *filePath) {
        return gerAudioLoad(m_handles, &m_count, name, filePath);
    }

    GerResult play(const char *name, bool loop = false) {
        GerSoundHandle *h = gerAudioFind(m_handles, m_count, name);
        if (!h) return GER_ERR_NOT_FOUND;
        return gerAudioPlay(h, loop ? 1 : 0);
    }

    GerResult stop(const char *name) {
        GerSoundHandle *h = gerAudioFind(m_handles, m_count, name);
        if (!h) return GER_ERR_NOT_FOUND;
        return gerAudioStop(h);
    }

    GerResult pause(const char *name) {
        GerSoundHandle *h = gerAudioFind(m_handles, m_count, name);
        if (!h) return GER_ERR_NOT_FOUND;
        return gerAudioPause(h);
    }

    GerResult resume(const char *name) {
        GerSoundHandle *h = gerAudioFind(m_handles, m_count, name);
        if (!h) return GER_ERR_NOT_FOUND;
        return gerAudioResume(h);
    }

    GerResult setVolume(const char *name, float vol) {
        GerSoundHandle *h = gerAudioFind(m_handles, m_count, name);
        if (!h) return GER_ERR_NOT_FOUND;
        return gerAudioSetVolume(h, vol);
    }

    GerResult unload(const char *name) {
        GerSoundHandle *h = gerAudioFind(m_handles, m_count, name);
        if (!h) return GER_ERR_NOT_FOUND;
        return gerAudioUnload(h);
    }

    int count() const { return m_count; }

private:
    GerSoundHandle m_handles[GER_AUDIO_MAX_SOUNDS];
    int            m_count;
};

/* =====================================================================
 * Collision helpers callable from C++
 * ===================================================================== */
inline bool collideAABB(GerAABB a, GerAABB b) {
    return gerCollideAABBvsAABB(a, b) != 0;
}
inline bool collideSphere(GerSphere a, GerSphere b) {
    return gerCollideSphereVsSphere(a, b) != 0;
}
inline bool collideAABBSphere(GerAABB box, GerSphere sphere) {
    return gerCollideAABBvsSphere(box, sphere) != 0;
}
inline bool rayVsAABB(GerVec3 origin, GerVec3 dir, GerAABB box, float *dist = nullptr) {
    return gerCollideRayVsAABB(origin, dir, box, dist) != 0;
}
inline bool rayVsSphere(GerVec3 origin, GerVec3 dir, GerSphere sphere, float *dist = nullptr) {
    return gerCollideRayVsSphere(origin, dir, sphere, dist) != 0;
}

/* =====================================================================
 * LightSystem: RAII wrapper untuk pencahayaan + shadow
 * ===================================================================== */
class LightSystem {
public:
    LightSystem() {
        if (gerLightSystemInit(&m_ls) != GER_OK)
            throw std::runtime_error("gerLightSystemInit() failed");
    }
    ~LightSystem() {
        gerLightSystemDestroy(&m_ls);
    }
    LightSystem(const LightSystem&) = delete;
    LightSystem& operator=(const LightSystem&) = delete;

    /* Tambah light, return index */
    int addDirectional(GerVec3 dir, GerVec3 diffuse, float intensity, bool shadow = false) {
        GerLight l = gerLightMakeDirectional(dir, diffuse, intensity);
        l.castShadow = shadow ? 1 : 0;
        return gerLightAdd(&m_ls, l);
    }
    int addPoint(GerVec3 pos, GerVec3 diffuse, float intensity,
                 float attLin = 0.09f, float attQuad = 0.032f, bool shadow = false) {
        GerLight l = gerLightMakePoint(pos, diffuse, intensity, attLin, attQuad);
        l.castShadow = shadow ? 1 : 0;
        return gerLightAdd(&m_ls, l);
    }
    int addSpot(GerVec3 pos, GerVec3 dir, GerVec3 diffuse, float intensity,
                float innerDeg, float outerDeg, bool shadow = false) {
        GerLight l = gerLightMakeSpot(pos, dir, diffuse, intensity, innerDeg, outerDeg);
        l.castShadow = shadow ? 1 : 0;
        return gerLightAdd(&m_ls, l);
    }
    int addAmbient(GerVec3 color, float intensity) {
        return gerLightAdd(&m_ls, gerLightMakeAmbient(color, intensity));
    }

    void remove(int index)                     { gerLightRemove(&m_ls, index); }
    GerLight* get(int index)                   { return gerLightGet(&m_ls, index); }
    void enable(int index, bool on = true)     { GerLight *l = get(index); if (l) l->enabled = on ? 1 : 0; }

    /* Attach ke scene (scene tidak own light system ini) */
    void attachTo(Scene &scene) {
        gerSceneSetLightSystem(scene.get(), &m_ls);
    }

    GerLightSystem* get() { return &m_ls; }

private:
    GerLightSystem m_ls;
};

/* =====================================================================
 * GameLoop: optional fixed-timestep game loop helper
 *
 * Encapsulates the while(pollEvents) + beginFrame + renderFrame +
 * present pattern so callers just provide lambdas / function pointers.
 *
 * Usage:
 *   ger::GameLoop loop(window, scene, 60.0);  // target 60 fps
 *   loop.onUpdate([&](double dt) {
 *       cube.setRotation(0, (float)(gerGetTimeSeconds() * 45.0), 0);
 *   });
 *   loop.run();
 * ===================================================================== */
class GameLoop {
public:
    using UpdateFn = std::function<void(double deltaTime)>;
    using RenderFn = std::function<void()>;

    GameLoop(Window &window, Scene &scene, double targetFps = 60.0)
        : m_window(window), m_scene(scene),
          m_targetDt(targetFps > 0.0 ? 1.0 / targetFps : 1.0 / 60.0) {}

    void onUpdate(UpdateFn fn) { m_updateFn = fn; }
    void onRender(RenderFn fn) { m_renderFn = fn; }

    void run() {
        double accumulator = 0.0;
        double lastTime = gerGetTimeSeconds();

        while (m_window.pollEvents()) {
            m_window.applyPendingResize();

            /* beginFrame BEFORE polling events so new edge-triggered
             * key presses from this iteration's PeekMessage batch are
             * visible immediately to the update callback */
            Input input = m_window.getInput();
            input.beginFrame();

            double now = gerGetTimeSeconds();
            double frameTime = now - lastTime;
            if (frameTime > 0.25) frameTime = 0.25; /* clamp spiral-of-death */
            lastTime = now;
            accumulator += frameTime;

            while (accumulator >= m_targetDt) {
                if (m_updateFn) m_updateFn(m_targetDt);
                accumulator -= m_targetDt;
            }

            m_scene.renderFrame();
            if (m_renderFn) m_renderFn();
            m_window.present();
        }
    }

private:
    Window  &m_window;
    Scene   &m_scene;
    double   m_targetDt;
    UpdateFn m_updateFn;
    RenderFn m_renderFn;
};

} /* namespace ger */

#endif /* GERCPP_H */
