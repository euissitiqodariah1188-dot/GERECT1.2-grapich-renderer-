/* =====================================================================
 * GERECT 1.2 - System/Threading Header (gersys64/gersys64.h)
 *
 * Modules implemented here:
 *   PMTG - Pembagi Multi-Thread Gerect: splits render work across up
 *          to GER_MAX_CORES (8) worker threads using a persistent
 *          thread pool (threads are created once, parked on a
 *          condition variable, and reused every frame — no
 *          CreateThread/CloseHandle churn per frame).
 *   FRM  - Frame timing / FPS counter.
 * =====================================================================
 */
#ifndef GERSYS64_H
#define GERSYS64_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ger/ger.h"

/* ----------------------------------------------------------------------
 * PMTG: persistent thread pool for tile-based parallel rasterization
 * ---------------------------------------------------------------------- */

typedef void (*GerJobFn)(int threadIndex, int tileY0, int tileY1, void *userData);

typedef struct GerThreadPool GerThreadPool;

GER_API GerThreadPool *gerPmtgCreate(int requestedThreadCount /* clamped to GER_MAX_CORES, 0 = auto-detect */);
GER_API void            gerPmtgDestroy(GerThreadPool *pool);
GER_API int             gerPmtgGetThreadCount(const GerThreadPool *pool);

/* Splits [0, totalRows) into pool->threadCount horizontal bands and
 * dispatches jobFn(threadIndex, y0, y1, userData) on each worker.
 * Blocks the calling (main) thread until all workers finish the frame's
 * job, then returns. Safe to call once per frame; does not allocate. */
GER_API GerResult gerPmtgDispatchRows(GerThreadPool *pool, int totalRows,
                                       GerJobFn jobFn, void *userData);

/* Generic job-array dispatch: each of the `jobCount` jobs gets pulled by
 * whichever worker thread is free first (work-stealing queue via atomic
 * counter). Use for irregular workloads like per-triangle binning. */
GER_API GerResult gerPmtgDispatchJobs(GerThreadPool *pool, int jobCount,
                                       GerJobFn jobFn, void *userData);

GER_API int gerSysGetLogicalCoreCount(void);

/* ----------------------------------------------------------------------
 * FRM: frame timing
 * ---------------------------------------------------------------------- */
typedef struct GerFrameTimer {
    double  lastTime;
    double  accumTime;
    int     accumFrames;
    double  fps;
    double  deltaTime;
    uint64_t frameIndex;
} GerFrameTimer;

GER_API void   gerFrmInit(GerFrameTimer *timer);
GER_API void   gerFrmBeginFrame(GerFrameTimer *timer);
GER_API void   gerFrmEndFrame(GerFrameTimer *timer);   /* call once per frame, updates fps every ~0.5s */
GER_API double gerFrmGetFps(const GerFrameTimer *timer);
GER_API double gerFrmGetDeltaTime(const GerFrameTimer *timer);
GER_API uint64_t gerFrmGetFrameIndex(const GerFrameTimer *timer);

/* ----------------------------------------------------------------------
 * Atomic helpers (thin wrappers over Win32 Interlocked* for portability
 * within the GERECT codebase)
 * ---------------------------------------------------------------------- */
GER_API LONG gerAtomicIncrement(volatile LONG *value);
GER_API LONG gerAtomicCompareExchange(volatile LONG *dest, LONG exchange, LONG comparand);

#ifdef __cplusplus
}
#endif

#endif /* GERSYS64_H */
