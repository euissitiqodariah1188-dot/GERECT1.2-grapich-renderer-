/* =====================================================================
 * GERECT 1.2 - Light System Implementation (Phong Shading)
 * =====================================================================
 */
#include "ger3d/gerlight.h"
#include <math.h>

/* -----------------------------------------------------------------------
 * Preset constructors
 * ----------------------------------------------------------------------- */
GerLight gerLightMakeDirectional(GerVec3 dir, GerVec3 diffuse, float intensity) {
    GerLight l;
    memset(&l, 0, sizeof(l));
    l.type = GER_LIGHT_DIRECTIONAL;
    l.enabled = 1;
    l.direction = gerVec3Normalize(dir);
    l.colorDiffuse = diffuse;
    l.colorAmbient = gerVec3Make(0.05f, 0.05f, 0.05f);
    l.colorSpecular = gerVec3Make(1.0f, 1.0f, 1.0f);
    l.intensity = intensity;
    l.attConstant = 1.0f;
    l.castShadow = 0;
    return l;
}

GerLight gerLightMakePoint(GerVec3 pos, GerVec3 diffuse, float intensity,
                            float attLin, float attQuad) {
    GerLight l;
    memset(&l, 0, sizeof(l));
    l.type = GER_LIGHT_POINT;
    l.enabled = 1;
    l.position = pos;
    l.direction = gerVec3Make(0,-1,0);
    l.colorDiffuse = diffuse;
    l.colorAmbient = gerVec3Make(0.0f, 0.0f, 0.0f);
    l.colorSpecular = gerVec3Make(1.0f, 1.0f, 1.0f);
    l.intensity = intensity;
    l.attConstant = 1.0f;
    l.attLinear = attLin;
    l.attQuadratic = attQuad;
    l.castShadow = 0;
    return l;
}

GerLight gerLightMakeSpot(GerVec3 pos, GerVec3 dir, GerVec3 diffuse,
                           float intensity, float innerDeg, float outerDeg) {
    GerLight l;
    memset(&l, 0, sizeof(l));
    l.type = GER_LIGHT_SPOT;
    l.enabled = 1;
    l.position = pos;
    l.direction = gerVec3Normalize(dir);
    l.colorDiffuse = diffuse;
    l.colorAmbient = gerVec3Make(0.0f, 0.0f, 0.0f);
    l.colorSpecular = gerVec3Make(1.0f, 1.0f, 1.0f);
    l.intensity = intensity;
    l.attConstant = 1.0f;
    l.attLinear = 0.09f;
    l.attQuadratic = 0.032f;
    l.spotInnerAngle = (float)GER_DEG2RAD(innerDeg);
    l.spotOuterAngle = (float)GER_DEG2RAD(outerDeg);
    l.castShadow = 0;
    return l;
}

GerLight gerLightMakeAmbient(GerVec3 color, float intensity) {
    GerLight l;
    memset(&l, 0, sizeof(l));
    l.type = GER_LIGHT_AMBIENT;
    l.enabled = 1;
    l.colorAmbient = color;
    l.intensity = intensity;
    return l;
}

/* -----------------------------------------------------------------------
 * GerLightSystem lifecycle
 * ----------------------------------------------------------------------- */
GerResult gerLightSystemInit(GerLightSystem *ls) {
    if (!ls) return GER_ERR_NULLPTR;
    memset(ls, 0, sizeof(GerLightSystem));
    ls->initialized = 1;
    return GER_OK;
}

void gerLightSystemDestroy(GerLightSystem *ls) {
    if (!ls || !ls->initialized) return;
    int i;
    for (i = 0; i < GER_MAX_LIGHTS; i++) {
        gerShadowMapDestroy(&ls->shadowMaps[i]);
    }
    memset(ls, 0, sizeof(GerLightSystem));
}

int gerLightAdd(GerLightSystem *ls, GerLight light) {
    if (!ls || ls->lightCount >= GER_MAX_LIGHTS) return -1;
    int idx = ls->lightCount++;
    ls->lights[idx] = light;
    if (light.castShadow) {
        gerShadowMapInit(&ls->shadowMaps[idx]);
    }
    return idx;
}

void gerLightRemove(GerLightSystem *ls, int index) {
    if (!ls || index < 0 || index >= ls->lightCount) return;
    gerShadowMapDestroy(&ls->shadowMaps[index]);
    /* compact array */
    int i;
    for (i = index; i < ls->lightCount - 1; i++) {
        ls->lights[i] = ls->lights[i+1];
        ls->shadowMaps[i] = ls->shadowMaps[i+1];
    }
    ls->lightCount--;
    /* zero the vacated last slot */
    memset(&ls->shadowMaps[ls->lightCount], 0, sizeof(GerShadowMap));
}

GerLight *gerLightGet(GerLightSystem *ls, int index) {
    if (!ls || index < 0 || index >= ls->lightCount) return NULL;
    return &ls->lights[index];
}

/* -----------------------------------------------------------------------
 * Phong shading per-fragment
 * ----------------------------------------------------------------------- */
GerColor gerLightSystemShade(
    const GerLightSystem *ls,
    GerVec3 worldPos,
    GerVec3 worldNormal,
    GerVec3 viewDir,
    GerVec3 matKa,
    GerVec3 matKd,
    GerVec3 matKs,
    float   matNs,
    float   baseAlpha)
{
    GerVec3 result = gerVec3Make(0,0,0);
    worldNormal = gerVec3Normalize(worldNormal);

    int li;
    for (li = 0; li < ls->lightCount; li++) {
        const GerLight *light = &ls->lights[li];
        if (!light->enabled) continue;

        /* -- ambient light -- */
        if (light->type == GER_LIGHT_AMBIENT) {
            GerVec3 amb = gerVec3Make(
                light->colorAmbient.x * matKa.x * light->intensity,
                light->colorAmbient.y * matKa.y * light->intensity,
                light->colorAmbient.z * matKa.z * light->intensity
            );
            result = gerVec3Add(result, amb);
            continue;
        }

        /* -- light direction and attenuation -- */
        GerVec3 toLight;
        float attenuation = 1.0f;
        float spotFactor  = 1.0f;

        if (light->type == GER_LIGHT_DIRECTIONAL) {
            toLight = gerVec3Scale(light->direction, -1.0f); /* dir points from light TO scene */
        } else {
            GerVec3 diff = gerVec3Sub(light->position, worldPos);
            float dist = gerVec3Length(diff);
            toLight = dist > 1e-6f ? gerVec3Scale(diff, 1.0f/dist) : gerVec3Make(0,1,0);
            float denom = light->attConstant
                        + light->attLinear    * dist
                        + light->attQuadratic * dist * dist;
            attenuation = (denom > 1e-6f) ? (1.0f / denom) : 0.0f;

            /* spotlight cone factor */
            if (light->type == GER_LIGHT_SPOT) {
                GerVec3 spotDir = gerVec3Normalize(light->direction);
                float cosTheta = gerVec3Dot(gerVec3Scale(toLight,-1.0f), spotDir);
                float cosInner = cosf(light->spotInnerAngle);
                float cosOuter = cosf(light->spotOuterAngle);
                float denom2 = cosInner - cosOuter;
                if (denom2 < 1e-6f) {
                    spotFactor = cosTheta > cosOuter ? 1.0f : 0.0f;
                } else {
                    spotFactor = (cosTheta - cosOuter) / denom2;
                    if (spotFactor < 0.0f) spotFactor = 0.0f;
                    if (spotFactor > 1.0f) spotFactor = 1.0f;
                }
            }
        }

        float combinedAtt = attenuation * spotFactor * light->intensity;
        if (combinedAtt < 1e-6f) continue;

        /* -- shadow test -- */
        float shadowFactor = 1.0f;
        if (light->castShadow && ls->shadowMaps[li].initialized) {
            shadowFactor = gerShadowMapSample(&ls->shadowMaps[li], worldPos, 0.003f);
        }
        if (shadowFactor < 1e-6f) {
            /* still add ambient contribution even in shadow */
            GerVec3 amb = gerVec3Make(
                light->colorAmbient.x * matKa.x,
                light->colorAmbient.y * matKa.y,
                light->colorAmbient.z * matKa.z
            );
            result = gerVec3Add(result, gerVec3Scale(amb, combinedAtt));
            continue;
        }

        /* -- ambient component -- */
        GerVec3 ambient = gerVec3Make(
            light->colorAmbient.x * matKa.x,
            light->colorAmbient.y * matKa.y,
            light->colorAmbient.z * matKa.z
        );

        /* -- diffuse (Lambertian) -- */
        float NdotL = gerVec3Dot(worldNormal, toLight);
        if (NdotL < 0.0f) NdotL = 0.0f;
        GerVec3 diffuse = gerVec3Make(
            light->colorDiffuse.x * matKd.x * NdotL,
            light->colorDiffuse.y * matKd.y * NdotL,
            light->colorDiffuse.z * matKd.z * NdotL
        );

        /* -- specular (Phong reflection) -- */
        GerVec3 spec = gerVec3Make(0,0,0);
        if (NdotL > 0.0f && matNs > 0.0f) {
            GerVec3 reflDir = gerVec3Sub(
                gerVec3Scale(worldNormal, 2.0f * NdotL), toLight
            );
            float RdotV = gerVec3Dot(gerVec3Normalize(reflDir),
                                      gerVec3Normalize(viewDir));
            if (RdotV > 0.0f) {
                float specPow = powf(RdotV, matNs);
                spec = gerVec3Make(
                    light->colorSpecular.x * matKs.x * specPow,
                    light->colorSpecular.y * matKs.y * specPow,
                    light->colorSpecular.z * matKs.z * specPow
                );
            }
        }

        GerVec3 contrib = gerVec3Add(
            ambient,
            gerVec3Scale(gerVec3Add(diffuse, spec), shadowFactor)
        );
        result = gerVec3Add(result, gerVec3Scale(contrib, combinedAtt));
    }

    /* clamp */
    if (result.x > 1.0f) result.x = 1.0f;
    if (result.y > 1.0f) result.y = 1.0f;
    if (result.z > 1.0f) result.z = 1.0f;

    uint8_t r = (uint8_t)(result.x * 255.0f);
    uint8_t g = (uint8_t)(result.y * 255.0f);
    uint8_t b = (uint8_t)(result.z * 255.0f);
    uint8_t a = (uint8_t)(baseAlpha * 255.0f);
    return GER_COLOR_RGBA(r, g, b, a);
}
