/* =====================================================================
 * GERECT 1.2 - test_obj.c
 *
 * Demo standalone: .exe tidak butuh file apapun.
 * Model cube dan sphere sudah ter-embed di binary via gerbed.h.
 *
 * Kalau punya file .obj sendiri:
 *   1. Jalankan: python tools/gerEmbed.py namafile.obj
 *   2. #include header yang dihasilkan
 *   3. Ganti GER_EMBED_CUBE_OBJ dengan macro dari header tersebut
 *
 * Kontrol:
 *   1 / 2 - ganti model (cube / sphere)
 *   W A S D - putar model
 *   F - toggle wireframe
 *   ESC - keluar
 * =====================================================================
 */
#include "ger/ger.h"
#include "gersys64/gersys64.h"
#include "ger3d/ger3d.h"
#include "ger3d/gerlight.h"
#include "gerui/gerui.h"
#include "gerinput/gerinput.h"
#include "gerbed/gerbed.h"   /* <- built-in embedded assets, zero files needed */

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE h2, LPSTR cmd, int n) {
    (void)h2; (void)n; (void)cmd;

    gerInit();

    GerScene scene;
    gerSceneInit(&scene, 1024, 768, 0);

    /* ---- Lighting ---- */
    GerLightSystem ls;
    gerLightSystemInit(&ls);

    /* Directional light dari atas-kanan, casting shadow */
    GerLight sun = gerLightMakeDirectional(
        gerVec3Make(-0.6f, -1.0f, 0.5f),
        gerVec3Make(1.0f, 0.95f, 0.85f),
        1.3f
    );
    sun.castShadow = 1;
    gerLightAdd(&ls, sun);

    /* Fill light lemah dari kiri bawah */
    gerLightAdd(&ls, gerLightMakeDirectional(
        gerVec3Make(0.8f, 0.3f, -0.5f),
        gerVec3Make(0.2f, 0.25f, 0.4f),
        0.5f
    ));

    /* Ambient biar sisi gelap tidak pitch black */
    gerLightAdd(&ls, gerLightMakeAmbient(
        gerVec3Make(0.1f, 0.1f, 0.15f), 1.0f
    ));

    gerSceneSetLightSystem(&scene, &ls);

    /* ---- Load model dari MEMORY (embedded, tidak butuh file) ---- */
    GerLayout *model = gerFugLoadObjFromMemory(
        &scene, "model",
        GER_EMBED_CUBE_OBJ, GER_EMBED_CUBE_OBJ_SIZE,
        NULL, 0, NULL
    );
    if (!model) {
        MessageBoxA(NULL, "Gagal load embedded OBJ.", "Error", MB_ICONERROR);
        gerSceneDestroy(&scene);
        gerLightSystemDestroy(&ls);
        gerShutdown();
        return 1;
    }
    model->color = GER_COLOR_RGB(180, 100, 60); /* warna coklat/terra cotta */
    model->shadeMode = GER_SHADE_GOURAUD;

    /* ---- Floor plane (pakai mesh builder bawaan, bukan OBJ) ---- */
    GerLayout *floor = gerSceneCreateLayout(&scene, "floor");
    gerLayoutSetMeshKind(&scene, floor, "plane");
    gerLayoutSetSize(floor, 6.0f, 1.0f, 6.0f);
    gerLayoutSetPos(floor, 0.0f, -1.5f, 0.0f);
    gerLayoutSetColor(floor, GER_COLOR_RGB(70, 90, 70));
    floor->shadeMode = GER_SHADE_FLAT;

    /* ---- Kamera ---- */
    scene.camera.eye    = gerVec3Make(0.0f, 1.5f, -5.0f);
    scene.camera.target = gerVec3Make(0.0f, 0.0f,  0.0f);
    scene.camera.fovYRadians = (float)GER_DEG2RAD(65.0);

    /* ---- Window ---- */
    GerWindow win;
    char title[128];
    sprintf(title, "GERECT 1.2 - OBJ Test [%d threads] | 1=Cube 2=Sphere W/A/S/D=Rotate F=Wire ESC=Quit",
            gerPmtgGetThreadCount(scene.threadPool));
    gerWindowCreate(&win, hInstance, title, 1024, 768);
    gerWindowBindScene(&win, &scene);

    float rotX = 0.0f, rotY = 0.0f;
    int   wireframe = 0;
    int   curModel = 0; /* 0=cube, 1=sphere */
    double lastTime = gerGetTimeSeconds();

    while (gerWindowPollEvents(&win)) {
        gerWindowApplyPendingResize(&win);

        /* --- delta time --- */
        double now = gerGetTimeSeconds();
        float dt = (float)(now - lastTime);
        if (dt > 0.1f) dt = 0.1f;
        lastTime = now;

        GerInputState *inp = gerWindowGetInput(&win);
        gerInputBeginFrame(inp);

        /* ESC keluar */
        if (gerInputKeyPressed(inp, GER_KEY_ESCAPE)) break;

        /* 1/2 ganti model */
        if (gerInputKeyPressed(inp, GER_KEY_1) && curModel != 0) {
            curModel = 0;
            gerLayoutDestroy(&scene, "model");
            model = gerFugLoadObjFromMemory(&scene, "model",
                GER_EMBED_CUBE_OBJ, GER_EMBED_CUBE_OBJ_SIZE, NULL, 0, NULL);
            if (model) {
                model->color = GER_COLOR_RGB(180, 100, 60);
                model->shadeMode = wireframe ? GER_SHADE_WIREFRAME : GER_SHADE_GOURAUD;
            }
        }
        if (gerInputKeyPressed(inp, GER_KEY_2) && curModel != 1) {
            curModel = 1;
            gerLayoutDestroy(&scene, "model");
            model = gerFugLoadObjFromMemory(&scene, "model",
                GER_EMBED_SPHERE_OBJ, GER_EMBED_SPHERE_OBJ_SIZE, NULL, 0, NULL);
            if (model) {
                model->color = GER_COLOR_RGB(80, 140, 200);
                model->shadeMode = wireframe ? GER_SHADE_WIREFRAME : GER_SHADE_GOURAUD;
            }
        }

        /* F toggle wireframe */
        if (gerInputKeyPressed(inp, GER_KEY_F) && model) {
            wireframe = !wireframe;
            model->shadeMode = wireframe ? GER_SHADE_WIREFRAME : GER_SHADE_GOURAUD;
        }

        /* WASD rotate */
        if (gerInputKeyHeld(inp, GER_KEY_W)) rotX -= 60.0f * dt;
        if (gerInputKeyHeld(inp, GER_KEY_S)) rotX += 60.0f * dt;
        if (gerInputKeyHeld(inp, GER_KEY_A)) rotY -= 60.0f * dt;
        if (gerInputKeyHeld(inp, GER_KEY_D)) rotY += 60.0f * dt;

        if (model) gerLayoutSetRotation(model, rotX, rotY, 0.0f);

        /* --- Render --- */
        gerLightSystemShadowPass(&ls, &scene);
        gerSceneRenderFrame(&scene);
        gerWindowPresent(&win);

        /* Update title dengan FPS */
        static int titleTimer = 0;
        if (++titleTimer >= 30) {
            titleTimer = 0;
            char newTitle[256];
            const char *modelName = curModel == 0 ? "Cube" : "Sphere";
            sprintf(newTitle,
                "GERECT 1.2 | Model: %s | FPS: %.0f | Shadow: ON | Phong: ON | %d threads",
                modelName,
                gerFrmGetFps(&scene.frameTimer),
                gerPmtgGetThreadCount(scene.threadPool));
            SetWindowTextA(win.hwnd, newTitle);
        }

        gerSleepMs(1);
    }

    gerWindowDestroy(&win);
    gerLightSystemDestroy(&ls);
    gerSceneDestroy(&scene);
    gerShutdown();
    return 0;
}
