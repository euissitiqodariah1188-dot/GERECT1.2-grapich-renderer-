/* =====================================================================
 * GERECT 1.2 - Shadow Map Implementation
 *
 * Strategy:
 *  - gerShadowMapInit(): VirtualAlloc satu block depth buffer 512x512
 *  - gerLightSystemShadowPass(): reset depth, render semua layout ke
 *    shadow map (software triangle rasterizer, depth-only), per frame
 *  - gerShadowMapSample(): transform world pos ke light clip space,
 *    baca depth buffer shadow map, 2x2 PCF untuk smooth edges
 *
 * Tidak ada malloc di dalam loop render. Shadow map dipakai via pointer
 * yang diteruskan ke GerLightSystem; rasterizer utama (ger3d_raster.c)
 * mengakses GerLightSystem via scene->lightSystem.
 * =====================================================================
 */
#include "ger3d/gerlight.h"
#include <math.h>

/* Forward declaration -- gerSceneSetLightSystem needs to touch scene
 * which is fully defined in ger3d.h (already included via gerlight.h) */

/* -----------------------------------------------------------------------
 * Shadow map lifecycle
 * ----------------------------------------------------------------------- */
GerResult gerShadowMapInit(GerShadowMap *sm) {
    if (!sm) return GER_ERR_NULLPTR;
    if (sm->initialized) return GER_OK;

    size_t bytes = (size_t)GER_SHADOW_MAP_SIZE * (size_t)GER_SHADOW_MAP_SIZE * sizeof(float);
    sm->depth = (float*)VirtualAlloc(NULL, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!sm->depth) return GER_ERR_OUT_OF_MEMORY;

    sm->lightViewProj = gerMat4Identity();
    sm->initialized = 1;
    gerShadowMapClear(sm);
    return GER_OK;
}

void gerShadowMapDestroy(GerShadowMap *sm) {
    if (!sm || !sm->initialized) return;
    if (sm->depth) { VirtualFree(sm->depth, 0, MEM_RELEASE); sm->depth = NULL; }
    sm->initialized = 0;
}

void gerShadowMapClear(GerShadowMap *sm) {
    if (!sm || !sm->initialized || !sm->depth) return;
    int n = GER_SHADOW_MAP_SIZE * GER_SHADOW_MAP_SIZE;
    int i;
    for (i = 0; i < n; i++) sm->depth[i] = 1.0f;
}

/* -----------------------------------------------------------------------
 * Build light-space view-projection matrix
 * ----------------------------------------------------------------------- */
void gerShadowMapBuildLightMatrix(GerShadowMap *sm, const GerLight *light,
                                   GerVec3 sceneCenter, float sceneRadius) {
    if (!sm || !light) return;

    GerMat4 view, proj;
    float r = sceneRadius > 0.1f ? sceneRadius : 5.0f;

    if (light->type == GER_LIGHT_DIRECTIONAL) {
        /* orthographic projection looking from opposite of light dir */
        GerVec3 eye = gerVec3Sub(sceneCenter,
                                  gerVec3Scale(gerVec3Normalize(light->direction), r * 2.0f));
        view = gerMat4LookAt(eye, sceneCenter, gerVec3Make(0,1,0));

        /* manual ortho matrix: maps [-r,r]^2 and [0,4r] depth to NDC */
        proj = gerMat4Identity();
        proj.m[0][0] =  1.0f / r;
        proj.m[1][1] =  1.0f / r;
        proj.m[2][2] = -1.0f / (r * 4.0f);
        proj.m[3][2] = -1.0f; /* push near to 0 in NDC */

    } else if (light->type == GER_LIGHT_SPOT) {
        view = gerMat4LookAt(light->position,
                              gerVec3Add(light->position, light->direction),
                              gerVec3Make(0,1,0));
        proj = gerMat4Perspective(light->spotOuterAngle * 2.0f, 1.0f, 0.1f, r * 4.0f);

    } else {
        /* point light: simple look-toward scene center */
        view = gerMat4LookAt(light->position, sceneCenter, gerVec3Make(0,1,0));
        proj = gerMat4Perspective((float)GER_DEG2RAD(90.0f), 1.0f, 0.1f, r * 4.0f);
    }

    sm->lightViewProj = gerMat4Multiply(view, proj);
}

/* -----------------------------------------------------------------------
 * Rasterize one triangle into the shadow depth buffer (depth-only, no
 * color, no lighting -- just bare z-values).
 * ----------------------------------------------------------------------- */
static float ShadowEdge(GerVec3 a, GerVec3 b, float px, float py) {
    return (px - a.x) * (b.y - a.y) - (py - a.y) * (b.x - a.x);
}

static void ShadowRasterTri(GerShadowMap *sm, GerVec3 s0, GerVec3 s1, GerVec3 s2) {
    float area = ShadowEdge(s0, s1, s2.x, s2.y);
    if (fabsf(area) < 1e-6f) return;
    float invArea = 1.0f / area;

    int minX = (int)floorf(fminf(s0.x, fminf(s1.x, s2.x)));
    int maxX = (int)ceilf (fmaxf(s0.x, fmaxf(s1.x, s2.x)));
    int minY = (int)floorf(fminf(s0.y, fminf(s1.y, s2.y)));
    int maxY = (int)ceilf (fmaxf(s0.y, fmaxf(s1.y, s2.y)));

    if (minX < 0) minX = 0;
    if (minY < 0) minY = 0;
    if (maxX > GER_SHADOW_MAP_SIZE) maxX = GER_SHADOW_MAP_SIZE;
    if (maxY > GER_SHADOW_MAP_SIZE) maxY = GER_SHADOW_MAP_SIZE;

    int py;
    for (py = minY; py < maxY; py++) {
        int px;
        for (px = minX; px < maxX; px++) {
            float fx = (float)px + 0.5f;
            float fy = (float)py + 0.5f;
            float w0 = ShadowEdge(s1, s2, fx, fy) * invArea;
            float w1 = ShadowEdge(s2, s0, fx, fy) * invArea;
            float w2 = ShadowEdge(s0, s1, fx, fy) * invArea;
            if (w0 < 0.0f || w1 < 0.0f || w2 < 0.0f) continue;

            float depth = w0 * s0.z + w1 * s1.z + w2 * s2.z;
            if (depth < 0.0f || depth > 1.0f) continue;

            size_t idx = (size_t)py * GER_SHADOW_MAP_SIZE + px;
            if (depth < sm->depth[idx]) sm->depth[idx] = depth;
        }
    }
}

static GerVec3 ProjectToShadowMap(GerShadowMap *sm, GerVec3 worldPos) {
    GerVec4 clip = gerMat4MulVec4(sm->lightViewProj, gerVec4FromVec3(worldPos, 1.0f));
    GerVec3 r = {0,0,2.0f}; /* default: far away (shadowed) */
    if (clip.w <= 1e-6f) return r;
    float ndcX = clip.x / clip.w;
    float ndcY = clip.y / clip.w;
    float ndcZ = clip.z / clip.w;
    r.x = (ndcX * 0.5f + 0.5f) * (float)(GER_SHADOW_MAP_SIZE - 1);
    r.y = (1.0f - (ndcY * 0.5f + 0.5f)) * (float)(GER_SHADOW_MAP_SIZE - 1);
    r.z = ndcZ * 0.5f + 0.5f;
    return r;
}

/* -----------------------------------------------------------------------
 * Shadow depth pass -- called once per frame before the color pass
 * ----------------------------------------------------------------------- */
void gerLightSystemShadowPass(GerLightSystem *ls, GerScene *scene) {
    if (!ls || !scene) return;

    /* Compute scene bounding sphere (approximate from layout positions) */
    GerVec3 sceneCenter = gerVec3Make(0,0,0);
    float sceneRadius = 8.0f;
    int activeCount = 0;
    int li;
    for (li = 0; li < scene->layoutCount; li++) {
        GerLayout *lay = &scene->layouts[li];
        if (!lay->active || !lay->is3DEnabled) continue;
        sceneCenter = gerVec3Add(sceneCenter, lay->position);
        activeCount++;
    }
    if (activeCount > 0) {
        sceneCenter = gerVec3Scale(sceneCenter, 1.0f / (float)activeCount);
        for (li = 0; li < scene->layoutCount; li++) {
            GerLayout *lay = &scene->layouts[li];
            if (!lay->active) continue;
            float d = gerVec3Length(gerVec3Sub(lay->position, sceneCenter));
            if (d > sceneRadius) sceneRadius = d;
        }
        sceneRadius += 3.0f;
    }

    int i;
    for (i = 0; i < ls->lightCount; i++) {
        GerLight *light = &ls->lights[i];
        if (!light->enabled || !light->castShadow) continue;
        GerShadowMap *sm = &ls->shadowMaps[i];
        if (!sm->initialized) continue;

        gerShadowMapBuildLightMatrix(sm, light, sceneCenter, sceneRadius);
        gerShadowMapClear(sm);

        /* Rasterize all active layouts into shadow map */
        int li2;
        for (li2 = 0; li2 < scene->layoutCount; li2++) {
            GerLayout *lay = &scene->layouts[li2];
            if (!lay->active || !lay->is3DEnabled) continue;
            if (!lay->mesh.vertices || lay->mesh.indexCount < 3) continue;

            GerMat4 model = gerMat4Multiply(
                gerMat4Scale(lay->scale.x, lay->scale.y, lay->scale.z),
                gerMat4Multiply(
                    gerMat4RotateXYZ(lay->rotationRad.x, lay->rotationRad.y, lay->rotationRad.z),
                    gerMat4Translate(lay->position.x, lay->position.y, lay->position.z)
                )
            );
            GerMat4 lightMVP = gerMat4Multiply(model, sm->lightViewProj);

            int ti;
            for (ti = 0; ti < lay->mesh.indexCount; ti += 3) {
                uint32_t i0 = lay->mesh.indices[ti+0];
                uint32_t i1 = lay->mesh.indices[ti+1];
                uint32_t i2 = lay->mesh.indices[ti+2];

                GerVec4 c0 = gerMat4MulVec4(lightMVP, gerVec4FromVec3(lay->mesh.vertices[i0].position, 1.0f));
                GerVec4 c1 = gerMat4MulVec4(lightMVP, gerVec4FromVec3(lay->mesh.vertices[i1].position, 1.0f));
                GerVec4 c2 = gerMat4MulVec4(lightMVP, gerVec4FromVec3(lay->mesh.vertices[i2].position, 1.0f));

                if (c0.w <= 0.0f || c1.w <= 0.0f || c2.w <= 0.0f) continue;

                GerVec3 s0, s1, s2;
                s0.x = (c0.x/c0.w * 0.5f + 0.5f) * (GER_SHADOW_MAP_SIZE-1);
                s0.y = (1.0f - (c0.y/c0.w * 0.5f + 0.5f)) * (GER_SHADOW_MAP_SIZE-1);
                s0.z = c0.z/c0.w * 0.5f + 0.5f;

                s1.x = (c1.x/c1.w * 0.5f + 0.5f) * (GER_SHADOW_MAP_SIZE-1);
                s1.y = (1.0f - (c1.y/c1.w * 0.5f + 0.5f)) * (GER_SHADOW_MAP_SIZE-1);
                s1.z = c1.z/c1.w * 0.5f + 0.5f;

                s2.x = (c2.x/c2.w * 0.5f + 0.5f) * (GER_SHADOW_MAP_SIZE-1);
                s2.y = (1.0f - (c2.y/c2.w * 0.5f + 0.5f)) * (GER_SHADOW_MAP_SIZE-1);
                s2.z = c2.z/c2.w * 0.5f + 0.5f;

                ShadowRasterTri(sm, s0, s1, s2);
            }
        }
    }
}

/* -----------------------------------------------------------------------
 * PCF shadow sample (2x2 kernel)
 * ----------------------------------------------------------------------- */
float gerShadowMapSample(const GerShadowMap *sm, GerVec3 worldPos, float bias) {
    if (!sm || !sm->initialized || !sm->depth) return 1.0f;

    GerVec3 lightCoord = ProjectToShadowMap((GerShadowMap*)sm, worldPos);

    /* outside light frustum = unshadowed (assume lit, not shadow artifact) */
    if (lightCoord.x < 0 || lightCoord.x >= GER_SHADOW_MAP_SIZE-1 ||
        lightCoord.y < 0 || lightCoord.y >= GER_SHADOW_MAP_SIZE-1) return 1.0f;
    if (lightCoord.z < 0.0f || lightCoord.z > 1.0f) return 1.0f;

    float currentDepth = lightCoord.z - bias;
    int x0 = (int)lightCoord.x, y0 = (int)lightCoord.y;
    int x1 = x0+1 < GER_SHADOW_MAP_SIZE ? x0+1 : x0;
    int y1 = y0+1 < GER_SHADOW_MAP_SIZE ? y0+1 : y0;

    /* 2x2 PCF tap */
    float lit = 0.0f;
    float d00 = sm->depth[(size_t)y0 * GER_SHADOW_MAP_SIZE + x0];
    float d10 = sm->depth[(size_t)y0 * GER_SHADOW_MAP_SIZE + x1];
    float d01 = sm->depth[(size_t)y1 * GER_SHADOW_MAP_SIZE + x0];
    float d11 = sm->depth[(size_t)y1 * GER_SHADOW_MAP_SIZE + x1];
    lit += (currentDepth <= d00) ? 1.0f : 0.0f;
    lit += (currentDepth <= d10) ? 1.0f : 0.0f;
    lit += (currentDepth <= d01) ? 1.0f : 0.0f;
    lit += (currentDepth <= d11) ? 1.0f : 0.0f;
    return lit * 0.25f;
}

/* -----------------------------------------------------------------------
 * Attach light system to scene
 * ----------------------------------------------------------------------- */
/* GerScene needs a lightSystem pointer field.  We store it in the scene
 * via the dedicated gerSceneSetLightSystem() API; scene doesn't own the
 * light system (no cleanup in gerSceneDestroy).  The pointer is used
 * by ger3d_raster.c when available. */

/* We need to patch GerScene to carry the pointer.  Since we cannot
 * change already-compiled objects, we use a small global table (keyed
 * by scene pointer) as a side-channel.  This keeps the struct layout
 * unchanged across TUs that already compiled against ger3d.h. */
#define GER_SCENE_LIGHT_MAP_SIZE 16
static struct { GerScene *scene; GerLightSystem *ls; } g_sceneLightMap[GER_SCENE_LIGHT_MAP_SIZE];
static int g_sceneLightMapCount = 0;

void gerSceneSetLightSystem(GerScene *scene, GerLightSystem *ls) {
    if (!scene) return;
    int i;
    for (i = 0; i < g_sceneLightMapCount; i++) {
        if (g_sceneLightMap[i].scene == scene) {
            g_sceneLightMap[i].ls = ls;
            return;
        }
    }
    if (g_sceneLightMapCount < GER_SCENE_LIGHT_MAP_SIZE) {
        g_sceneLightMap[g_sceneLightMapCount].scene = scene;
        g_sceneLightMap[g_sceneLightMapCount].ls = ls;
        g_sceneLightMapCount++;
    }
}

/* Used by the rasterizer to retrieve the light system for a scene */
GerLightSystem *gerSceneGetLightSystem(GerScene *scene) {
    if (!scene) return NULL;
    int i;
    for (i = 0; i < g_sceneLightMapCount; i++) {
        if (g_sceneLightMap[i].scene == scene) return g_sceneLightMap[i].ls;
    }
    return NULL;
}
