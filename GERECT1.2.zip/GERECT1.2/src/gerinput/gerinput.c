/* =====================================================================
 * GERECT 1.2 - Input Implementation
 * =====================================================================
 */
#include "gerinput/gerinput.h"
#include <windows.h>

void gerInputInit(GerInputState *input) {
    if (!input) return;
    memset(input, 0, sizeof(GerInputState));
}

void gerInputBeginFrame(GerInputState *input) {
    if (!input) return;

    memset(input->keyPressedThisFrame, 0, sizeof(input->keyPressedThisFrame));
    memset(input->keyReleasedThisFrame, 0, sizeof(input->keyReleasedThisFrame));
    memset(input->mousePressedThisFrame, 0, sizeof(input->mousePressedThisFrame));
    memset(input->mouseReleasedThisFrame, 0, sizeof(input->mouseReleasedThisFrame));

    if (input->hasPrevMouse) {
        input->mouseDeltaX = input->mouseX - input->prevMouseX;
        input->mouseDeltaY = input->mouseY - input->prevMouseY;
    } else {
        input->mouseDeltaX = 0;
        input->mouseDeltaY = 0;
        input->hasPrevMouse = 1;
    }
    input->prevMouseX = input->mouseX;
    input->prevMouseY = input->mouseY;
    input->mouseWheelDelta = 0;
}

/* ---------------------------------------------------------------------
 * VK_* -> GerKey mapping table. Built once at first use (lazy static
 * init), not per-call -- avoids any per-frame cost and any dynamic
 * allocation.
 * --------------------------------------------------------------------- */
GerKey gerInputVKToGerKey(unsigned int vk) {
    switch (vk) {
        case 'A': return GER_KEY_A; case 'B': return GER_KEY_B;
        case 'C': return GER_KEY_C; case 'D': return GER_KEY_D;
        case 'E': return GER_KEY_E; case 'F': return GER_KEY_F;
        case 'G': return GER_KEY_G; case 'H': return GER_KEY_H;
        case 'I': return GER_KEY_I; case 'J': return GER_KEY_J;
        case 'K': return GER_KEY_K; case 'L': return GER_KEY_L;
        case 'M': return GER_KEY_M; case 'N': return GER_KEY_N;
        case 'O': return GER_KEY_O; case 'P': return GER_KEY_P;
        case 'Q': return GER_KEY_Q; case 'R': return GER_KEY_R;
        case 'S': return GER_KEY_S; case 'T': return GER_KEY_T;
        case 'U': return GER_KEY_U; case 'V': return GER_KEY_V;
        case 'W': return GER_KEY_W; case 'X': return GER_KEY_X;
        case 'Y': return GER_KEY_Y; case 'Z': return GER_KEY_Z;

        case '0': return GER_KEY_0; case '1': return GER_KEY_1;
        case '2': return GER_KEY_2; case '3': return GER_KEY_3;
        case '4': return GER_KEY_4; case '5': return GER_KEY_5;
        case '6': return GER_KEY_6; case '7': return GER_KEY_7;
        case '8': return GER_KEY_8; case '9': return GER_KEY_9;

        case VK_SPACE: return GER_KEY_SPACE;
        case VK_RETURN: return GER_KEY_ENTER;
        case VK_ESCAPE: return GER_KEY_ESCAPE;
        case VK_TAB: return GER_KEY_TAB;
        case VK_BACK: return GER_KEY_BACKSPACE;
        case VK_SHIFT: case VK_LSHIFT: case VK_RSHIFT: return GER_KEY_SHIFT;
        case VK_CONTROL: case VK_LCONTROL: case VK_RCONTROL: return GER_KEY_CTRL;
        case VK_MENU: case VK_LMENU: case VK_RMENU: return GER_KEY_ALT;

        case VK_LEFT: return GER_KEY_LEFT;
        case VK_RIGHT: return GER_KEY_RIGHT;
        case VK_UP: return GER_KEY_UP;
        case VK_DOWN: return GER_KEY_DOWN;

        case VK_F1: return GER_KEY_F1; case VK_F2: return GER_KEY_F2;
        case VK_F3: return GER_KEY_F3; case VK_F4: return GER_KEY_F4;
        case VK_F5: return GER_KEY_F5; case VK_F6: return GER_KEY_F6;
        case VK_F7: return GER_KEY_F7; case VK_F8: return GER_KEY_F8;
        case VK_F9: return GER_KEY_F9; case VK_F10: return GER_KEY_F10;
        case VK_F11: return GER_KEY_F11; case VK_F12: return GER_KEY_F12;

        default: return GER_KEY_UNKNOWN;
    }
}

void gerInputOnKeyDown(GerInputState *input, unsigned int vkCode) {
    if (!input) return;
    GerKey key = gerInputVKToGerKey(vkCode);
    if (key == GER_KEY_UNKNOWN) return;
    if (!input->keyDown[key]) {
        input->keyPressedThisFrame[key] = 1;
    }
    input->keyDown[key] = 1;
}

void gerInputOnKeyUp(GerInputState *input, unsigned int vkCode) {
    if (!input) return;
    GerKey key = gerInputVKToGerKey(vkCode);
    if (key == GER_KEY_UNKNOWN) return;
    input->keyDown[key] = 0;
    input->keyReleasedThisFrame[key] = 1;
}

void gerInputOnMouseMove(GerInputState *input, int x, int y) {
    if (!input) return;
    input->mouseX = x;
    input->mouseY = y;
}

void gerInputOnMouseButtonDown(GerInputState *input, GerMouseButton button) {
    if (!input || button < 0 || button >= GER_MOUSE_BUTTON_COUNT) return;
    if (!input->mouseDown[button]) {
        input->mousePressedThisFrame[button] = 1;
    }
    input->mouseDown[button] = 1;
}

void gerInputOnMouseButtonUp(GerInputState *input, GerMouseButton button) {
    if (!input || button < 0 || button >= GER_MOUSE_BUTTON_COUNT) return;
    input->mouseDown[button] = 0;
    input->mouseReleasedThisFrame[button] = 1;
}

void gerInputOnMouseWheel(GerInputState *input, int delta) {
    if (!input) return;
    input->mouseWheelDelta += delta;
}

int gerInputKeyHeld(const GerInputState *input, GerKey key) {
    if (!input || key < 0 || key >= GER_KEY_COUNT) return 0;
    return input->keyDown[key];
}

int gerInputKeyPressed(const GerInputState *input, GerKey key) {
    if (!input || key < 0 || key >= GER_KEY_COUNT) return 0;
    return input->keyPressedThisFrame[key];
}

int gerInputKeyReleased(const GerInputState *input, GerKey key) {
    if (!input || key < 0 || key >= GER_KEY_COUNT) return 0;
    return input->keyReleasedThisFrame[key];
}

int gerInputMouseHeld(const GerInputState *input, GerMouseButton button) {
    if (!input || button < 0 || button >= GER_MOUSE_BUTTON_COUNT) return 0;
    return input->mouseDown[button];
}

int gerInputMousePressed(const GerInputState *input, GerMouseButton button) {
    if (!input || button < 0 || button >= GER_MOUSE_BUTTON_COUNT) return 0;
    return input->mousePressedThisFrame[button];
}

int gerInputMouseReleased(const GerInputState *input, GerMouseButton button) {
    if (!input || button < 0 || button >= GER_MOUSE_BUTTON_COUNT) return 0;
    return input->mouseReleasedThisFrame[button];
}

GerVec2 gerInputGetMousePos(const GerInputState *input) {
    GerVec2 v = { 0.0f, 0.0f };
    if (!input) return v;
    v.x = (float)input->mouseX;
    v.y = (float)input->mouseY;
    return v;
}

GerVec2 gerInputGetMouseDelta(const GerInputState *input) {
    GerVec2 v = { 0.0f, 0.0f };
    if (!input) return v;
    v.x = (float)input->mouseDeltaX;
    v.y = (float)input->mouseDeltaY;
    return v;
}

int gerInputGetMouseWheelDelta(const GerInputState *input) {
    return input ? input->mouseWheelDelta : 0;
}
