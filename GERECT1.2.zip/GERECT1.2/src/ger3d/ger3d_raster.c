/* =====================================================================
 * GERECT 1.2 - Rasterizer + Render Pipeline
 *
 * Pipeline (matches the described data flow):
 *   FuG (load) -> SSM (this file builds the transformed/clipped
 *   triangle list) -> FRM (frame timing wraps the call) -> PMTG
 *   (rows of the framebuffer are rasterized in parallel across up to
 *   8 worker threads) -> done.
 *
 * Strategy: a "bin" pass on the main thread transforms all active
 * layouts' triangles into screen space ONCE per frame into a
 * preallocated triangle buffer (no malloc - lives in GerScene's pool,
 * sized at init). Then PMTG splits the framebuffer into horizontal
 * row bands; each worker thread rasterizes only the triangles
 * overlapping its band, scanning the precomputed triangle buffer
 * (read-only, so no locking needed across threads).
 * =====================================================================
 */
#include "ger3d/ger3d.h"

/* ----------------------------------------------------------------------
 * Screen-space triangle: precomputed once per frame on the main thread,
 * then consumed read-only by all PMTG worker threads.
 * ---------------------------------------------------------------------- */
typedef struct GerScreenTri {
    GerVec3 p[3];      /* screen-space x,y + view-space depth in z (for interpolation) */
    GerVec2 uv[3];
    GerVec3 normal[3];
    float   minY, maxY;
    float   minX, maxX;
    GerColor baseColor;
    GerShadeMode shadeMode;
    const GerTexture *texture;
} GerScreenTri;

#define GER_MAX_SCREEN_TRIS (GER_MESH_MAX_INDICES / 3 * 8)

typedef struct GerBatchLine {
    GerVec3 a, b;
    GerColor color;
} GerBatchLine;

typedef struct GerRenderBatch {
    GerScreenTri *tris;
    int           triCount;
    int           triCapacity;

    /* line-mode draw list (for "line" layout kind, drawn via Bresenham
     * rather than the triangle rasterizer) */
    GerBatchLine *lines;
    int           lineCount;
    int           lineCapacity;

    GerFramebuffer *fb;
} GerRenderBatch;

/* Persistent batch storage, sized once. Avoids per-frame malloc. */
static GerScreenTri g_triStorage[GER_MAX_SCREEN_TRIS];
static GerBatchLine g_lineStorage[GER_MAX_LAYOUTS];
static GerRenderBatch g_batch;
static int g_batchInitialized = 0;

static void GerEnsureBatchInit(void) {
    if (g_batchInitialized) return;
    g_batch.tris = g_triStorage;
    g_batch.triCapacity = GER_MAX_SCREEN_TRIS;
    g_batch.lines = g_lineStorage;
    g_batch.lineCapacity = GER_MAX_LAYOUTS;
    g_batchInitialized = 1;
}

/* ----------------------------------------------------------------------
 * Vertex transform helpers
 * ---------------------------------------------------------------------- */
static GerMat4 GerLayoutModelMatrix(const GerLayout *layout) {
    GerMat4 s = gerMat4Scale(layout->scale.x, layout->scale.y, layout->scale.z);
    GerMat4 r = gerMat4RotateXYZ(layout->rotationRad.x, layout->rotationRad.y, layout->rotationRad.z);
    GerMat4 t = gerMat4Translate(layout->position.x, layout->position.y, layout->position.z);
    GerMat4 sr = gerMat4Multiply(s, r);
    return gerMat4Multiply(sr, t);
}

static int GerProjectToScreen(GerVec3 worldPos, GerMat4 viewProj, int screenW, int screenH,
                               GerVec3 *outScreen /* x,y = pixel coords, z = view depth 0..1 */) {
    GerVec4 clip = gerMat4MulVec4(viewProj, gerVec4FromVec3(worldPos, 1.0f));
    if (clip.w <= 0.0001f) return 0; /* behind camera */

    float ndcX = clip.x / clip.w;
    float ndcY = clip.y / clip.w;
    float ndcZ = clip.z / clip.w;

    outScreen->x = (ndcX * 0.5f + 0.5f) * (float)screenW;
    outScreen->y = (1.0f - (ndcY * 0.5f + 0.5f)) * (float)screenH;
    outScreen->z = ndcZ * 0.5f + 0.5f; /* 0 = near, 1 = far */
    return 1;
}

/* ----------------------------------------------------------------------
 * Binning pass (main thread, once per frame): transform all layouts'
 * geometry into the persistent screen-space triangle/line buffers.
 * ---------------------------------------------------------------------- */
static void GerBinScene(GerScene *scene) {
    GerEnsureBatchInit();
    g_batch.triCount = 0;
    g_batch.lineCount = 0;
    g_batch.fb = &scene->framebuffer;

    float aspect = (float)scene->framebuffer.width / (float)scene->framebuffer.height;
    GerMat4 view = gerCameraGetView(&scene->camera);
    GerMat4 proj = gerCameraGetProjection(&scene->camera, aspect);
    GerMat4 viewProj = gerMat4Multiply(view, proj);

    int li;
    for (li = 0; li < scene->layoutCount; li++) {
        GerLayout *layout = &scene->layouts[li];
        if (!layout->active || !layout->is3DEnabled) continue;
        if (!layout->mesh.vertices || layout->mesh.vertexCount == 0) continue;

        GerMat4 model = GerLayoutModelMatrix(layout);
        GerMat4 mvp = gerMat4Multiply(model, viewProj);

        /* line-list mesh (indexCount == 2): draw as a screen-space line */
        if (layout->mesh.indexCount == 2 && layout->mesh.vertexCount == 2) {
            if (g_batch.lineCount >= g_batch.lineCapacity) continue;
            GerVec3 sa, sb;
            GerVec3 wa = layout->mesh.vertices[0].position;
            GerVec3 wb = layout->mesh.vertices[1].position;
            int okA = GerProjectToScreen(wa, mvp, scene->framebuffer.width, scene->framebuffer.height, &sa);
            int okB = GerProjectToScreen(wb, mvp, scene->framebuffer.width, scene->framebuffer.height, &sb);
            if (okA && okB) {
                g_batch.lines[g_batch.lineCount].a = sa;
                g_batch.lines[g_batch.lineCount].b = sb;
                g_batch.lines[g_batch.lineCount].color = layout->color;
                g_batch.lineCount++;
            }
            continue;
        }

        /* triangle mesh: transform every triangle referenced by indices */
        int triIdx;
        int triCountThisMesh = layout->mesh.indexCount / 3;
        for (triIdx = 0; triIdx < triCountThisMesh; triIdx++) {
            if (g_batch.triCount >= g_batch.triCapacity) break;

            uint32_t i0 = layout->mesh.indices[triIdx * 3 + 0];
            uint32_t i1 = layout->mesh.indices[triIdx * 3 + 1];
            uint32_t i2 = layout->mesh.indices[triIdx * 3 + 2];

            GerVertex v0 = layout->mesh.vertices[i0];
            GerVertex v1 = layout->mesh.vertices[i1];
            GerVertex v2 = layout->mesh.vertices[i2];

            GerVec3 s0, s1, s2;
            int ok0 = GerProjectToScreen(v0.position, mvp, scene->framebuffer.width, scene->framebuffer.height, &s0);
            int ok1 = GerProjectToScreen(v1.position, mvp, scene->framebuffer.width, scene->framebuffer.height, &s1);
            int ok2 = GerProjectToScreen(v2.position, mvp, scene->framebuffer.width, scene->framebuffer.height, &s2);
            if (!ok0 || !ok1 || !ok2) continue; /* simple near-plane reject; full clipping omitted by design scope */

            GerScreenTri *tri = &g_batch.tris[g_batch.triCount++];
            tri->p[0] = s0; tri->p[1] = s1; tri->p[2] = s2;
            tri->uv[0] = v0.uv; tri->uv[1] = v1.uv; tri->uv[2] = v2.uv;

            /* transform normals by the model matrix's rotation part only
             * (uniform-scale assumption keeps this cheap and correct for
             * the common case; non-uniform scale skews normals slightly,
             * acceptable for this engine's lighting model) */
            GerMat4 rotOnly = gerMat4RotateXYZ(layout->rotationRad.x, layout->rotationRad.y, layout->rotationRad.z);
            GerVec4 n0 = gerMat4MulVec4(rotOnly, gerVec4FromVec3(v0.normal, 0.0f));
            GerVec4 n1 = gerMat4MulVec4(rotOnly, gerVec4FromVec3(v1.normal, 0.0f));
            GerVec4 n2 = gerMat4MulVec4(rotOnly, gerVec4FromVec3(v2.normal, 0.0f));
            tri->normal[0] = gerVec3Normalize(gerVec3Make(n0.x, n0.y, n0.z));
            tri->normal[1] = gerVec3Normalize(gerVec3Make(n1.x, n1.y, n1.z));
            tri->normal[2] = gerVec3Normalize(gerVec3Make(n2.x, n2.y, n2.z));

            tri->minY = s0.y; tri->maxY = s0.y;
            if (s1.y < tri->minY) tri->minY = s1.y;
            if (s1.y > tri->maxY) tri->maxY = s1.y;
            if (s2.y < tri->minY) tri->minY = s2.y;
            if (s2.y > tri->maxY) tri->maxY = s2.y;

            tri->minX = s0.x; tri->maxX = s0.x;
            if (s1.x < tri->minX) tri->minX = s1.x;
            if (s1.x > tri->maxX) tri->maxX = s1.x;
            if (s2.x < tri->minX) tri->minX = s2.x;
            if (s2.x > tri->maxX) tri->maxX = s2.x;

            tri->baseColor = layout->color;
            tri->shadeMode = layout->shadeMode;
            tri->texture = layout->texture;
        }
    }
}

/* ----------------------------------------------------------------------
 * Per-tile triangle rasterization (runs on a PMTG worker thread for
 * the row band [y0, y1)). Reads g_batch (read-only during this phase),
 * writes only into its own row band of the framebuffer/zbuffer.
 * ---------------------------------------------------------------------- */
static float GerEdgeFunction(GerVec3 a, GerVec3 b, float px, float py) {
    return (px - a.x) * (b.y - a.y) - (py - a.y) * (b.x - a.x);
}

static const GerCompiledEffectTable *g_activeEffectTable = NULL;
static GerVec3 g_lightDir; /* simple fixed directional light, world-ish space */

static void GerRasterizeTrianglesInRowBand(int threadIndex, int y0, int y1, void *userData) {
    (void)threadIndex;
    GerFramebuffer *fb = (GerFramebuffer *)userData;

    int t;
    for (t = 0; t < g_batch.triCount; t++) {
        GerScreenTri *tri = &g_batch.tris[t];

        int triMinY = (int)floorf(tri->minY);
        int triMaxY = (int)ceilf(tri->maxY);
        if (triMaxY < y0 || triMinY >= y1) continue; /* triangle doesn't touch this band */

        int clampMinY = triMinY < y0 ? y0 : triMinY;
        int clampMaxY = triMaxY > y1 ? y1 : triMaxY;
        int clampMinX = (int)floorf(tri->minX);
        int clampMaxX = (int)ceilf(tri->maxX);
        if (clampMinX < 0) clampMinX = 0;
        if (clampMaxX > fb->width) clampMaxX = fb->width;
        if (clampMinY < 0) clampMinY = 0;
        if (clampMaxY > fb->height) clampMaxY = fb->height;

        GerVec3 p0 = tri->p[0], p1 = tri->p[1], p2 = tri->p[2];
        float area = GerEdgeFunction(p0, p1, p2.x, p2.y);
        if (fabsf(area) < 1e-6f) continue;
        float invArea = 1.0f / area;

        GerPixelShaderFn shader = g_activeEffectTable->shaders[tri->shadeMode];

        int py;
        for (py = clampMinY; py < clampMaxY; py++) {
            int px;
            for (px = clampMinX; px < clampMaxX; px++) {
                float fx = (float)px + 0.5f;
                float fy = (float)py + 0.5f;

                float w0 = GerEdgeFunction(p1, p2, fx, fy) * invArea;
                float w1 = GerEdgeFunction(p2, p0, fx, fy) * invArea;
                float w2 = GerEdgeFunction(p0, p1, fx, fy) * invArea;

                if (w0 < 0.0f || w1 < 0.0f || w2 < 0.0f) continue;

                float depth = w0 * p0.z + w1 * p1.z + w2 * p2.z;
                size_t pixelIndex = (size_t)py * fb->width + px;

                if (depth < 0.0f || depth > 1.0f) continue;
                if (depth >= fb->depthBuffer[pixelIndex]) continue; /* z-test */

                float u = w0 * tri->uv[0].x + w1 * tri->uv[1].x + w2 * tri->uv[2].x;
                float v = w0 * tri->uv[0].y + w1 * tri->uv[1].y + w2 * tri->uv[2].y;

                GerVec3 n = gerVec3Normalize(gerVec3Add(
                    gerVec3Add(gerVec3Scale(tri->normal[0], w0), gerVec3Scale(tri->normal[1], w1)),
                    gerVec3Scale(tri->normal[2], w2)
                ));
                float ndotl = gerVec3Dot(n, g_lightDir);

                float br = (float)((tri->baseColor >> 16) & 0xFF) / 255.0f;
                float bg = (float)((tri->baseColor >> 8) & 0xFF) / 255.0f;
                float bb = (float)(tri->baseColor & 0xFF) / 255.0f;
                float ba = (float)((tri->baseColor >> 24) & 0xFF) / 255.0f;

                GerColor finalColor = shader(br, bg, bb, ba, u, v, tri->texture, ndotl);

                fb->depthBuffer[pixelIndex] = depth;
                fb->colorBuffer[pixelIndex] = finalColor;
            }
        }
    }
}

/* ----------------------------------------------------------------------
 * Line rasterization: simple, runs once on the main thread after the
 * parallel triangle pass (lines are typically few -- gizmos, debug
 * axes, the gerDL3d "garis" example -- so parallelizing them adds
 * overhead without benefit).
 * ---------------------------------------------------------------------- */
static void GerDrawLineBresenham(GerFramebuffer *fb, GerVec3 a, GerVec3 b, GerColor color) {
    int x0 = (int)(a.x + 0.5f), y0 = (int)(a.y + 0.5f);
    int x1 = (int)(b.x + 0.5f), y1 = (int)(b.y + 0.5f);

    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy;

    for (;;) {
        gerFramebufferSetPixel(fb, x0, y0, color);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}

/* ----------------------------------------------------------------------
 * Full frame render: FuG (assumed already loaded) -> SSM bin -> FRM
 * timing -> PMTG parallel rasterize -> line overlay -> done.
 * ---------------------------------------------------------------------- */
void gerSceneRenderFrame(GerScene *scene) {
    if (!scene) return;

    gerFrmBeginFrame(&scene->frameTimer);

    gerFramebufferClear(&scene->framebuffer, GER_COLOR_RGB(20, 20, 28));

    EnterCriticalSection(&scene->sceneLock);
    GerBinScene(scene);
    LeaveCriticalSection(&scene->sceneLock);

    g_activeEffectTable = &scene->effects;
    g_lightDir = gerVec3Normalize(gerVec3Make(0.4f, 0.8f, -0.4f));

    /* PMTG: dispatch the framebuffer's rows across up to 8 worker
     * threads. Each worker scans the read-only triangle batch and
     * writes only to pixels in its own row range -- no contention. */
    gerPmtgDispatchRows(scene->threadPool, scene->framebuffer.height,
                         GerRasterizeTrianglesInRowBand, &scene->framebuffer);

    /* Lines drawn after triangles, unlit, on top (typical debug/gizmo
       behavior); cheap enough to stay single-threaded. */
    int i;
    for (i = 0; i < g_batch.lineCount; i++) {
        GerDrawLineBresenham(&scene->framebuffer,
                              g_batch.lines[i].a, g_batch.lines[i].b,
                              g_batch.lines[i].color);
    }

    gerFrmEndFrame(&scene->frameTimer);
}
