/* =====================================================================
 * GERECT 1.2 - Win32 Window + DIB Blit Implementation
 *
 * Uses CreateDIBSection so the framebuffer can be presented via plain
 * GDI BitBlt -- no OpenGL, SDL, SFML, or DirectX anywhere in this file.
 * =====================================================================
 */
#include "gerui/gerui.h"

#define GER_WINDOW_CLASS_NAME "GerectWindowClass"

static LRESULT CALLBACK GerWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    GerWindow *win = (GerWindow *)GetWindowLongPtr(hwnd, GWLP_USERDATA);

    switch (msg) {
        case WM_CREATE: {
            CREATESTRUCT *cs = (CREATESTRUCT *)lParam;
            SetWindowLongPtr(hwnd, GWLP_USERDATA, (LONG_PTR)cs->lpCreateParams);
            return 0;
        }
        case WM_DESTROY: {
            if (win) win->shouldClose = 1;
            PostQuitMessage(0);
            return 0;
        }
        case WM_CLOSE: {
            if (win) win->shouldClose = 1;
            DestroyWindow(hwnd);
            return 0;
        }
        case WM_SIZE: {
            if (win) {
                int w = LOWORD(lParam);
                int h = HIWORD(lParam);
                if (w > 0 && h > 0) {
                    win->pendingWidth = w;
                    win->pendingHeight = h;
                    gerAtomicCompareExchange(&win->resizeRequested, 1, 0);
                }
            }
            return 0;
        }
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);
            if (win && win->memDC) {
                BitBlt(hdc, 0, 0, win->width, win->height, win->memDC, 0, 0, SRCCOPY);
            }
            EndPaint(hwnd, &ps); /* always paired with BeginPaint, per anti-leak rule 3 */
            return 0;
        }
        case WM_ERASEBKGND:
            return 1; /* avoid default background erase flicker; we own the whole client area */

        case WM_KEYDOWN:
        case WM_SYSKEYDOWN:
            if (win) gerInputOnKeyDown(&win->input, (unsigned int)wParam);
            return 0;

        case WM_KEYUP:
        case WM_SYSKEYUP:
            if (win) gerInputOnKeyUp(&win->input, (unsigned int)wParam);
            return 0;

        case WM_MOUSEMOVE:
            if (win) gerInputOnMouseMove(&win->input, (int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam));
            return 0;

        case WM_LBUTTONDOWN:
            if (win) { gerInputOnMouseButtonDown(&win->input, GER_MOUSE_LEFT); SetCapture(hwnd); }
            return 0;
        case WM_LBUTTONUP:
            if (win) { gerInputOnMouseButtonUp(&win->input, GER_MOUSE_LEFT); ReleaseCapture(); }
            return 0;
        case WM_RBUTTONDOWN:
            if (win) { gerInputOnMouseButtonDown(&win->input, GER_MOUSE_RIGHT); SetCapture(hwnd); }
            return 0;
        case WM_RBUTTONUP:
            if (win) { gerInputOnMouseButtonUp(&win->input, GER_MOUSE_RIGHT); ReleaseCapture(); }
            return 0;
        case WM_MBUTTONDOWN:
            if (win) { gerInputOnMouseButtonDown(&win->input, GER_MOUSE_MIDDLE); SetCapture(hwnd); }
            return 0;
        case WM_MBUTTONUP:
            if (win) { gerInputOnMouseButtonUp(&win->input, GER_MOUSE_MIDDLE); ReleaseCapture(); }
            return 0;
        case WM_MOUSEWHEEL:
            if (win) gerInputOnMouseWheel(&win->input, GET_WHEEL_DELTA_WPARAM(wParam) / WHEEL_DELTA);
            return 0;
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
}

static GerResult GerCreateDibSection(GerWindow *win, int width, int height) {
    /* tear down any previous DIB section/memDC before creating a new
     * one (only happens on resize, never per-frame) */
    if (win->dibSection) {
        DeleteObject(win->dibSection);
        win->dibSection = NULL;
    }
    if (win->memDC) {
        DeleteDC(win->memDC);
        win->memDC = NULL;
    }

    BITMAPINFO bmi;
    memset(&bmi, 0, sizeof(bmi));
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = width;
    bmi.bmiHeader.biHeight = -height; /* negative = top-down DIB, matches our framebuffer row order */
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    HDC screenDC = GetDC(NULL);
    win->memDC = CreateCompatibleDC(screenDC);
    win->dibSection = CreateDIBSection(screenDC, &bmi, DIB_RGB_COLORS, &win->dibPixels, NULL, 0);
    ReleaseDC(NULL, screenDC);

    if (!win->memDC || !win->dibSection || !win->dibPixels) {
        return GER_ERR_WIN32;
    }

    SelectObject(win->memDC, win->dibSection);
    win->width = width;
    win->height = height;
    return GER_OK;
}

GerResult gerWindowCreate(GerWindow *win, HINSTANCE hInstance,
                           const char *title, int width, int height) {
    if (!win || !hInstance || !title) return GER_ERR_NULLPTR;
    memset(win, 0, sizeof(GerWindow));
    win->hInstance = hInstance;

    WNDCLASSEX wc;
    memset(&wc, 0, sizeof(wc));
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = GerWndProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = NULL; /* we paint everything ourselves via DIB blit */
    wc.lpszClassName = GER_WINDOW_CLASS_NAME;

    /* RegisterClassEx may legitimately fail with "already registered"
     * if multiple windows are created in-process; only treat other
     * failures as fatal. */
    if (!RegisterClassEx(&wc) && GetLastError() != ERROR_CLASS_ALREADY_EXISTS) {
        return GER_ERR_WIN32;
    }

    RECT rect = { 0, 0, width, height };
    AdjustWindowRect(&rect, WS_OVERLAPPEDWINDOW, FALSE);

    win->hwnd = CreateWindowEx(
        0, GER_WINDOW_CLASS_NAME, title, WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
        rect.right - rect.left, rect.bottom - rect.top,
        NULL, NULL, hInstance, win
    );

    if (!win->hwnd) return GER_ERR_WIN32;

    GerResult r = GerCreateDibSection(win, width, height);
    if (r != GER_OK) {
        DestroyWindow(win->hwnd);
        win->hwnd = NULL;
        return r;
    }

    ShowWindow(win->hwnd, SW_SHOW);
    UpdateWindow(win->hwnd);

    win->shouldClose = 0;
    win->resizeRequested = 0;
    gerInputInit(&win->input);
    return GER_OK;
}

void gerWindowDestroy(GerWindow *win) {
    if (!win) return;

    if (win->dibSection) {
        DeleteObject(win->dibSection);
        win->dibSection = NULL;
    }
    if (win->memDC) {
        DeleteDC(win->memDC);
        win->memDC = NULL;
    }
    if (win->hwnd) {
        DestroyWindow(win->hwnd);
        win->hwnd = NULL;
    }
    win->dibPixels = NULL;
    win->boundScene = NULL;
}

void gerWindowBindScene(GerWindow *win, GerScene *scene) {
    if (!win) return;
    win->boundScene = scene;
}

int gerWindowPollEvents(GerWindow *win) {
    if (!win) return 0;

    MSG msg;
    while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
        if (msg.message == WM_QUIT) {
            win->shouldClose = 1;
            return 0;
        }
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return !win->shouldClose;
}

void gerWindowApplyPendingResize(GerWindow *win) {
    if (!win) return;
    if (gerAtomicCompareExchange(&win->resizeRequested, 0, 1) == 1) {
        int w = win->pendingWidth, h = win->pendingHeight;
        if (w > 0 && h > 0 && (w != win->width || h != win->height)) {
            GerCreateDibSection(win, w, h);
            if (win->boundScene) {
                gerFramebufferResize(&win->boundScene->framebuffer, w, h);
            }
        }
    }
}

void gerWindowPresent(GerWindow *win) {
    if (!win || !win->boundScene || !win->dibPixels) return;

    GerFramebuffer *fb = &win->boundScene->framebuffer;
    int copyW = fb->width < win->width ? fb->width : win->width;
    int copyH = fb->height < win->height ? fb->height : win->height;

    /* copy GerScene's color buffer (top-down BGRA, matching the DIB's
     * top-down layout chosen in GerCreateDibSection) directly into the
     * DIB section's pixel memory -- no intermediate allocation. */
    uint32_t *dst = (uint32_t *)win->dibPixels;
    int y;
    for (y = 0; y < copyH; y++) {
        memcpy(dst + (size_t)y * win->width,
               fb->colorBuffer + (size_t)y * fb->width,
               (size_t)copyW * sizeof(uint32_t));
    }

    InvalidateRect(win->hwnd, NULL, FALSE);
    /* Force an immediate blit too (in addition to the WM_PAINT path)
     * so the visible window updates every frame even if the message
     * queue is momentarily idle. */
    HDC hdc = GetDC(win->hwnd);
    if (hdc) {
        BitBlt(hdc, 0, 0, win->width, win->height, win->memDC, 0, 0, SRCCOPY);
        ReleaseDC(win->hwnd, hdc);
    }
}

int gerWindowShouldClose(const GerWindow *win) {
    return win ? win->shouldClose : 1;
}

GerInputState *gerWindowGetInput(GerWindow *win) {
    return win ? &win->input : NULL;
}
