/* =====================================================================
 * GERECT 1.2 - Wavefront OBJ / MTL Loader
 * =====================================================================
 * Mendukung:
 *  v   - vertex positions
 *  vt  - texture coordinates
 *  vn  - vertex normals
 *  f   - faces (triangles & quads, format: v/vt/vn  v/vt  v//vn  v)
 *  mtllib / usemtl - material references
 *  #   - komentar
 *
 * Vertex data dikumpulkan dulu ke buffer sementara (stack-allocated
 * dengan batas OBJ_TMP_MAX), lalu di-emit ke GerMesh pool saat face
 * sudah ter-resolve.  Buffer sementara di-free sebelum return.
 * =====================================================================
 */
#include "ger3d/gerlight.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define OBJ_TMP_MAX_POS   65536
#define OBJ_TMP_MAX_UV    65536
#define OBJ_TMP_MAX_NRM   65536
#define OBJ_TMP_MAX_VERTS GER_MESH_MAX_VERTICES
#define OBJ_TMP_MAX_IDX   GER_MESH_MAX_INDICES

/* -----------------------------------------------------------------------
 * MTL loader
 * ----------------------------------------------------------------------- */
GerResult gerMtlLoad(GerObjMaterialLib *lib, const char *mtlPath) {
    if (!lib || !mtlPath) return GER_ERR_NULLPTR;
    lib->count = 0;

    FILE *f = fopen(mtlPath, "r");
    if (!f) return GER_ERR_NOT_FOUND;

    GerObjMaterial *cur = NULL;
    char line[512];

    while (fgets(line, sizeof(line), f)) {
        char *p = line;
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '#' || *p == '\n' || *p == '\r') continue;

        if (strncmp(p, "newmtl", 6) == 0) {
            if (lib->count >= GER_OBJ_MAX_MATERIALS) continue;
            cur = &lib->mats[lib->count++];
            memset(cur, 0, sizeof(GerObjMaterial));
            cur->d  = 1.0f;
            cur->Ns = 32.0f;
            sscanf(p + 7, "%63s", cur->name);

        } else if (cur && strncmp(p, "Ka", 2) == 0) {
            sscanf(p + 2, "%f %f %f", &cur->Ka.x, &cur->Ka.y, &cur->Ka.z);
        } else if (cur && strncmp(p, "Kd", 2) == 0) {
            sscanf(p + 2, "%f %f %f", &cur->Kd.x, &cur->Kd.y, &cur->Kd.z);
        } else if (cur && strncmp(p, "Ks", 2) == 0) {
            sscanf(p + 2, "%f %f %f", &cur->Ks.x, &cur->Ks.y, &cur->Ks.z);
        } else if (cur && strncmp(p, "Ns", 2) == 0) {
            sscanf(p + 2, "%f", &cur->Ns);
        } else if (cur && (strncmp(p, "d ", 2) == 0 || strncmp(p, "Tr", 2) == 0)) {
            float val; sscanf(p + 2, "%f", &val);
            cur->d = (p[0] == 'T') ? (1.0f - val) : val;
        } else if (cur && strncmp(p, "map_Kd", 6) == 0) {
            sscanf(p + 7, "%259s", cur->map_Kd);
        }
    }

    fclose(f);
    return GER_OK;
}

/* -----------------------------------------------------------------------
 * Hash map for vertex deduplication (open addressing, power-of-two size)
 * ----------------------------------------------------------------------- */
#define VHASH_SIZE 131072  /* must be power of two >= OBJ_TMP_MAX_VERTS */
typedef struct VHashEntry {
    int posIdx, uvIdx, nrmIdx; /* -1 = empty */
    int meshVertIdx;
} VHashEntry;

static VHashEntry *g_vhash = NULL; /* allocated once per load call, freed before return */

static unsigned int VHashKey(int p, int u, int n) {
    unsigned int h = (unsigned int)(p * 2654435761u) ^ (unsigned int)(u * 40503u) ^ (unsigned int)(n * 22695477u);
    return h & (VHASH_SIZE - 1);
}

static int VHashFind(int p, int u, int n) {
    if (!g_vhash) return -1;
    unsigned int slot = VHashKey(p, u, n);
    int probe = 0;
    while (probe < VHASH_SIZE) {
        VHashEntry *e = &g_vhash[slot];
        if (e->posIdx == -1) return -1;
        if (e->posIdx == p && e->uvIdx == u && e->nrmIdx == n)
            return e->meshVertIdx;
        slot = (slot + 1) & (VHASH_SIZE - 1);
        probe++;
    }
    return -1;
}

static void VHashInsert(int p, int u, int n, int meshVert) {
    if (!g_vhash) return;
    unsigned int slot = VHashKey(p, u, n);
    int probe = 0;
    while (probe < VHASH_SIZE) {
        VHashEntry *e = &g_vhash[slot];
        if (e->posIdx == -1) {
            e->posIdx = p; e->uvIdx = u; e->nrmIdx = n;
            e->meshVertIdx = meshVert;
            return;
        }
        slot = (slot + 1) & (VHASH_SIZE - 1);
        probe++;
    }
}

/* -----------------------------------------------------------------------
 * Parse one face index token "v/vt/vn" | "v//vn" | "v/vt" | "v"
 * All returned indices are 0-based (OBJ is 1-based, we subtract 1).
 * Negative (relative) OBJ indices are resolved using the counts
 * supplied in posCount/uvCount/nrmCount.
 * ----------------------------------------------------------------------- */
static void ParseFaceToken(const char *tok, int posCount, int uvCount, int nrmCount,
                            int *outPos, int *outUV, int *outNrm) {
    *outPos = -1; *outUV = -1; *outNrm = -1;
    int p = 0, u = 0, n = 0;
    int parsed = sscanf(tok, "%d/%d/%d", &p, &u, &n);
    if (parsed < 3) {
        u = 0; n = 0;
        parsed = sscanf(tok, "%d//%d", &p, &n);
        if (parsed < 2) {
            n = 0;
            parsed = sscanf(tok, "%d/%d", &p, &u);
            if (parsed < 2) {
                sscanf(tok, "%d", &p);
                u = 0;
            }
        }
    }
    /* Convert from 1-based / relative negative to 0-based absolute */
    if (p > 0) *outPos = p - 1;
    else if (p < 0) *outPos = posCount + p;

    if (u > 0) *outUV = u - 1;
    else if (u < 0) *outUV = uvCount + u;

    if (n > 0) *outNrm = n - 1;
    else if (n < 0) *outNrm = nrmCount + n;
}

/* -----------------------------------------------------------------------
 * Main OBJ loader
 * ----------------------------------------------------------------------- */
GerResult gerObjLoad(GerMesh *outMesh, GerMemPool *pool,
                      const char *objPath,
                      const char *targetMaterialName,
                      GerObjMaterial *outMaterial) {
    if (!outMesh || !pool || !objPath) return GER_ERR_NULLPTR;

    /* ---- allocate temporary parse buffers (heap, freed before return) ---- */
    GerVec3 *tmpPos = (GerVec3*)malloc(sizeof(GerVec3) * OBJ_TMP_MAX_POS);
    GerVec2 *tmpUV  = (GerVec2*)malloc(sizeof(GerVec2) * OBJ_TMP_MAX_UV);
    GerVec3 *tmpNrm = (GerVec3*)malloc(sizeof(GerVec3) * OBJ_TMP_MAX_NRM);
    g_vhash = (VHashEntry*)malloc(sizeof(VHashEntry) * VHASH_SIZE);
    GerVertex *tmpVerts = (GerVertex*)malloc(sizeof(GerVertex) * OBJ_TMP_MAX_VERTS);
    uint32_t  *tmpIdx   = (uint32_t*)malloc(sizeof(uint32_t) * OBJ_TMP_MAX_IDX);

    GerResult result = GER_OK;

    if (!tmpPos || !tmpUV || !tmpNrm || !g_vhash || !tmpVerts || !tmpIdx) {
        result = GER_ERR_OUT_OF_MEMORY;
        goto cleanup;
    }

    /* Init vhash: mark all slots empty */
    {
        int i;
        for (i = 0; i < VHASH_SIZE; i++) g_vhash[i].posIdx = -1;
    }

    int posCount = 0, uvCount = 0, nrmCount = 0;
    int vertCount = 0, idxCount = 0;
    int inTargetGroup = (targetMaterialName == NULL) ? 1 : 0;
    int hasNormals = 0;

    /* .mtl sidecar path (same dir as .obj, different extension) */
    char mtlPath[260] = {0};
    GerObjMaterialLib matLib; matLib.count = 0;
    GerObjMaterial activeMat;
    memset(&activeMat, 0, sizeof(activeMat));
    activeMat.Kd = gerVec3Make(1,1,1);
    activeMat.Ka = gerVec3Make(0.2f,0.2f,0.2f);
    activeMat.Ks = gerVec3Make(0.5f,0.5f,0.5f);
    activeMat.Ns = 32.0f;
    activeMat.d  = 1.0f;

    FILE *f = fopen(objPath, "r");
    if (!f) { result = GER_ERR_NOT_FOUND; goto cleanup; }

    char line[1024];
    while (fgets(line, sizeof(line), f)) {
        char *p = line;
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '#' || *p == '\n' || *p == '\r') continue;

        /* vertex position */
        if (p[0]=='v' && (p[1]==' '||p[1]=='\t')) {
            if (posCount < OBJ_TMP_MAX_POS) {
                GerVec3 v = {0,0,0};
                sscanf(p+2, "%f %f %f", &v.x, &v.y, &v.z);
                tmpPos[posCount++] = v;
            }
        }
        /* texture coord */
        else if (p[0]=='v' && p[1]=='t' && (p[2]==' '||p[2]=='\t')) {
            if (uvCount < OBJ_TMP_MAX_UV) {
                GerVec2 uv = {0,0};
                sscanf(p+3, "%f %f", &uv.x, &uv.y);
                uv.y = 1.0f - uv.y; /* OBJ UV origin is bottom-left; flip to top-left */
                tmpUV[uvCount++] = uv;
            }
        }
        /* normal */
        else if (p[0]=='v' && p[1]=='n' && (p[2]==' '||p[2]=='\t')) {
            if (nrmCount < OBJ_TMP_MAX_NRM) {
                GerVec3 n = {0,1,0};
                sscanf(p+3, "%f %f %f", &n.x, &n.y, &n.z);
                tmpNrm[nrmCount++] = n;
                hasNormals = 1;
            }
        }
        /* mtllib */
        else if (strncmp(p, "mtllib", 6) == 0) {
            char mtlName[256];
            if (sscanf(p+7, "%255s", mtlName) == 1) {
                /* build full path: same directory as .obj */
                const char *lastSlash = strrchr(objPath, '/');
                const char *lastBSlash = strrchr(objPath, '\\');
                const char *lastSep = lastSlash > lastBSlash ? lastSlash : lastBSlash;
                if (lastSep) {
                    size_t dirLen = (size_t)(lastSep - objPath) + 1;
                    if (dirLen < sizeof(mtlPath) - strlen(mtlName) - 1) {
                        memcpy(mtlPath, objPath, dirLen);
                        strcpy(mtlPath + dirLen, mtlName);
                    }
                } else {
                    strncpy(mtlPath, mtlName, sizeof(mtlPath)-1);
                }
                gerMtlLoad(&matLib, mtlPath);
            }
        }
        /* usemtl */
        else if (strncmp(p, "usemtl", 6) == 0) {
            char matName[GER_MAX_NAME_LEN];
            sscanf(p+7, "%63s", matName);
            /* Switch active material */
            int mi;
            for (mi = 0; mi < matLib.count; mi++) {
                if (strcmp(matLib.mats[mi].name, matName) == 0) {
                    activeMat = matLib.mats[mi];
                    break;
                }
            }
            if (targetMaterialName) {
                inTargetGroup = (strcmp(matName, targetMaterialName) == 0) ? 1 : 0;
            }
        }
        /* face */
        else if (p[0]=='f' && (p[1]==' '||p[1]=='\t')) {
            if (!inTargetGroup) continue;

            /* tokenise face tokens */
            char tokens[8][64];
            int tcount = 0;
            char *tok = p + 2;
            while (*tok && tcount < 8) {
                while (*tok == ' ' || *tok == '\t') tok++;
                if (*tok == '\n' || *tok == '\r' || *tok == '\0') break;
                char *end = tok;
                while (*end && *end != ' ' && *end != '\t' && *end != '\n' && *end != '\r') end++;
                size_t len = (size_t)(end - tok);
                if (len >= sizeof(tokens[0])) len = sizeof(tokens[0])-1;
                memcpy(tokens[tcount], tok, len);
                tokens[tcount][len] = '\0';
                tcount++;
                tok = end;
            }
            if (tcount < 3) continue;

            /* triangulate: fan from vertex 0 */
            int fan;
            for (fan = 1; fan <= tcount - 2; fan++) {
                int triTokIdx[3] = { 0, fan, fan+1 };
                int triVerts[3];

                int t;
                for (t = 0; t < 3; t++) {
                    int pi = -1, ui = -1, ni = -1;
                    ParseFaceToken(tokens[triTokIdx[t]], posCount, uvCount, nrmCount, &pi, &ui, &ni);

                    int existing = VHashFind(pi, ui, ni);
                    if (existing >= 0) {
                        triVerts[t] = existing;
                    } else {
                        if (vertCount >= OBJ_TMP_MAX_VERTS) { result = GER_ERR_LIMIT_REACHED; fclose(f); goto cleanup; }
                        GerVertex vert;
                        memset(&vert, 0, sizeof(vert));
                        vert.position = (pi >= 0 && pi < posCount) ? tmpPos[pi] : gerVec3Make(0,0,0);
                        vert.uv       = (ui >= 0 && ui < uvCount)  ? tmpUV[ui]  : (GerVec2){0,0};
                        vert.normal   = (ni >= 0 && ni < nrmCount) ? tmpNrm[ni] : gerVec3Make(0,1,0);
                        vert.color    = GER_COLOR_RGB(255,255,255);
                        tmpVerts[vertCount] = vert;
                        VHashInsert(pi, ui, ni, vertCount);
                        triVerts[t] = vertCount++;
                    }
                }

                if (idxCount + 3 > OBJ_TMP_MAX_IDX) { result = GER_ERR_LIMIT_REACHED; fclose(f); goto cleanup; }
                tmpIdx[idxCount++] = (uint32_t)triVerts[0];
                tmpIdx[idxCount++] = (uint32_t)triVerts[1];
                tmpIdx[idxCount++] = (uint32_t)triVerts[2];
            }
        }
    }
    fclose(f);

    /* ---- generate flat normals if none in file ---- */
    if (!hasNormals && idxCount > 0) {
        int i;
        for (i = 0; i < vertCount; i++) {
            tmpVerts[i].normal = gerVec3Make(0,0,0);
        }
        for (i = 0; i < idxCount; i += 3) {
            GerVec3 a = tmpVerts[tmpIdx[i+0]].position;
            GerVec3 b = tmpVerts[tmpIdx[i+1]].position;
            GerVec3 c = tmpVerts[tmpIdx[i+2]].position;
            GerVec3 n = gerVec3Normalize(gerVec3Cross(gerVec3Sub(b,a), gerVec3Sub(c,a)));
            tmpVerts[tmpIdx[i+0]].normal = gerVec3Add(tmpVerts[tmpIdx[i+0]].normal, n);
            tmpVerts[tmpIdx[i+1]].normal = gerVec3Add(tmpVerts[tmpIdx[i+1]].normal, n);
            tmpVerts[tmpIdx[i+2]].normal = gerVec3Add(tmpVerts[tmpIdx[i+2]].normal, n);
        }
        for (i = 0; i < vertCount; i++) {
            tmpVerts[i].normal = gerVec3Normalize(tmpVerts[i].normal);
        }
    }

    /* ---- commit to pool (single alloc each, never touched per frame) ---- */
    if (vertCount == 0 || idxCount == 0) { result = GER_ERR_INVALID_ARG; goto cleanup; }

    outMesh->vertices = (GerVertex*)gerMemPoolAlloc(pool, sizeof(GerVertex) * (size_t)vertCount);
    outMesh->indices  = (uint32_t*) gerMemPoolAlloc(pool, sizeof(uint32_t)  * (size_t)idxCount);
    if (!outMesh->vertices || !outMesh->indices) { result = GER_ERR_OUT_OF_MEMORY; goto cleanup; }

    memcpy(outMesh->vertices, tmpVerts, sizeof(GerVertex) * (size_t)vertCount);
    memcpy(outMesh->indices,  tmpIdx,   sizeof(uint32_t)  * (size_t)idxCount);
    outMesh->vertexCount = vertCount;
    outMesh->indexCount  = idxCount;

    if (outMaterial) *outMaterial = activeMat;

cleanup:
    free(tmpPos); free(tmpUV); free(tmpNrm);
    free(g_vhash); g_vhash = NULL;
    free(tmpVerts); free(tmpIdx);
    return result;
}

/* Convenience: load .obj directly into a new layout */
GerLayout *gerFugLoadObj(GerScene *scene, const char *layoutName,
                          const char *objPath, const char *targetMat) {
    if (!scene || !layoutName || !objPath) return NULL;
    GerLayout *layout = gerSceneCreateLayout(scene, layoutName);
    if (!layout) return NULL;

    GerObjMaterial mat;
    GerResult r = gerObjLoad(&layout->mesh, &scene->pool, objPath, targetMat, &mat);
    if (r != GER_OK) { layout->active = 0; return NULL; }

    /* Apply diffuse color from material */
    uint8_t cr = (uint8_t)(mat.Kd.x * 255.0f);
    uint8_t cg = (uint8_t)(mat.Kd.y * 255.0f);
    uint8_t cb = (uint8_t)(mat.Kd.z * 255.0f);
    layout->color = GER_COLOR_RGB(cr, cg, cb);
    layout->shadeMode = GER_SHADE_GOURAUD;
    return layout;
}

/* =====================================================================
 * Memory-based OBJ loader
 * Menggunakan buffer in-memory sebagai gantinya file I/O.
 * Identik dengan gerObjLoad() kecuali sumber datanya char* bukan FILE*.
 * ===================================================================== */

/* Helper: baca satu baris dari buffer memory, return pointer ke baris
 * berikutnya atau NULL jika sudah habis */
static const char *MemReadLine(const char *pos, const char *end,
                                char *outBuf, size_t outBufSize) {
    if (!pos || pos >= end) return NULL;
    size_t i = 0;
    while (pos < end && *pos != '\n' && i < outBufSize - 1) {
        outBuf[i++] = *pos++;
    }
    if (pos < end && *pos == '\n') pos++;
    outBuf[i] = '\0';
    return pos;
}

GerResult gerObjLoadFromMemory(GerMesh *outMesh, GerMemPool *pool,
                                const char *objData, size_t objSize,
                                const char *mtlData, size_t mtlSize,
                                const char *targetMaterialName,
                                GerObjMaterial *outMaterial) {
    if (!outMesh || !pool || !objData || objSize == 0) return GER_ERR_NULLPTR;

    /* Alokasi buffer temp (sama seperti gerObjLoad) */
    GerVec3   *tmpPos   = (GerVec3*)  malloc(sizeof(GerVec3)   * OBJ_TMP_MAX_POS);
    GerVec2   *tmpUV    = (GerVec2*)  malloc(sizeof(GerVec2)   * OBJ_TMP_MAX_UV);
    GerVec3   *tmpNrm   = (GerVec3*)  malloc(sizeof(GerVec3)   * OBJ_TMP_MAX_NRM);
    g_vhash             = (VHashEntry*)malloc(sizeof(VHashEntry)* VHASH_SIZE);
    GerVertex *tmpVerts = (GerVertex*)malloc(sizeof(GerVertex)  * OBJ_TMP_MAX_VERTS);
    uint32_t  *tmpIdx   = (uint32_t*) malloc(sizeof(uint32_t)   * OBJ_TMP_MAX_IDX);

    GerResult result = GER_OK;
    if (!tmpPos || !tmpUV || !tmpNrm || !g_vhash || !tmpVerts || !tmpIdx) {
        result = GER_ERR_OUT_OF_MEMORY;
        goto mem_cleanup;
    }

    { int i; for (i = 0; i < VHASH_SIZE; i++) g_vhash[i].posIdx = -1; }

    int posCount = 0, uvCount = 0, nrmCount = 0;
    int vertCount = 0, idxCount = 0;
    int inTargetGroup = (targetMaterialName == NULL) ? 1 : 0;
    int hasNormals = 0;

    /* Parse MTL dari memory jika ada */
    GerObjMaterialLib matLib; matLib.count = 0;
    if (mtlData && mtlSize > 0) {
        GerObjMaterial *cur = NULL;
        char line[512];
        const char *mp = mtlData, *mend = mtlData + mtlSize;
        while ((mp = MemReadLine(mp, mend, line, sizeof(line))) != NULL) {
            char *p = line;
            while (*p == ' ' || *p == '\t') p++;
            if (*p == '#' || *p == '\n' || *p == '\r' || *p == '\0') continue;
            if (strncmp(p, "newmtl", 6) == 0) {
                if (matLib.count < GER_OBJ_MAX_MATERIALS) {
                    cur = &matLib.mats[matLib.count++];
                    memset(cur, 0, sizeof(*cur));
                    cur->d = 1.0f; cur->Ns = 32.0f;
                    sscanf(p+7, "%63s", cur->name);
                }
            } else if (cur && strncmp(p,"Ka",2)==0) sscanf(p+2,"%f %f %f",&cur->Ka.x,&cur->Ka.y,&cur->Ka.z);
            else if (cur && strncmp(p,"Kd",2)==0) sscanf(p+2,"%f %f %f",&cur->Kd.x,&cur->Kd.y,&cur->Kd.z);
            else if (cur && strncmp(p,"Ks",2)==0) sscanf(p+2,"%f %f %f",&cur->Ks.x,&cur->Ks.y,&cur->Ks.z);
            else if (cur && strncmp(p,"Ns",2)==0) sscanf(p+2,"%f",&cur->Ns);
            else if (cur && strncmp(p,"d ",2)==0) sscanf(p+2,"%f",&cur->d);
        }
    }

    GerObjMaterial activeMat;
    memset(&activeMat, 0, sizeof(activeMat));
    activeMat.Kd = gerVec3Make(1,1,1);
    activeMat.Ka = gerVec3Make(0.2f,0.2f,0.2f);
    activeMat.Ks = gerVec3Make(0.5f,0.5f,0.5f);
    activeMat.Ns = 32.0f; activeMat.d = 1.0f;

    /* Parse OBJ dari memory */
    char line[1024];
    const char *p = objData, *end = objData + objSize;
    while ((p = MemReadLine(p, end, line, sizeof(line))) != NULL) {
        char *lp = line;
        while (*lp == ' ' || *lp == '\t') lp++;
        if (*lp == '#' || *lp == '\n' || *lp == '\r' || *lp == '\0') continue;

        if (lp[0]=='v' && (lp[1]==' '||lp[1]=='\t')) {
            if (posCount < OBJ_TMP_MAX_POS) {
                GerVec3 v={0,0,0}; sscanf(lp+2,"%f %f %f",&v.x,&v.y,&v.z);
                tmpPos[posCount++] = v;
            }
        } else if (lp[0]=='v' && lp[1]=='t' && (lp[2]==' '||lp[2]=='\t')) {
            if (uvCount < OBJ_TMP_MAX_UV) {
                GerVec2 uv={0,0}; sscanf(lp+3,"%f %f",&uv.x,&uv.y);
                uv.y = 1.0f - uv.y;
                tmpUV[uvCount++] = uv;
            }
        } else if (lp[0]=='v' && lp[1]=='n' && (lp[2]==' '||lp[2]=='\t')) {
            if (nrmCount < OBJ_TMP_MAX_NRM) {
                GerVec3 n={0,1,0}; sscanf(lp+3,"%f %f %f",&n.x,&n.y,&n.z);
                tmpNrm[nrmCount++] = n; hasNormals = 1;
            }
        } else if (strncmp(lp,"usemtl",6)==0) {
            char matName[GER_MAX_NAME_LEN]; sscanf(lp+7,"%63s",matName);
            int mi;
            for (mi=0; mi<matLib.count; mi++) {
                if (strcmp(matLib.mats[mi].name, matName)==0) { activeMat=matLib.mats[mi]; break; }
            }
            if (targetMaterialName)
                inTargetGroup = (strcmp(matName, targetMaterialName)==0) ? 1 : 0;
        } else if (lp[0]=='f' && (lp[1]==' '||lp[1]=='\t')) {
            if (!inTargetGroup) continue;
            char tokens[8][64]; int tcount=0;
            char *tok = lp+2;
            while (*tok && tcount<8) {
                while (*tok==' '||*tok=='\t') tok++;
                if (*tok=='\n'||*tok=='\r'||*tok=='\0') break;
                char *e=tok; while (*e&&*e!=' '&&*e!='\t'&&*e!='\n'&&*e!='\r') e++;
                size_t len=(size_t)(e-tok); if(len>=sizeof(tokens[0])) len=sizeof(tokens[0])-1;
                memcpy(tokens[tcount],tok,len); tokens[tcount][len]='\0'; tcount++; tok=e;
            }
            if (tcount<3) continue;
            int fan;
            for (fan=1; fan<=tcount-2; fan++) {
                int triTok[3]={0,fan,fan+1}, triVerts[3];
                int t;
                for (t=0; t<3; t++) {
                    int pi=-1,ui=-1,ni=-1;
                    ParseFaceToken(tokens[triTok[t]], posCount, uvCount, nrmCount, &pi,&ui,&ni);
                    int ex = VHashFind(pi,ui,ni);
                    if (ex>=0) { triVerts[t]=ex; }
                    else {
                        if (vertCount>=OBJ_TMP_MAX_VERTS) { result=GER_ERR_LIMIT_REACHED; goto mem_cleanup; }
                        GerVertex vert; memset(&vert,0,sizeof(vert));
                        vert.position=(pi>=0&&pi<posCount)?tmpPos[pi]:gerVec3Make(0,0,0);
                        vert.uv      =(ui>=0&&ui<uvCount) ?tmpUV[ui] :(GerVec2){0,0};
                        vert.normal  =(ni>=0&&ni<nrmCount)?tmpNrm[ni]:gerVec3Make(0,1,0);
                        vert.color   =GER_COLOR_RGB(255,255,255);
                        tmpVerts[vertCount]=vert;
                        VHashInsert(pi,ui,ni,vertCount);
                        triVerts[t]=vertCount++;
                    }
                }
                if (idxCount+3>OBJ_TMP_MAX_IDX) { result=GER_ERR_LIMIT_REACHED; goto mem_cleanup; }
                tmpIdx[idxCount++]=(uint32_t)triVerts[0];
                tmpIdx[idxCount++]=(uint32_t)triVerts[1];
                tmpIdx[idxCount++]=(uint32_t)triVerts[2];
            }
        }
    }

    /* Generate normals jika tidak ada */
    if (!hasNormals && idxCount>0) {
        int i;
        for (i=0;i<vertCount;i++) tmpVerts[i].normal=gerVec3Make(0,0,0);
        for (i=0;i<idxCount;i+=3) {
            GerVec3 a=tmpVerts[tmpIdx[i+0]].position;
            GerVec3 b=tmpVerts[tmpIdx[i+1]].position;
            GerVec3 c=tmpVerts[tmpIdx[i+2]].position;
            GerVec3 n=gerVec3Normalize(gerVec3Cross(gerVec3Sub(b,a),gerVec3Sub(c,a)));
            tmpVerts[tmpIdx[i+0]].normal=gerVec3Add(tmpVerts[tmpIdx[i+0]].normal,n);
            tmpVerts[tmpIdx[i+1]].normal=gerVec3Add(tmpVerts[tmpIdx[i+1]].normal,n);
            tmpVerts[tmpIdx[i+2]].normal=gerVec3Add(tmpVerts[tmpIdx[i+2]].normal,n);
        }
        for (i=0;i<vertCount;i++) tmpVerts[i].normal=gerVec3Normalize(tmpVerts[i].normal);
    }

    if (vertCount==0||idxCount==0) { result=GER_ERR_INVALID_ARG; goto mem_cleanup; }

    outMesh->vertices=(GerVertex*)gerMemPoolAlloc(pool,sizeof(GerVertex)*(size_t)vertCount);
    outMesh->indices =(uint32_t*) gerMemPoolAlloc(pool,sizeof(uint32_t) *(size_t)idxCount);
    if (!outMesh->vertices||!outMesh->indices) { result=GER_ERR_OUT_OF_MEMORY; goto mem_cleanup; }

    memcpy(outMesh->vertices,tmpVerts,sizeof(GerVertex)*(size_t)vertCount);
    memcpy(outMesh->indices, tmpIdx,  sizeof(uint32_t) *(size_t)idxCount);
    outMesh->vertexCount=vertCount;
    outMesh->indexCount =idxCount;
    if (outMaterial) *outMaterial=activeMat;

mem_cleanup:
    free(tmpPos); free(tmpUV); free(tmpNrm);
    free(g_vhash); g_vhash=NULL;
    free(tmpVerts); free(tmpIdx);
    return result;
}

GerLayout *gerFugLoadObjFromMemory(GerScene *scene, const char *layoutName,
                                    const char *objData, size_t objSize,
                                    const char *mtlData, size_t mtlSize,
                                    const char *targetMat) {
    if (!scene||!layoutName||!objData) return NULL;
    GerLayout *layout = gerSceneCreateLayout(scene, layoutName);
    if (!layout) return NULL;
    GerObjMaterial mat;
    GerResult r = gerObjLoadFromMemory(&layout->mesh, &scene->pool,
                                        objData, objSize,
                                        mtlData, mtlSize,
                                        targetMat, &mat);
    if (r != GER_OK) { layout->active=0; return NULL; }
    uint8_t cr=(uint8_t)(mat.Kd.x*255.0f);
    uint8_t cg=(uint8_t)(mat.Kd.y*255.0f);
    uint8_t cb=(uint8_t)(mat.Kd.z*255.0f);
    layout->color=GER_COLOR_RGB(cr,cg,cb);
    layout->shadeMode=GER_SHADE_GOURAUD;
    return layout;
}
