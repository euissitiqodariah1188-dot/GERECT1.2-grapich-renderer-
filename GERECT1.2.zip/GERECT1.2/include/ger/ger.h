/* =====================================================================
 * GERECT 1.2 - Core Header (ger/ger.h)
 * Software 3D Renderer Engine - Pure C, Win32 API only.
 * No OpenGL, no SDL, no SFML, no DirectX.
 * =====================================================================
 */
#ifndef GER_H
#define GER_H

#ifdef __cplusplus
extern "C" {
#endif

#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

/* ----------------------------------------------------------------------
 * Build configuration
 * ---------------------------------------------------------------------- */
#define GER_VERSION_MAJOR   1
#define GER_VERSION_MINOR   2
#define GER_MAX_CORES       8
#define GER_MAX_LAYOUTS     4096
#define GER_MAX_NAME_LEN    64
#define GER_PI              3.14159265358979323846
#define GER_DEG2RAD(x)      ((x) * (GER_PI / 180.0))
#define GER_RAD2DEG(x)      ((x) * (180.0 / GER_PI))

#ifndef GER_API
#define GER_API
#endif

/* ----------------------------------------------------------------------
 * Basic result / error codes
 * ---------------------------------------------------------------------- */
typedef enum GerResult {
    GER_OK                  = 0,
    GER_ERR_NULLPTR         = -1,
    GER_ERR_OUT_OF_MEMORY   = -2,
    GER_ERR_INVALID_ARG     = -3,
    GER_ERR_NOT_FOUND       = -4,
    GER_ERR_LIMIT_REACHED   = -5,
    GER_ERR_WIN32           = -6,
    GER_ERR_PARSE           = -7,
    GER_ERR_THREAD          = -8
} GerResult;

/* ----------------------------------------------------------------------
 * Vector / Matrix math (column-major friendly, row-vector convention)
 * ---------------------------------------------------------------------- */
typedef struct GerVec2 { float x, y; } GerVec2;
typedef struct GerVec3 { float x, y, z; } GerVec3;
typedef struct GerVec4 { float x, y, z, w; } GerVec4;

typedef struct GerMat4 {
    /* row-major 4x4, m[row][col] */
    float m[4][4];
} GerMat4;

GER_API GerVec3 gerVec3Make(float x, float y, float z);
GER_API GerVec3 gerVec3Add(GerVec3 a, GerVec3 b);
GER_API GerVec3 gerVec3Sub(GerVec3 a, GerVec3 b);
GER_API GerVec3 gerVec3Scale(GerVec3 a, float s);
GER_API GerVec3 gerVec3Cross(GerVec3 a, GerVec3 b);
GER_API float   gerVec3Dot(GerVec3 a, GerVec3 b);
GER_API float   gerVec3Length(GerVec3 a);
GER_API GerVec3 gerVec3Normalize(GerVec3 a);

GER_API GerVec4 gerVec4Make(float x, float y, float z, float w);
GER_API GerVec4 gerVec4FromVec3(GerVec3 v, float w);

GER_API GerMat4 gerMat4Identity(void);
GER_API GerMat4 gerMat4Multiply(GerMat4 a, GerMat4 b);
GER_API GerMat4 gerMat4Translate(float x, float y, float z);
GER_API GerMat4 gerMat4Scale(float x, float y, float z);
GER_API GerMat4 gerMat4RotateX(float radians);
GER_API GerMat4 gerMat4RotateY(float radians);
GER_API GerMat4 gerMat4RotateZ(float radians);
GER_API GerMat4 gerMat4RotateXYZ(float rx, float ry, float rz);
GER_API GerMat4 gerMat4Perspective(float fovYRadians, float aspect, float zNear, float zFar);
GER_API GerMat4 gerMat4LookAt(GerVec3 eye, GerVec3 target, GerVec3 up);
GER_API GerVec4 gerMat4MulVec4(GerMat4 m, GerVec4 v);

/* ----------------------------------------------------------------------
 * Color (BGRA, little-endian packed 32-bit)
 * Memory byte order in the 32-bit value (low->high byte): B,G,R,A
 * so that when read as a little-endian uint32_t the literal is 0xAARRGGBB
 * when written as ARGB-style hex, matching standard Win32 DIB expectations.
 * ---------------------------------------------------------------------- */
typedef uint32_t GerColor;

#define GER_COLOR_BGRA(b,g,r,a) \
    ( ((uint32_t)(a) << 24) | ((uint32_t)(r) << 16) | ((uint32_t)(g) << 8) | ((uint32_t)(b)) )

#define GER_COLOR_RGBA(r,g,b,a) GER_COLOR_BGRA(b,g,r,a)
#define GER_COLOR_RGB(r,g,b)    GER_COLOR_BGRA(b,g,r,255)

GER_API GerColor gerColorNamed(const char *name); /* "red", "white", "n/red" (n/ prefix ignored) */
GER_API GerColor gerColorLerp(GerColor a, GerColor b, float t);

/* ----------------------------------------------------------------------
 * Static memory pool (anti-leak): one allocation at init, never realloc
 * during the render loop. All dynamic structures in GERECT funnel
 * through this pool so lifetime is explicit and centrally tracked.
 * ---------------------------------------------------------------------- */
typedef struct GerMemPool {
    uint8_t *base;        /* single VirtualAlloc'd block */
    size_t   capacity;
    size_t   used;
    CRITICAL_SECTION lock;
    int      initialized;
} GerMemPool;

GER_API GerResult gerMemPoolInit(GerMemPool *pool, size_t capacityBytes);
GER_API void      *gerMemPoolAlloc(GerMemPool *pool, size_t size);
GER_API void       gerMemPoolReset(GerMemPool *pool); /* logical reset, does not unmap */
GER_API void       gerMemPoolDestroy(GerMemPool *pool); /* VirtualFree, zero struct */

/* ----------------------------------------------------------------------
 * Global engine lifecycle
 * ---------------------------------------------------------------------- */
GER_API GerResult gerInit(void);
GER_API void      gerShutdown(void);
GER_API double    gerGetTimeSeconds(void);
GER_API void      gerSleepMs(unsigned int ms);

#ifdef __cplusplus
}
#endif

#endif /* GER_H */
