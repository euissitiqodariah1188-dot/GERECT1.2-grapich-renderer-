/* =====================================================================
 * GERECT 1.2 - 3D Core Header (ger3d/ger3d.h)
 *
 * Modules implemented here:
 *   SSM  - Sistem Scene/Mesh: the 3D logic layer (layouts, transforms,
 *          mesh primitives, scene graph, camera).
 *   Precompiled effect/shader table - all pixel shading variants and
 *          texture sampling modes are resolved to function pointers
 *          ONCE at gerSceneInit() time (a dispatch table built up
 *          front), so the hot per-pixel path never branches on
 *          string/enum lookups or re-resolves anything during render.
 * =====================================================================
 */
#ifndef GER3D_H
#define GER3D_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ger/ger.h"
#include "gersys64/gersys64.h"

/* ----------------------------------------------------------------------
 * Framebuffer + Z-buffer (allocated once, memset per frame, never realloc)
 * ---------------------------------------------------------------------- */
typedef struct GerFramebuffer {
    uint32_t *colorBuffer;   /* BGRA32, width*height, VirtualAlloc'd once */
    float    *depthBuffer;   /* width*height, VirtualAlloc'd once */
    int       width;
    int       height;
} GerFramebuffer;

GER_API GerResult gerFramebufferInit(GerFramebuffer *fb, int width, int height);
GER_API void      gerFramebufferClear(GerFramebuffer *fb, GerColor clearColor);
GER_API void      gerFramebufferResize(GerFramebuffer *fb, int width, int height); /* only on WM_SIZE, not per frame */
GER_API void      gerFramebufferDestroy(GerFramebuffer *fb);
GER_API void      gerFramebufferSetPixel(GerFramebuffer *fb, int x, int y, GerColor c);

/* ----------------------------------------------------------------------
 * Texture (loaded once at FuG load time, static for the lifetime of
 * the layout that references it)
 * ---------------------------------------------------------------------- */
typedef struct GerTexture {
    uint32_t *pixels;   /* BGRA32 */
    int       width;
    int       height;
    char      name[GER_MAX_NAME_LEN];
    int       inUse;
} GerTexture;

#define GER_MAX_TEXTURES 256

/* ----------------------------------------------------------------------
 * Precompiled shading mode table
 *
 * Each entry is resolved to a concrete function pointer pair
 * (vertex-stage transform is shared; this table only covers the
 * per-pixel "compiled effect" stage) the first time the engine boots,
 * mirroring "semua efek dan shader sudah di compile duluan".
 * ---------------------------------------------------------------------- */
typedef enum GerShadeMode {
    GER_SHADE_FLAT = 0,
    GER_SHADE_GOURAUD,
    GER_SHADE_TEXTURED,
    GER_SHADE_WIREFRAME,
    GER_SHADE_COUNT
} GerShadeMode;

typedef GerColor (*GerPixelShaderFn)(
    float baseR, float baseG, float baseB, float baseA,
    float u, float v, const GerTexture *tex,
    float ndotl /* precomputed lambert term */
);

typedef struct GerCompiledEffectTable {
    GerPixelShaderFn shaders[GER_SHADE_COUNT];
    int compiled;
} GerCompiledEffectTable;

/* Builds the dispatch table once. Called internally by gerSceneInit();
 * exposed publicly in case an application wants to rebuild it (e.g.
 * after a hot-reload), but never called per-frame. */
GER_API void gerEffectsCompileAll(GerCompiledEffectTable *table);

/* ----------------------------------------------------------------------
 * Vertex / Mesh (static allocation: loaded once, render-only afterwards)
 * ---------------------------------------------------------------------- */
typedef struct GerVertex {
    GerVec3 position;
    GerVec3 normal;
    GerVec2 uv;
    GerColor color;
} GerVertex;

#define GER_MESH_MAX_VERTICES 65536
#define GER_MESH_MAX_INDICES  (GER_MESH_MAX_VERTICES * 3)

typedef struct GerMesh {
    GerVertex *vertices;   /* pointer into static pool, fixed after load */
    uint32_t  *indices;
    int        vertexCount;
    int        indexCount;
} GerMesh;

/* Procedural primitive builders. Allocate from the supplied pool ONCE;
 * caller must not call these per-frame. */
GER_API GerResult gerMeshBuildLine(GerMesh *mesh, GerMemPool *pool, GerVec3 a, GerVec3 b);
GER_API GerResult gerMeshBuildCube(GerMesh *mesh, GerMemPool *pool, float sizeX, float sizeY, float sizeZ);
GER_API GerResult gerMeshBuildPlane(GerMesh *mesh, GerMemPool *pool, float sizeX, float sizeZ, int subdivisions);
GER_API GerResult gerMeshBuildSphere(GerMesh *mesh, GerMemPool *pool, float radius, int rings, int segments);
GER_API GerResult gerMeshBuildPyramid(GerMesh *mesh, GerMemPool *pool, float baseSize, float height);

/* ----------------------------------------------------------------------
 * GerLayout: the DSL-visible 3D object ("layout[nama]") combining a
 * mesh, transform (pos/rot/scale via size[]), color, optional texture
 * and shading mode. This is the unit the script interpreter (ger.ger
 * script engine, see gerui) manipulates with pos[]/rot[]/move[]/size[]/color[].
 * ---------------------------------------------------------------------- */
typedef struct GerLayout {
    char         name[GER_MAX_NAME_LEN];
    GerMesh      mesh;
    GerVec3      position;
    GerVec3      rotationRad;
    GerVec3      scale;
    GerColor     color;
    GerShadeMode shadeMode;
    GerTexture  *texture;   /* NULL if untextured */
    int          active;
    int          is3DEnabled; /* set by gerDL3d */
} GerLayout;

#define GER_MAX_LAYOUT_OBJECTS GER_MAX_LAYOUTS

/* ----------------------------------------------------------------------
 * Camera
 * ---------------------------------------------------------------------- */
typedef struct GerCamera {
    GerVec3 eye;
    GerVec3 target;
    GerVec3 up;
    float   fovYRadians;
    float   nearZ;
    float   farZ;
} GerCamera;

GER_API void gerCameraInit(GerCamera *cam);
GER_API GerMat4 gerCameraGetView(const GerCamera *cam);
GER_API GerMat4 gerCameraGetProjection(const GerCamera *cam, float aspect);

/* ----------------------------------------------------------------------
 * GerScene: top-level SSM container. Fixed-capacity array of layouts,
 * fixed-capacity texture table, single framebuffer, single thread pool,
 * single precompiled effect table. Everything allocated exactly once
 * in gerSceneInit().
 * ---------------------------------------------------------------------- */
typedef struct GerScene {
    GerMemPool              pool;
    GerLayout                layouts[GER_MAX_LAYOUT_OBJECTS];
    int                       layoutCount;
    GerTexture                textures[GER_MAX_TEXTURES];
    int                       textureCount;
    GerFramebuffer            framebuffer;
    GerCamera                 camera;
    GerThreadPool            *threadPool;
    GerCompiledEffectTable    effects;
    GerFrameTimer             frameTimer;
    CRITICAL_SECTION          sceneLock; /* guards layout array mutation from script thread vs render thread */
} GerScene;

GER_API GerResult gerSceneInit(GerScene *scene, int width, int height, int threadCount);
GER_API void      gerSceneDestroy(GerScene *scene);

/* SSM: scene/layout manipulation, mirrors the DSL verbs 1:1 */
GER_API GerLayout *gerSceneFindLayout(GerScene *scene, const char *name);
GER_API GerLayout *gerSceneCreateLayout(GerScene *scene, const char *name); /* gerDL3d + layout[] */
GER_API GerResult  gerLayoutSetPos(GerLayout *layout, float x, float y, float z);          /* pos[][] */
GER_API GerResult  gerLayoutSetSize(GerLayout *layout, float x, float y, float z);          /* size[][] */
GER_API GerResult  gerLayoutSetColor(GerLayout *layout, GerColor color);                    /* color[][] */
GER_API GerResult  gerLayoutSetRotation(GerLayout *layout, float rx, float ry, float rz);    /* rot[][] (degrees) */
GER_API GerResult  gerLayoutMove(GerLayout *layout, float dx, float dy, float dz);           /* move[][] (relative) */
GER_API GerResult  gerLayoutSetShadeMode(GerLayout *layout, GerShadeMode mode);
GER_API GerResult  gerLayoutSetTexture(GerLayout *layout, GerTexture *tex);
GER_API GerResult  gerLayoutSetMeshKind(GerScene *scene, GerLayout *layout, const char *kind); /* "line","cube","plane","sphere","pyramid" */
GER_API GerResult  gerLayoutDestroy(GerScene *scene, const char *name);

/* FuG: texture / asset loading (BMP loader, no external image lib needed) */
GER_API GerTexture *gerFugLoadTextureBMP(GerScene *scene, const char *name, const char *bmpPath);
GER_API GerTexture *gerFugCreateSolidTexture(GerScene *scene, const char *name, int w, int h, GerColor color);

/* The full SSM -> FRM -> PMTG pipeline for a single frame.
 * Equivalent to: FuncG -> SSM -> FRM -> PMTG -> done, as described in
 * the engine's data flow. Call once per WM_PAINT / game loop tick. */
GER_API void gerSceneRenderFrame(GerScene *scene);

#ifdef __cplusplus
}
#endif

#endif /* GER3D_H */
