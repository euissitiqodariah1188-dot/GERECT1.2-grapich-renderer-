/* =====================================================================
 * GERECT 1.2 - 3D Core Implementation, Part 1: Framebuffer / Camera / Effects
 * =====================================================================
 */
#include "ger3d/ger3d.h"

/* ---------------------------------------------------------------------
 * Framebuffer
 * --------------------------------------------------------------------- */
GerResult gerFramebufferInit(GerFramebuffer *fb, int width, int height) {
    if (!fb || width <= 0 || height <= 0) return GER_ERR_INVALID_ARG;

    size_t colorBytes = (size_t)width * (size_t)height * sizeof(uint32_t);
    size_t depthBytes = (size_t)width * (size_t)height * sizeof(float);

    fb->colorBuffer = (uint32_t *)VirtualAlloc(NULL, colorBytes,
                                                MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!fb->colorBuffer) return GER_ERR_OUT_OF_MEMORY;

    fb->depthBuffer = (float *)VirtualAlloc(NULL, depthBytes,
                                             MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!fb->depthBuffer) {
        VirtualFree(fb->colorBuffer, 0, MEM_RELEASE);
        fb->colorBuffer = NULL;
        return GER_ERR_OUT_OF_MEMORY;
    }

    fb->width = width;
    fb->height = height;
    return GER_OK;
}

void gerFramebufferClear(GerFramebuffer *fb, GerColor clearColor) {
    if (!fb || !fb->colorBuffer || !fb->depthBuffer) return;
    size_t pixelCount = (size_t)fb->width * (size_t)fb->height;

    /* Per-frame reset uses memset/manual fill on the already-allocated
     * buffers -- never malloc/free here. */
    size_t i;
    for (i = 0; i < pixelCount; i++) {
        fb->colorBuffer[i] = clearColor;
    }
    /* depth buffer reset to "far" (1.0f represents farthest in our
     * normalized device depth convention) via fast memset of repeated
     * float pattern is not directly possible for arbitrary float, so
     * loop-fill explicitly as instructed (manual overwrite, no realloc) */
    for (i = 0; i < pixelCount; i++) {
        fb->depthBuffer[i] = 1.0f;
    }
}

void gerFramebufferResize(GerFramebuffer *fb, int width, int height) {
    if (!fb || width <= 0 || height <= 0) return;
    if (fb->width == width && fb->height == height) return;

    /* Resize is NOT a per-frame operation (only triggered by WM_SIZE),
     * so freeing + reallocating here does not violate the per-frame
     * "no realloc in render loop" rule. */
    if (fb->colorBuffer) VirtualFree(fb->colorBuffer, 0, MEM_RELEASE);
    if (fb->depthBuffer) VirtualFree(fb->depthBuffer, 0, MEM_RELEASE);
    fb->colorBuffer = NULL;
    fb->depthBuffer = NULL;

    gerFramebufferInit(fb, width, height);
}

void gerFramebufferDestroy(GerFramebuffer *fb) {
    if (!fb) return;
    if (fb->colorBuffer) {
        VirtualFree(fb->colorBuffer, 0, MEM_RELEASE);
        fb->colorBuffer = NULL;
    }
    if (fb->depthBuffer) {
        VirtualFree(fb->depthBuffer, 0, MEM_RELEASE);
        fb->depthBuffer = NULL;
    }
    fb->width = 0;
    fb->height = 0;
}

void gerFramebufferSetPixel(GerFramebuffer *fb, int x, int y, GerColor c) {
    if (!fb || x < 0 || y < 0 || x >= fb->width || y >= fb->height) return;
    fb->colorBuffer[(size_t)y * fb->width + x] = c;
}

/* ---------------------------------------------------------------------
 * Camera
 * --------------------------------------------------------------------- */
void gerCameraInit(GerCamera *cam) {
    if (!cam) return;
    cam->eye = gerVec3Make(0.0f, 1.5f, -4.0f);
    cam->target = gerVec3Make(0.0f, 0.0f, 0.0f);
    cam->up = gerVec3Make(0.0f, 1.0f, 0.0f);
    cam->fovYRadians = (float)GER_DEG2RAD(60.0);
    cam->nearZ = 0.1f;
    cam->farZ = 1000.0f;
}

GerMat4 gerCameraGetView(const GerCamera *cam) {
    return gerMat4LookAt(cam->eye, cam->target, cam->up);
}

GerMat4 gerCameraGetProjection(const GerCamera *cam, float aspect) {
    return gerMat4Perspective(cam->fovYRadians, aspect, cam->nearZ, cam->farZ);
}

/* ---------------------------------------------------------------------
 * Precompiled pixel shader table
 *
 * Each of these functions is a fully resolved implementation; the
 * "compile" step is simply populating the function pointer array once
 * so the renderer's inner loop does a single indexed call
 * (table.shaders[mode](...)) with zero branching on shading mode.
 * --------------------------------------------------------------------- */
static GerColor GerShaderFlat(float baseR, float baseG, float baseB, float baseA,
                               float u, float v, const GerTexture *tex, float ndotl) {
    (void)u; (void)v; (void)tex;
    float lit = 0.35f + 0.65f * (ndotl > 0.0f ? ndotl : 0.0f);
    uint8_t r = (uint8_t)(baseR * 255.0f * lit);
    uint8_t g = (uint8_t)(baseG * 255.0f * lit);
    uint8_t b = (uint8_t)(baseB * 255.0f * lit);
    uint8_t a = (uint8_t)(baseA * 255.0f);
    return GER_COLOR_RGBA(r, g, b, a);
}

static GerColor GerShaderGouraud(float baseR, float baseG, float baseB, float baseA,
                                  float u, float v, const GerTexture *tex, float ndotl) {
    (void)u; (void)v; (void)tex;
    float lit = 0.15f + 0.85f * (ndotl > 0.0f ? ndotl : 0.0f);
    uint8_t r = (uint8_t)(baseR * 255.0f * lit);
    uint8_t g = (uint8_t)(baseG * 255.0f * lit);
    uint8_t b = (uint8_t)(baseB * 255.0f * lit);
    uint8_t a = (uint8_t)(baseA * 255.0f);
    return GER_COLOR_RGBA(r, g, b, a);
}

static GerColor GerShaderTextured(float baseR, float baseG, float baseB, float baseA,
                                   float u, float v, const GerTexture *tex, float ndotl) {
    if (!tex || !tex->pixels) {
        return GerShaderFlat(baseR, baseG, baseB, baseA, u, v, tex, ndotl);
    }
    /* bilinear sample */
    float fx = u * (float)(tex->width - 1);
    float fy = v * (float)(tex->height - 1);
    if (fx < 0.0f) fx = 0.0f;
    if (fy < 0.0f) fy = 0.0f;
    int x0 = (int)fx, y0 = (int)fy;
    int x1 = x0 + 1 < tex->width ? x0 + 1 : x0;
    int y1 = y0 + 1 < tex->height ? y0 + 1 : y0;
    float tx = fx - (float)x0, ty = fy - (float)y0;

    uint32_t c00 = tex->pixels[(size_t)y0 * tex->width + x0];
    uint32_t c10 = tex->pixels[(size_t)y0 * tex->width + x1];
    uint32_t c01 = tex->pixels[(size_t)y1 * tex->width + x0];
    uint32_t c11 = tex->pixels[(size_t)y1 * tex->width + x1];

    GerColor top = gerColorLerp(c00, c10, tx);
    GerColor bot = gerColorLerp(c01, c11, tx);
    GerColor sampled = gerColorLerp(top, bot, ty);

    float lit = 0.3f + 0.7f * (ndotl > 0.0f ? ndotl : 0.0f);
    uint8_t sr = (uint8_t)((sampled >> 16) & 0xFF);
    uint8_t sg = (uint8_t)((sampled >> 8) & 0xFF);
    uint8_t sb = (uint8_t)(sampled & 0xFF);
    uint8_t sa = (uint8_t)((sampled >> 24) & 0xFF);

    uint8_t r = (uint8_t)((float)sr * lit * baseR);
    uint8_t g = (uint8_t)((float)sg * lit * baseG);
    uint8_t b = (uint8_t)((float)sb * lit * baseB);
    return GER_COLOR_RGBA(r, g, b, sa);
}

static GerColor GerShaderWireframe(float baseR, float baseG, float baseB, float baseA,
                                    float u, float v, const GerTexture *tex, float ndotl) {
    (void)u; (void)v; (void)tex; (void)ndotl;
    uint8_t r = (uint8_t)(baseR * 255.0f);
    uint8_t g = (uint8_t)(baseG * 255.0f);
    uint8_t b = (uint8_t)(baseB * 255.0f);
    uint8_t a = (uint8_t)(baseA * 255.0f);
    return GER_COLOR_RGBA(r, g, b, a);
}

void gerEffectsCompileAll(GerCompiledEffectTable *table) {
    if (!table) return;
    table->shaders[GER_SHADE_FLAT] = GerShaderFlat;
    table->shaders[GER_SHADE_GOURAUD] = GerShaderGouraud;
    table->shaders[GER_SHADE_TEXTURED] = GerShaderTextured;
    table->shaders[GER_SHADE_WIREFRAME] = GerShaderWireframe;
    table->compiled = 1;
}
