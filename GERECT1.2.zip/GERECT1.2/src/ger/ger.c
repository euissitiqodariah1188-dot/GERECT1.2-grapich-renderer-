/* =====================================================================
 * GERECT 1.2 - Core Implementation (ger.c)
 * ===================================================================== */
#include "ger/ger.h"

static LARGE_INTEGER g_perfFreq;
static LARGE_INTEGER g_perfStart;
static int g_gerInitialized = 0;

/* ---------------------------------------------------------------------
 * Vector math
 * --------------------------------------------------------------------- */
GerVec3 gerVec3Make(float x, float y, float z) {
    GerVec3 v; v.x = x; v.y = y; v.z = z; return v;
}

GerVec3 gerVec3Add(GerVec3 a, GerVec3 b) {
    return gerVec3Make(a.x + b.x, a.y + b.y, a.z + b.z);
}

GerVec3 gerVec3Sub(GerVec3 a, GerVec3 b) {
    return gerVec3Make(a.x - b.x, a.y - b.y, a.z - b.z);
}

GerVec3 gerVec3Scale(GerVec3 a, float s) {
    return gerVec3Make(a.x * s, a.y * s, a.z * s);
}

GerVec3 gerVec3Cross(GerVec3 a, GerVec3 b) {
    return gerVec3Make(
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    );
}

float gerVec3Dot(GerVec3 a, GerVec3 b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
}

float gerVec3Length(GerVec3 a) {
    return sqrtf(gerVec3Dot(a, a));
}

GerVec3 gerVec3Normalize(GerVec3 a) {
    float len = gerVec3Length(a);
    if (len < 1e-8f) return gerVec3Make(0.0f, 0.0f, 0.0f);
    float inv = 1.0f / len;
    return gerVec3Make(a.x * inv, a.y * inv, a.z * inv);
}

GerVec4 gerVec4Make(float x, float y, float z, float w) {
    GerVec4 v; v.x = x; v.y = y; v.z = z; v.w = w; return v;
}

GerVec4 gerVec4FromVec3(GerVec3 v, float w) {
    return gerVec4Make(v.x, v.y, v.z, w);
}

/* ---------------------------------------------------------------------
 * Matrix math (row-major storage, row-vector * matrix convention)
 * --------------------------------------------------------------------- */
GerMat4 gerMat4Identity(void) {
    GerMat4 r;
    memset(&r, 0, sizeof(r));
    r.m[0][0] = r.m[1][1] = r.m[2][2] = r.m[3][3] = 1.0f;
    return r;
}

GerMat4 gerMat4Multiply(GerMat4 a, GerMat4 b) {
    GerMat4 r;
    int i, j, k;
    for (i = 0; i < 4; i++) {
        for (j = 0; j < 4; j++) {
            float sum = 0.0f;
            for (k = 0; k < 4; k++) {
                sum += a.m[i][k] * b.m[k][j];
            }
            r.m[i][j] = sum;
        }
    }
    return r;
}

GerMat4 gerMat4Translate(float x, float y, float z) {
    GerMat4 r = gerMat4Identity();
    r.m[3][0] = x; r.m[3][1] = y; r.m[3][2] = z;
    return r;
}

GerMat4 gerMat4Scale(float x, float y, float z) {
    GerMat4 r = gerMat4Identity();
    r.m[0][0] = x; r.m[1][1] = y; r.m[2][2] = z;
    return r;
}

GerMat4 gerMat4RotateX(float radians) {
    GerMat4 r = gerMat4Identity();
    float c = cosf(radians), s = sinf(radians);
    r.m[1][1] = c;  r.m[1][2] = s;
    r.m[2][1] = -s; r.m[2][2] = c;
    return r;
}

GerMat4 gerMat4RotateY(float radians) {
    GerMat4 r = gerMat4Identity();
    float c = cosf(radians), s = sinf(radians);
    r.m[0][0] = c;  r.m[0][2] = -s;
    r.m[2][0] = s;  r.m[2][2] = c;
    return r;
}

GerMat4 gerMat4RotateZ(float radians) {
    GerMat4 r = gerMat4Identity();
    float c = cosf(radians), s = sinf(radians);
    r.m[0][0] = c;  r.m[0][1] = s;
    r.m[1][0] = -s; r.m[1][1] = c;
    return r;
}

GerMat4 gerMat4RotateXYZ(float rx, float ry, float rz) {
    GerMat4 mx = gerMat4RotateX(rx);
    GerMat4 my = gerMat4RotateY(ry);
    GerMat4 mz = gerMat4RotateZ(rz);
    GerMat4 t = gerMat4Multiply(mx, my);
    return gerMat4Multiply(t, mz);
}

GerMat4 gerMat4Perspective(float fovYRadians, float aspect, float zNear, float zFar) {
    GerMat4 r;
    memset(&r, 0, sizeof(r));
    float f = 1.0f / tanf(fovYRadians * 0.5f);
    r.m[0][0] = f / aspect;
    r.m[1][1] = f;
    r.m[2][2] = (zFar + zNear) / (zNear - zFar);
    r.m[2][3] = -1.0f;
    r.m[3][2] = (2.0f * zFar * zNear) / (zNear - zFar);
    return r;
}

GerMat4 gerMat4LookAt(GerVec3 eye, GerVec3 target, GerVec3 up) {
    GerVec3 f = gerVec3Normalize(gerVec3Sub(target, eye));
    GerVec3 s = gerVec3Normalize(gerVec3Cross(f, up));
    GerVec3 u = gerVec3Cross(s, f);

    GerMat4 r = gerMat4Identity();
    r.m[0][0] = s.x; r.m[1][0] = s.y; r.m[2][0] = s.z;
    r.m[0][1] = u.x; r.m[1][1] = u.y; r.m[2][1] = u.z;
    r.m[0][2] = -f.x; r.m[1][2] = -f.y; r.m[2][2] = -f.z;
    r.m[3][0] = -gerVec3Dot(s, eye);
    r.m[3][1] = -gerVec3Dot(u, eye);
    r.m[3][2] = gerVec3Dot(f, eye);
    return r;
}

GerVec4 gerMat4MulVec4(GerMat4 m, GerVec4 v) {
    GerVec4 r;
    r.x = v.x * m.m[0][0] + v.y * m.m[1][0] + v.z * m.m[2][0] + v.w * m.m[3][0];
    r.y = v.x * m.m[0][1] + v.y * m.m[1][1] + v.z * m.m[2][1] + v.w * m.m[3][1];
    r.z = v.x * m.m[0][2] + v.y * m.m[1][2] + v.z * m.m[2][2] + v.w * m.m[3][2];
    r.w = v.x * m.m[0][3] + v.y * m.m[1][3] + v.z * m.m[2][3] + v.w * m.m[3][3];
    return r;
}

/* ---------------------------------------------------------------------
 * Color
 * --------------------------------------------------------------------- */
typedef struct GerNamedColor {
    const char *name;
    uint8_t r, g, b, a;
} GerNamedColor;

static const GerNamedColor g_namedColors[] = {
    { "red",     255, 0,   0,   255 },
    { "green",   0,   255, 0,   255 },
    { "blue",    0,   0,   255, 255 },
    { "white",   255, 255, 255, 255 },
    { "black",   0,   0,   0,   255 },
    { "yellow",  255, 255, 0,   255 },
    { "cyan",    0,   255, 255, 255 },
    { "magenta", 255, 0,   255, 255 },
    { "orange",  255, 165, 0,   255 },
    { "purple",  128, 0,   128, 255 },
    { "gray",    128, 128, 128, 255 },
    { "grey",    128, 128, 128, 255 },
    { "pink",    255, 192, 203, 255 },
    { "brown",   139, 69,  19,  255 },
    { "lime",    50,  205, 50,  255 },
    { "navy",    0,   0,   128, 255 },
    { "gold",    255, 215, 0,   255 },
    { "silver",  192, 192, 192, 255 },
    { "transparent", 0, 0, 0, 0 }
};
#define GER_NAMED_COLOR_COUNT (sizeof(g_namedColors) / sizeof(g_namedColors[0]))

GerColor gerColorNamed(const char *name) {
    if (!name) return GER_COLOR_RGB(255, 255, 255);

    /* strip optional "n/" namespace prefix used by the GERECT script DSL */
    const char *p = name;
    if (p[0] == 'n' && p[1] == '/') p += 2;

    size_t i;
    for (i = 0; i < GER_NAMED_COLOR_COUNT; i++) {
        if (_stricmp(p, g_namedColors[i].name) == 0) {
            return GER_COLOR_RGBA(g_namedColors[i].r, g_namedColors[i].g,
                                   g_namedColors[i].b, g_namedColors[i].a);
        }
    }
    /* hex form: #RRGGBB or #RRGGBBAA */
    if (p[0] == '#') {
        unsigned int r = 255, g = 255, b = 255, a = 255;
        size_t len = strlen(p) - 1;
        if (len == 6) {
            sscanf(p + 1, "%02x%02x%02x", &r, &g, &b);
        } else if (len == 8) {
            sscanf(p + 1, "%02x%02x%02x%02x", &r, &g, &b, &a);
        }
        return GER_COLOR_RGBA(r, g, b, a);
    }
    return GER_COLOR_RGB(255, 255, 255);
}

GerColor gerColorLerp(GerColor a, GerColor b, float t) {
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;
    uint8_t ab = (uint8_t)(a & 0xFF),       ag = (uint8_t)((a >> 8) & 0xFF);
    uint8_t ar = (uint8_t)((a >> 16) & 0xFF), aa = (uint8_t)((a >> 24) & 0xFF);
    uint8_t bb = (uint8_t)(b & 0xFF),       bg = (uint8_t)((b >> 8) & 0xFF);
    uint8_t br = (uint8_t)((b >> 16) & 0xFF), ba = (uint8_t)((b >> 24) & 0xFF);

    uint8_t rb = (uint8_t)(ab + (bb - ab) * t);
    uint8_t rg = (uint8_t)(ag + (bg - ag) * t);
    uint8_t rr = (uint8_t)(ar + (br - ar) * t);
    uint8_t ra = (uint8_t)(aa + (ba - aa) * t);
    return GER_COLOR_RGBA(rr, rg, rb, ra);
}

/* ---------------------------------------------------------------------
 * Static memory pool
 * --------------------------------------------------------------------- */
GerResult gerMemPoolInit(GerMemPool *pool, size_t capacityBytes) {
    if (!pool) return GER_ERR_NULLPTR;
    if (capacityBytes == 0) return GER_ERR_INVALID_ARG;

    pool->base = (uint8_t *)VirtualAlloc(NULL, capacityBytes,
                                          MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!pool->base) return GER_ERR_OUT_OF_MEMORY;

    pool->capacity = capacityBytes;
    pool->used = 0;
    InitializeCriticalSection(&pool->lock);
    pool->initialized = 1;
    return GER_OK;
}

void *gerMemPoolAlloc(GerMemPool *pool, size_t size) {
    if (!pool || !pool->initialized) return NULL;
    void *ptr = NULL;

    EnterCriticalSection(&pool->lock);
    /* 16-byte alignment for SIMD-friendly access patterns */
    size_t alignedSize = (size + 15) & ~((size_t)15);
    if (pool->used + alignedSize <= pool->capacity) {
        ptr = pool->base + pool->used;
        pool->used += alignedSize;
    }
    LeaveCriticalSection(&pool->lock);

    return ptr;
}

void gerMemPoolReset(GerMemPool *pool) {
    if (!pool || !pool->initialized) return;
    EnterCriticalSection(&pool->lock);
    pool->used = 0;
    LeaveCriticalSection(&pool->lock);
}

void gerMemPoolDestroy(GerMemPool *pool) {
    if (!pool || !pool->initialized) return;
    if (pool->base) {
        VirtualFree(pool->base, 0, MEM_RELEASE);
        pool->base = NULL;
    }
    DeleteCriticalSection(&pool->lock);
    pool->capacity = 0;
    pool->used = 0;
    pool->initialized = 0;
}

/* ---------------------------------------------------------------------
 * Lifecycle / timing
 * --------------------------------------------------------------------- */
GerResult gerInit(void) {
    if (g_gerInitialized) return GER_OK;
    if (!QueryPerformanceFrequency(&g_perfFreq)) return GER_ERR_WIN32;
    QueryPerformanceCounter(&g_perfStart);
    g_gerInitialized = 1;
    return GER_OK;
}

void gerShutdown(void) {
    g_gerInitialized = 0;
}

double gerGetTimeSeconds(void) {
    LARGE_INTEGER now;
    QueryPerformanceCounter(&now);
    return (double)(now.QuadPart - g_perfStart.QuadPart) / (double)g_perfFreq.QuadPart;
}

void gerSleepMs(unsigned int ms) {
    Sleep(ms);
}
