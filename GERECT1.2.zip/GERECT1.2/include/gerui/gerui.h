/* =====================================================================
 * GERECT 1.2 - UI / Window / Script Header (gerui/gerui.h)
 *
 * Window: thin Win32 wrapper (HWND, message loop, DIB section blit of
 *         the GerFramebuffer to the screen -- GDI only, no GL/DX).
 *
 * Script (.ger DSL): a hand-written lexer + recursive-descent parser
 *         + tree-walking executor for the syntax described in the
 *         spec, e.g.:
 *
 *           gerDL3d
 *           layout[garis]
 *           pos[0.5.0][garis]
 *           size[0.10.0][garis]
 *           color[n/red][garis]
 *           rot[0.-10.0][garis]
 *           move[1.0.0][garis]
 *
 *         Statements execute top-to-bottom against a GerScene. The
 *         interpreter is a standalone text-driven layer that calls
 *         straight into the ger3d.h SSM API -- it owns no rendering
 *         logic itself.
 * =====================================================================
 */
#ifndef GERUI_H
#define GERUI_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ger/ger.h"
#include "gersys64/gersys64.h"
#include "ger3d/ger3d.h"

/* ----------------------------------------------------------------------
 * Window
 * ---------------------------------------------------------------------- */
typedef struct GerWindow {
    HWND     hwnd;
    HINSTANCE hInstance;
    HBITMAP  dibSection;
    HDC      memDC;
    void    *dibPixels;       /* points into the DIB section's bitmap bits */
    int      width;
    int      height;
    int      shouldClose;
    GerScene *boundScene;     /* scene whose framebuffer is blitted each WM_PAINT */
    LONG     resizeRequested; /* atomic flag set by WM_SIZE, consumed by main loop */
    int      pendingWidth;
    int      pendingHeight;
} GerWindow;

GER_API GerResult gerWindowCreate(GerWindow *win, HINSTANCE hInstance,
                                   const char *title, int width, int height);
GER_API void       gerWindowDestroy(GerWindow *win);
GER_API void       gerWindowBindScene(GerWindow *win, GerScene *scene);
GER_API int        gerWindowPollEvents(GerWindow *win); /* returns 0 when WM_QUIT received */
GER_API void       gerWindowPresent(GerWindow *win);    /* blits scene->framebuffer to the window */
GER_API int        gerWindowShouldClose(const GerWindow *win);
GER_API void       gerWindowApplyPendingResize(GerWindow *win); /* call once per frame from main loop */

/* ----------------------------------------------------------------------
 * .ger script interpreter
 * ---------------------------------------------------------------------- */
typedef enum GerTokenType {
    GER_TOK_EOF = 0,
    GER_TOK_IDENT,        /* gerDL3d, layout, pos, size, color, rot, move, etc. */
    GER_TOK_LBRACKET,     /* [ */
    GER_TOK_RBRACKET,     /* ] */
    GER_TOK_NUMBER,       /* 0.5, -10, 3 */
    GER_TOK_DOT,          /* . used as both decimal point and component separator */
    GER_TOK_STRING_LIKE,  /* bare word inside [] e.g. garis, n/red */
    GER_TOK_NEWLINE,
    GER_TOK_UNKNOWN
} GerTokenType;

typedef struct GerToken {
    GerTokenType type;
    char         text[GER_MAX_NAME_LEN];
    double       number;
} GerToken;

#define GER_SCRIPT_MAX_TOKENS 16384

typedef struct GerScriptLexer {
    GerToken tokens[GER_SCRIPT_MAX_TOKENS];
    int      tokenCount;
} GerScriptLexer;

typedef struct GerScriptInterp {
    GerScene       *scene;
    GerScriptLexer  lexer;
    int             cursor;
    int             errorCount;
    char            lastError[256];
} GerScriptInterp;

GER_API GerResult gerScriptLex(GerScriptLexer *lex, const char *source);
GER_API GerResult gerScriptRunSource(GerScene *scene, const char *source);
GER_API GerResult gerScriptRunFile(GerScene *scene, const char *path);

#ifdef __cplusplus
}
#endif

#endif /* GERUI_H */
