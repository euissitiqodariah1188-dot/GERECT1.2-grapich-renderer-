/* =====================================================================
 * GERECT 1.2 - Demo Game (C++)
 *
 * Mendemonstrasikan semua fitur engine via C++ wrapper:
 *   - ger::Engine, ger::Scene, ger::Window (RAII, no manual cleanup)
 *   - ger::Layout dengan method chaining (setPos->setColor->setMesh dll)
 *   - ger::Input keyboard + mouse (keyPressed, keyHeld, mousePos)
 *   - Collision: AABB player vs enemy, sphere pickup vs player
 *   - ger::Audio: musik looping + sfx via MCI
 *   - ger::GameLoop: fixed-timestep update, lambda onUpdate/onRender
 *   - ger::GameLoop script DSL dari inline string
 *
 * Kontrol:
 *   WASD        - gerakin player (kubus merah)
 *   Mouse drag  - putar camera (klik kiri tahan)
 *   R           - reset posisi player
 *   F           - toggle wireframe vs flat shading
 *   ESC         - keluar
 * =====================================================================
 */
#include <gercpp/gercpp.h>
#include <cstdio>
#include <cmath>

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int) {

    /* -----------------------------------------------------------------
     * Boot engine & create window + scene (RAII: auto-cleanup on exit)
     * ----------------------------------------------------------------- */
    ger::Engine engine; /* inits timing, first -- must outlive everything */
    ger::Window window(hInstance, "GERECT 1.2 - Demo Game [WASD=Move, ESC=Quit]", 1024, 768);
    ger::Scene  scene(1024, 768, 0 /* auto thread count */);
    window.bindScene(scene);

    scene.setCameraEye(0.0f, 3.0f, -7.0f);
    scene.setCameraTarget(0.0f, 0.0f, 0.0f);
    scene.setCameraFov(65.0f);

    /* -----------------------------------------------------------------
     * Build scene via C++ chaining API
     * ----------------------------------------------------------------- */

    /* Floor */
    GerTexture *checker = scene.createSolidTexture("floor_tex", 4, 4, "white");
    if (checker && checker->pixels) {
        checker->pixels[0] = gerColorNamed("gray");
        checker->pixels[3] = gerColorNamed("gray");
        checker->pixels[5] = gerColorNamed("gray");
        checker->pixels[6] = gerColorNamed("gray");
    }
    auto floor = scene.makeLayout("floor", "plane", "white", GER_SHADE_TEXTURED);
    floor.setSize(10.0f, 1.0f, 10.0f)
         ->setPos(0.0f, -1.0f, 0.0f)
         ->setTexture(checker);

    /* Player (kubus merah) */
    auto player = scene.makeLayout("player", "cube", "red", GER_SHADE_GOURAUD);
    player.setSize(0.6f, 0.6f, 0.6f)
          ->setPos(0.0f, -0.4f, 0.0f);

    /* Enemies (beberapa kubus biru, posisi acak tapi deterministic) */
    const int ENEMY_COUNT = 4;
    const char *enemyNames[ENEMY_COUNT] = {"enemy0","enemy1","enemy2","enemy3"};
    float enemyStartX[ENEMY_COUNT] = { 2.5f, -2.5f, 3.0f, -3.0f };
    float enemyStartZ[ENEMY_COUNT] = { 2.5f, -2.5f, -3.0f, 3.0f };

    for (int i = 0; i < ENEMY_COUNT; i++) {
        auto enemy = scene.makeLayout(enemyNames[i], "cube", "blue", GER_SHADE_GOURAUD);
        enemy.setSize(0.7f, 0.7f, 0.7f)
             ->setPos(enemyStartX[i], -0.4f, enemyStartZ[i]);
    }

    /* Collectible pickups (sphere kuning) */
    const int PICKUP_COUNT = 5;
    const char *pickupNames[PICKUP_COUNT] = {"pick0","pick1","pick2","pick3","pick4"};
    float pickupX[PICKUP_COUNT] = { 1.0f, -1.5f, 2.0f, 0.0f, -2.0f };
    float pickupZ[PICKUP_COUNT] = { 1.5f, 1.0f, -2.0f, -2.5f, -1.0f };
    bool  pickupAlive[PICKUP_COUNT] = { true, true, true, true, true };

    for (int i = 0; i < PICKUP_COUNT; i++) {
        auto pickup = scene.makeLayout(pickupNames[i], "sphere", "gold", GER_SHADE_GOURAUD);
        pickup.setSize(0.35f, 0.35f, 0.35f)
              ->setPos(pickupX[i], -0.55f, pickupZ[i]);
    }

    /* Dekorasi: piramid di sudut */
    scene.makeLayout("deco_a", "pyramid", "purple", GER_SHADE_FLAT)
         .setSize(0.8f, 1.2f, 0.8f)
         ->setPos(-4.0f, -0.4f, -4.0f);
    scene.makeLayout("deco_b", "pyramid", "orange", GER_SHADE_FLAT)
         .setSize(0.8f, 1.2f, 0.8f)
         ->setPos(4.0f, -0.4f, 4.0f);

    /* -----------------------------------------------------------------
     * Audio (opsional: skip gracefully jika file tidak ada)
     * ----------------------------------------------------------------- */
    ger::Audio audio;
    bool hasAudio = false;
    /* Ganti "bgm.wav" dengan path file WAV/MP3 yang nyata di project kamu */
    if (audio.load("bgm", "bgm.wav") == GER_OK) {
        audio.setVolume("bgm", 0.4f);
        audio.play("bgm", true /* loop */);
        hasAudio = true;
    }
    if (audio.load("sfx_collect", "collect.wav") != GER_OK) {
        /* tidak fatal, sfx dilewati kalau file tidak ada */
    }
    if (audio.load("sfx_hit", "hit.wav") != GER_OK) {
        /* sama */
    }
    (void)hasAudio;

    /* -----------------------------------------------------------------
     * Game state
     * ----------------------------------------------------------------- */
    float playerX = 0.0f, playerZ = 0.0f;
    float playerSpeed = 3.0f; /* unit per second */
    int   score = 0;
    int   lives = 3;
    bool  wireframe = false;
    float camYaw = 0.0f; /* kamera orbit horizontal pakai mouse drag */
    float camDist = 7.0f;
    float camHeight = 3.0f;
    bool  isDragging = false;

    char titleBuf[256];

    /* -----------------------------------------------------------------
     * Game loop pakai ger::GameLoop (fixed timestep 60 Hz)
     * ----------------------------------------------------------------- */
    ger::GameLoop loop(window, scene, 60.0);

    loop.onUpdate([&](double dt) {
        if (lives <= 0) return;

        ger::Input input = window.getInput();

        /* --- toggle wireframe --- */
        if (input.keyPressed(GER_KEY_F)) {
            wireframe = !wireframe;
            GerShadeMode newMode = wireframe ? GER_SHADE_WIREFRAME : GER_SHADE_GOURAUD;
            for (int i = 0; i < ENEMY_COUNT; i++) {
                ger::Layout l = scene.findLayout(enemyNames[i]);
                l.setShadeMode(newMode);
            }
            ger::Layout pl = scene.findLayout("player");
            pl.setShadeMode(newMode);
        }

        /* --- reset player --- */
        if (input.keyPressed(GER_KEY_R)) {
            playerX = 0.0f;
            playerZ = 0.0f;
        }

        /* --- player movement (camera-relative WASD) --- */
        float camSin = sinf(camYaw);
        float camCos = cosf(camYaw);
        float moveX = 0.0f, moveZ = 0.0f;

        if (input.keyHeld(GER_KEY_W)) { moveX += camSin; moveZ += camCos; }
        if (input.keyHeld(GER_KEY_S)) { moveX -= camSin; moveZ -= camCos; }
        if (input.keyHeld(GER_KEY_A)) { moveX -= camCos; moveZ += camSin; }
        if (input.keyHeld(GER_KEY_D)) { moveX += camCos; moveZ -= camSin; }

        float moveLen = sqrtf(moveX * moveX + moveZ * moveZ);
        if (moveLen > 0.001f) {
            float invLen = 1.0f / moveLen;
            playerX += moveX * invLen * playerSpeed * (float)dt;
            playerZ += moveZ * invLen * playerSpeed * (float)dt;
        }

        /* Clamp player in bounds */
        if (playerX > 4.5f) playerX = 4.5f;
        if (playerX < -4.5f) playerX = -4.5f;
        if (playerZ > 4.5f) playerZ = 4.5f;
        if (playerZ < -4.5f) playerZ = -4.5f;

        /* Update player layout */
        ger::Layout pl = scene.findLayout("player");
        pl.setPos(playerX, -0.4f, playerZ);
        if (moveLen > 0.001f) {
            float angle = atan2f(moveX, moveZ);
            pl.setRotation(0.0f, (float)(angle * 180.0f / (float)GER_PI), 0.0f);
        }

        /* --- mouse camera orbit --- */
        if (input.mousePressed(GER_MOUSE_RIGHT)) isDragging = true;
        if (input.mouseReleased(GER_MOUSE_RIGHT)) isDragging = false;
        if (isDragging) {
            GerVec2 delta = input.mouseDelta();
            camYaw += delta.x * 0.005f;
        }
        int wheel = input.mouseWheel();
        if (wheel != 0) {
            camDist -= (float)wheel * 0.5f;
            if (camDist < 2.0f) camDist = 2.0f;
            if (camDist > 15.0f) camDist = 15.0f;
        }

        /* Update camera orbit around player */
        float eyeX = playerX + sinf(camYaw) * camDist;
        float eyeZ = playerZ + cosf(camYaw) * (-camDist);
        scene.setCameraEye(eyeX, camHeight, eyeZ);
        scene.setCameraTarget(playerX, 0.0f, playerZ);

        /* --- enemy spin & patrol --- */
        double t = gerGetTimeSeconds();
        for (int i = 0; i < ENEMY_COUNT; i++) {
            ger::Layout enemy = scene.findLayout(enemyNames[i]);
            if (!enemy.isActive()) continue;
            float phase = (float)i * 1.57f;
            float px = enemyStartX[i] + sinf((float)t * 0.8f + phase) * 1.2f;
            float pz = enemyStartZ[i] + cosf((float)t * 0.6f + phase) * 1.2f;
            enemy.setPos(px, -0.4f, pz)
                 ->setRotation(0.0f, (float)(t * 60.0 + i * 90.0), 0.0f);
        }

        /* --- pickup bop --- */
        for (int i = 0; i < PICKUP_COUNT; i++) {
            if (!pickupAlive[i]) continue;
            ger::Layout pickup = scene.findLayout(pickupNames[i]);
            float bobY = -0.55f + sinf((float)t * 2.0f + (float)i) * 0.15f;
            pickup.setPos(pickupX[i], bobY, pickupZ[i])
                  ->setRotation((float)(t * 40.0), (float)(t * 60.0), 0.0f);
        }

        /* --- collision: player vs pickups --- */
        ger::Layout playerLay = scene.findLayout("player");
        GerSphere playerSphere = playerLay.getWorldSphere();

        for (int i = 0; i < PICKUP_COUNT; i++) {
            if (!pickupAlive[i]) continue;
            ger::Layout pickup = scene.findLayout(pickupNames[i]);
            GerSphere pickupSphere = pickup.getWorldSphere();
            if (ger::collideSphere(playerSphere, pickupSphere)) {
                pickup.hide();
                pickupAlive[i] = false;
                score += 10;
                audio.play("sfx_collect", false);
            }
        }

        /* --- collision: player vs enemies --- */
        GerAABB playerAABB = playerLay.getWorldAABB();
        static double lastHitTime = -999.0;
        for (int i = 0; i < ENEMY_COUNT; i++) {
            ger::Layout enemy = scene.findLayout(enemyNames[i]);
            if (!enemy.isActive()) continue;
            GerAABB enemyAABB = enemy.getWorldAABB();
            if (ger::collideAABB(playerAABB, enemyAABB)) {
                double now = gerGetTimeSeconds();
                if (now - lastHitTime > 1.0) {
                    lives--;
                    lastHitTime = now;
                    audio.play("sfx_hit", false);
                    /* knock player back */
                    playerX -= (playerX - enemy.getPos().x) * 0.5f;
                    playerZ -= (playerZ - enemy.getPos().z) * 0.5f;
                }
            }
        }

        /* Update window title with live HUD info */
        snprintf(titleBuf, sizeof(titleBuf),
                 "GERECT 1.2 | Score: %d | Lives: %d | FPS: %.0f | Cores: %d",
                 score, lives, scene.getFps(),
                 gerPmtgGetThreadCount(scene.get()->threadPool));
        SetWindowTextA(window.get()->hwnd, titleBuf);
    });

    loop.run();

    return 0;
}
