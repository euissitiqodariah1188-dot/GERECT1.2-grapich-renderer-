/* =====================================================================
 * GERECT 1.2 - PMTG Thread Pool + FRM Frame Timer Implementation
 * =====================================================================
 *
 * Design notes (anti-leak / anti-realloc-per-frame):
 *  - Worker threads are spawned exactly once in gerPmtgCreate() and
 *    parked in a wait state on a CONDITION_VARIABLE.
 *  - Each frame, the main thread sets up the job descriptor (rows or
 *    job array pointer + count) in already-allocated struct fields,
 *    bumps a generation counter, and wakes the workers.
 *  - Workers pull from a shared atomic counter (work-stealing) so load
 *    imbalance across rows/jobs is automatically smoothed.
 *  - gerPmtgDestroy() signals shutdown, wakes all threads, joins them,
 *    and frees the single block backing the GerThreadPool struct (and
 *    its thread handle array) that was allocated in Create().
 */
#include "gersys64/gersys64.h"

struct GerThreadPool {
    int threadCount;
    HANDLE threads[GER_MAX_CORES];

    CRITICAL_SECTION   mutex;
    CONDITION_VARIABLE  cvWork;
    CONDITION_VARIABLE  cvDone;

    volatile LONG generation;     /* bumped each dispatch to wake workers */
    volatile LONG shuttingDown;
    volatile LONG activeWorkers;  /* workers still processing this generation */

    /* current job descriptor (valid only during a dispatch) */
    GerJobFn jobFn;
    void    *userData;
    int      totalRows;          /* row-mode */
    volatile LONG nextRow;        /* work-stealing cursor for row-mode */
    int      rowsPerChunk;

    int      jobCount;           /* job-array mode */
    volatile LONG nextJob;

    int      mode; /* 0 = idle, 1 = row dispatch, 2 = job dispatch */
};

typedef struct GerWorkerArgs {
    GerThreadPool *pool;
    int threadIndex;
} GerWorkerArgs;

/* one static array of worker-arg structs per pool capacity; avoids
 * heap allocation per thread and keeps lifetime tied 1:1 to the pool */
static GerWorkerArgs g_workerArgsStorage[GER_MAX_CORES];

static DWORD WINAPI GerPmtgWorkerProc(LPVOID param) {
    GerWorkerArgs *args = (GerWorkerArgs *)param;
    GerThreadPool *pool = args->pool;
    int threadIndex = args->threadIndex;
    LONG lastSeenGeneration = 0;

    for (;;) {
        EnterCriticalSection(&pool->mutex);
        while (pool->generation == lastSeenGeneration && !pool->shuttingDown) {
            SleepConditionVariableCS(&pool->cvWork, &pool->mutex, INFINITE);
        }
        if (pool->shuttingDown) {
            LeaveCriticalSection(&pool->mutex);
            return 0;
        }
        lastSeenGeneration = pool->generation;
        int mode = pool->mode;
        LeaveCriticalSection(&pool->mutex);

        if (mode == 1) {
            /* row-mode: pull row chunks until exhausted */
            for (;;) {
                LONG row = gerAtomicIncrement(&pool->nextRow) - 1;
                int y0 = row * pool->rowsPerChunk;
                if (y0 >= pool->totalRows) break;
                int y1 = y0 + pool->rowsPerChunk;
                if (y1 > pool->totalRows) y1 = pool->totalRows;
                pool->jobFn(threadIndex, y0, y1, pool->userData);
            }
        } else if (mode == 2) {
            for (;;) {
                LONG idx = gerAtomicIncrement(&pool->nextJob) - 1;
                if (idx >= pool->jobCount) break;
                pool->jobFn(threadIndex, (int)idx, (int)idx + 1, pool->userData);
            }
        }

        EnterCriticalSection(&pool->mutex);
        LONG remaining = --pool->activeWorkers;
        if (remaining == 0) {
            WakeAllConditionVariable(&pool->cvDone);
        }
        LeaveCriticalSection(&pool->mutex);
    }
}

int gerSysGetLogicalCoreCount(void) {
    SYSTEM_INFO info;
    GetSystemInfo(&info);
    int n = (int)info.dwNumberOfProcessors;
    if (n < 1) n = 1;
    if (n > GER_MAX_CORES) n = GER_MAX_CORES;
    return n;
}

GerThreadPool *gerPmtgCreate(int requestedThreadCount) {
    int count = requestedThreadCount;
    if (count <= 0) count = gerSysGetLogicalCoreCount();
    if (count > GER_MAX_CORES) count = GER_MAX_CORES;
    if (count < 1) count = 1;

    /* single allocation for the pool struct itself; freed exactly once
     * in gerPmtgDestroy(). No further heap activity occurs per frame. */
    GerThreadPool *pool = (GerThreadPool *)malloc(sizeof(GerThreadPool));
    if (!pool) return NULL;
    memset(pool, 0, sizeof(GerThreadPool));

    pool->threadCount = count;
    InitializeCriticalSection(&pool->mutex);
    InitializeConditionVariable(&pool->cvWork);
    InitializeConditionVariable(&pool->cvDone);
    pool->generation = 0;
    pool->shuttingDown = 0;
    pool->mode = 0;

    int i;
    for (i = 0; i < count; i++) {
        g_workerArgsStorage[i].pool = pool;
        g_workerArgsStorage[i].threadIndex = i;
        pool->threads[i] = CreateThread(NULL, 0, GerPmtgWorkerProc,
                                         &g_workerArgsStorage[i], 0, NULL);
        if (!pool->threads[i]) {
            /* cleanup partially created pool on failure */
            pool->shuttingDown = 1;
            WakeAllConditionVariable(&pool->cvWork);
            int j;
            for (j = 0; j < i; j++) {
                WaitForSingleObject(pool->threads[j], INFINITE);
                CloseHandle(pool->threads[j]);
            }
            DeleteCriticalSection(&pool->mutex);
            free(pool);
            return NULL;
        }
    }

    return pool;
}

void gerPmtgDestroy(GerThreadPool *pool) {
    if (!pool) return;

    EnterCriticalSection(&pool->mutex);
    pool->shuttingDown = 1;
    pool->generation++;
    LeaveCriticalSection(&pool->mutex);
    WakeAllConditionVariable(&pool->cvWork);

    int i;
    for (i = 0; i < pool->threadCount; i++) {
        if (pool->threads[i]) {
            WaitForSingleObject(pool->threads[i], INFINITE);
            CloseHandle(pool->threads[i]);
            pool->threads[i] = NULL;
        }
    }

    DeleteCriticalSection(&pool->mutex);
    free(pool);
}

int gerPmtgGetThreadCount(const GerThreadPool *pool) {
    if (!pool) return 0;
    return pool->threadCount;
}

GerResult gerPmtgDispatchRows(GerThreadPool *pool, int totalRows,
                               GerJobFn jobFn, void *userData) {
    if (!pool || !jobFn || totalRows <= 0) return GER_ERR_INVALID_ARG;

    /* chunk size chosen so each of N threads gets several chunks
     * (load balancing) rather than exactly one big stripe each */
    int chunksPerThread = 4;
    int rowsPerChunk = totalRows / (pool->threadCount * chunksPerThread);
    if (rowsPerChunk < 1) rowsPerChunk = 1;

    EnterCriticalSection(&pool->mutex);
    pool->jobFn = jobFn;
    pool->userData = userData;
    pool->totalRows = totalRows;
    pool->rowsPerChunk = rowsPerChunk;
    pool->nextRow = 0;
    pool->mode = 1;
    pool->activeWorkers = pool->threadCount;
    pool->generation++;
    LeaveCriticalSection(&pool->mutex);

    WakeAllConditionVariable(&pool->cvWork);

    EnterCriticalSection(&pool->mutex);
    while (pool->activeWorkers != 0) {
        SleepConditionVariableCS(&pool->cvDone, &pool->mutex, INFINITE);
    }
    pool->mode = 0;
    LeaveCriticalSection(&pool->mutex);

    return GER_OK;
}

GerResult gerPmtgDispatchJobs(GerThreadPool *pool, int jobCount,
                               GerJobFn jobFn, void *userData) {
    if (!pool || !jobFn || jobCount <= 0) return GER_ERR_INVALID_ARG;

    EnterCriticalSection(&pool->mutex);
    pool->jobFn = jobFn;
    pool->userData = userData;
    pool->jobCount = jobCount;
    pool->nextJob = 0;
    pool->mode = 2;
    pool->activeWorkers = pool->threadCount;
    pool->generation++;
    LeaveCriticalSection(&pool->mutex);

    WakeAllConditionVariable(&pool->cvWork);

    EnterCriticalSection(&pool->mutex);
    while (pool->activeWorkers != 0) {
        SleepConditionVariableCS(&pool->cvDone, &pool->mutex, INFINITE);
    }
    pool->mode = 0;
    LeaveCriticalSection(&pool->mutex);

    return GER_OK;
}

LONG gerAtomicIncrement(volatile LONG *value) {
    return InterlockedIncrement(value);
}

LONG gerAtomicCompareExchange(volatile LONG *dest, LONG exchange, LONG comparand) {
    return InterlockedCompareExchange(dest, exchange, comparand);
}

/* ---------------------------------------------------------------------
 * FRM: frame timer
 * --------------------------------------------------------------------- */
void gerFrmInit(GerFrameTimer *timer) {
    if (!timer) return;
    memset(timer, 0, sizeof(GerFrameTimer));
    timer->lastTime = gerGetTimeSeconds();
    timer->fps = 0.0;
}

void gerFrmBeginFrame(GerFrameTimer *timer) {
    if (!timer) return;
    double now = gerGetTimeSeconds();
    timer->deltaTime = now - timer->lastTime;
    if (timer->deltaTime < 0.0) timer->deltaTime = 0.0;
    if (timer->deltaTime > 0.25) timer->deltaTime = 0.25; /* clamp hitches */
    timer->lastTime = now;
}

void gerFrmEndFrame(GerFrameTimer *timer) {
    if (!timer) return;
    timer->accumTime += timer->deltaTime;
    timer->accumFrames++;
    timer->frameIndex++;

    if (timer->accumTime >= 0.5) {
        timer->fps = (double)timer->accumFrames / timer->accumTime;
        timer->accumTime = 0.0;
        timer->accumFrames = 0;
    }
}

double gerFrmGetFps(const GerFrameTimer *timer) {
    return timer ? timer->fps : 0.0;
}

double gerFrmGetDeltaTime(const GerFrameTimer *timer) {
    return timer ? timer->deltaTime : 0.0;
}

uint64_t gerFrmGetFrameIndex(const GerFrameTimer *timer) {
    return timer ? timer->frameIndex : 0;
}
