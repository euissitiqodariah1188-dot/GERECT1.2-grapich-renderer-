/* =====================================================================
 * GERECT 1.2 - .ger Script Lexer
 *
 * Tokenizes source text into idents, brackets, numbers, dotted
 * component separators, and bare "string-like" words (used for layout
 * names and color tokens such as "n/red"). Designed to handle exactly
 * the surface syntax from the spec:
 *
 *   gerDL3d
 *   layout[garis]
 *   pos[0.5.0][garis]
 *   size[0.10.0][garis]
 *   color[n/red][garis]
 *   rot[0.-10.0][garis]
 *
 * Numbers inside [...] are dot-separated triplets (x.y.z) rather than
 * standard decimals, so the lexer treats '.' as its own token and the
 * parser groups NUMBER DOT NUMBER DOT NUMBER sequences itself. This
 * also transparently supports real decimal numbers like "0.5" being
 * read as two integer tokens (0 and 5) separated by a dot when used
 * as a single component -- the parser's numeric-list reader handles
 * both the "x.y.z" triplet form and decimal fractions by re-merging
 * adjacent NUMBER DOT NUMBER pairs that are not separated by a comma
 * boundary, exactly as the example syntax requires (see ger3d_script_parser.c).
 * =====================================================================
 */
#include "gerui/gerui.h"

static void GerLexerPush(GerScriptLexer *lex, GerTokenType type, const char *text, double number) {
    if (lex->tokenCount >= GER_SCRIPT_MAX_TOKENS) return;
    GerToken *tok = &lex->tokens[lex->tokenCount++];
    tok->type = type;
    tok->number = number;
    if (text) {
        size_t n = strlen(text);
        if (n > GER_MAX_NAME_LEN - 1) n = GER_MAX_NAME_LEN - 1;
        memcpy(tok->text, text, n);
        tok->text[n] = '\0';
    } else {
        tok->text[0] = '\0';
    }
}

static int GerIsIdentStart(char c) {
    return isalpha((unsigned char)c) || c == '_';
}

static int GerIsIdentChar(char c) {
    return isalnum((unsigned char)c) || c == '_' || c == '/';
}

GerResult gerScriptLex(GerScriptLexer *lex, const char *source) {
    if (!lex || !source) return GER_ERR_NULLPTR;
    lex->tokenCount = 0;

    const char *p = source;
    while (*p) {
        char c = *p;

        if (c == '\n') {
            GerLexerPush(lex, GER_TOK_NEWLINE, NULL, 0.0);
            p++;
            continue;
        }
        if (c == ' ' || c == '\t' || c == '\r') {
            p++;
            continue;
        }
        /* line comment support: // ... */
        if (c == '/' && p[1] == '/') {
            while (*p && *p != '\n') p++;
            continue;
        }
        if (c == '[') {
            GerLexerPush(lex, GER_TOK_LBRACKET, NULL, 0.0);
            p++;
            continue;
        }
        if (c == ']') {
            GerLexerPush(lex, GER_TOK_RBRACKET, NULL, 0.0);
            p++;
            continue;
        }
        if (c == '.') {
            GerLexerPush(lex, GER_TOK_DOT, NULL, 0.0);
            p++;
            continue;
        }
        if (c == '-' && isdigit((unsigned char)p[1])) {
            /* negative number */
            const char *start = p;
            p++;
            while (isdigit((unsigned char)*p)) p++;
            char buf[64];
            size_t len = (size_t)(p - start);
            if (len >= sizeof(buf)) len = sizeof(buf) - 1;
            memcpy(buf, start, len);
            buf[len] = '\0';
            GerLexerPush(lex, GER_TOK_NUMBER, buf, atof(buf));
            continue;
        }
        if (isdigit((unsigned char)c)) {
            const char *start = p;
            while (isdigit((unsigned char)*p)) p++;
            char buf[64];
            size_t len = (size_t)(p - start);
            if (len >= sizeof(buf)) len = sizeof(buf) - 1;
            memcpy(buf, start, len);
            buf[len] = '\0';
            GerLexerPush(lex, GER_TOK_NUMBER, buf, atof(buf));
            continue;
        }
        if (GerIsIdentStart(c) || c == '#') {
            const char *start = p;
            /* allow leading # for hex colors like #FF0000 inside [] */
            if (c == '#') p++;
            while (GerIsIdentChar(*p) || (p != start && isxdigit((unsigned char)*p) && *(start) == '#')) {
                p++;
            }
            char buf[GER_MAX_NAME_LEN];
            size_t len = (size_t)(p - start);
            if (len >= sizeof(buf)) len = sizeof(buf) - 1;
            memcpy(buf, start, len);
            buf[len] = '\0';

            /* could be either a keyword/ident (pos, layout, gerDL3d...)
             * or a bare value word (garis, red, n/red) -- the parser
             * disambiguates by context, so we just tag it IDENT and
             * let the parser treat unknown idents inside [] as values. */
            GerLexerPush(lex, GER_TOK_IDENT, buf, 0.0);
            continue;
        }

        /* unknown character: skip it but record as UNKNOWN for
         * diagnostics rather than silently corrupting the stream */
        char buf[2] = { c, '\0' };
        GerLexerPush(lex, GER_TOK_UNKNOWN, buf, 0.0);
        p++;
    }

    GerLexerPush(lex, GER_TOK_EOF, NULL, 0.0);
    return GER_OK;
}
