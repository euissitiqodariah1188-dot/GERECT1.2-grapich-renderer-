/* =====================================================================
 * GERECT 1.2 - Collision Implementation
 * =====================================================================
 */
#include "ger3d/gercollision.h"

GerAABB gerMeshComputeLocalAABB(const GerMesh *mesh) {
    GerAABB box;
    box.min = gerVec3Make(0.0f, 0.0f, 0.0f);
    box.max = gerVec3Make(0.0f, 0.0f, 0.0f);

    if (!mesh || !mesh->vertices || mesh->vertexCount == 0) return box;

    box.min = mesh->vertices[0].position;
    box.max = mesh->vertices[0].position;

    int i;
    for (i = 1; i < mesh->vertexCount; i++) {
        GerVec3 p = mesh->vertices[i].position;
        if (p.x < box.min.x) box.min.x = p.x;
        if (p.y < box.min.y) box.min.y = p.y;
        if (p.z < box.min.z) box.min.z = p.z;
        if (p.x > box.max.x) box.max.x = p.x;
        if (p.y > box.max.y) box.max.y = p.y;
        if (p.z > box.max.z) box.max.z = p.z;
    }
    return box;
}

GerAABB gerLayoutGetWorldAABB(const GerLayout *layout, GerAABB localAABB) {
    GerAABB world;
    if (!layout) { world.min = world.max = gerVec3Make(0,0,0); return world; }

    GerVec3 scaledMin = gerVec3Make(
        localAABB.min.x * layout->scale.x,
        localAABB.min.y * layout->scale.y,
        localAABB.min.z * layout->scale.z
    );
    GerVec3 scaledMax = gerVec3Make(
        localAABB.max.x * layout->scale.x,
        localAABB.max.y * layout->scale.y,
        localAABB.max.z * layout->scale.z
    );

    /* scale can flip min/max if negative; re-sort per axis defensively */
    float minX = scaledMin.x < scaledMax.x ? scaledMin.x : scaledMax.x;
    float maxX = scaledMin.x < scaledMax.x ? scaledMax.x : scaledMin.x;
    float minY = scaledMin.y < scaledMax.y ? scaledMin.y : scaledMax.y;
    float maxY = scaledMin.y < scaledMax.y ? scaledMax.y : scaledMin.y;
    float minZ = scaledMin.z < scaledMax.z ? scaledMin.z : scaledMax.z;
    float maxZ = scaledMin.z < scaledMax.z ? scaledMax.z : scaledMin.z;

    world.min = gerVec3Add(layout->position, gerVec3Make(minX, minY, minZ));
    world.max = gerVec3Add(layout->position, gerVec3Make(maxX, maxY, maxZ));
    return world;
}

GerSphere gerLayoutGetWorldSphere(const GerLayout *layout, GerAABB localAABB) {
    GerSphere sphere;
    sphere.center = layout ? layout->position : gerVec3Make(0,0,0);
    sphere.radius = 0.0f;
    if (!layout) return sphere;

    GerVec3 extent = gerVec3Sub(localAABB.max, localAABB.min);
    float localRadius = gerVec3Length(gerVec3Scale(extent, 0.5f));

    float maxScale = layout->scale.x;
    if (layout->scale.y > maxScale) maxScale = layout->scale.y;
    if (layout->scale.z > maxScale) maxScale = layout->scale.z;
    if (maxScale < 0.0f) maxScale = -maxScale;

    sphere.radius = localRadius * maxScale;
    return sphere;
}

int gerCollideAABBvsAABB(GerAABB a, GerAABB b) {
    if (a.max.x < b.min.x || a.min.x > b.max.x) return 0;
    if (a.max.y < b.min.y || a.min.y > b.max.y) return 0;
    if (a.max.z < b.min.z || a.min.z > b.max.z) return 0;
    return 1;
}

int gerCollideSphereVsSphere(GerSphere a, GerSphere b) {
    float distSq = gerVec3Dot(gerVec3Sub(a.center, b.center), gerVec3Sub(a.center, b.center));
    float radiusSum = a.radius + b.radius;
    return distSq <= (radiusSum * radiusSum);
}

int gerCollideAABBvsSphere(GerAABB box, GerSphere sphere) {
    float closestX = sphere.center.x;
    if (closestX < box.min.x) closestX = box.min.x;
    if (closestX > box.max.x) closestX = box.max.x;

    float closestY = sphere.center.y;
    if (closestY < box.min.y) closestY = box.min.y;
    if (closestY > box.max.y) closestY = box.max.y;

    float closestZ = sphere.center.z;
    if (closestZ < box.min.z) closestZ = box.min.z;
    if (closestZ > box.max.z) closestZ = box.max.z;

    GerVec3 closest = gerVec3Make(closestX, closestY, closestZ);
    GerVec3 diff = gerVec3Sub(sphere.center, closest);
    float distSq = gerVec3Dot(diff, diff);
    return distSq <= (sphere.radius * sphere.radius);
}

int gerCollidePointInAABB(GerVec3 point, GerAABB box) {
    return point.x >= box.min.x && point.x <= box.max.x &&
           point.y >= box.min.y && point.y <= box.max.y &&
           point.z >= box.min.z && point.z <= box.max.z;
}

int gerCollidePointInSphere(GerVec3 point, GerSphere sphere) {
    GerVec3 diff = gerVec3Sub(point, sphere.center);
    float distSq = gerVec3Dot(diff, diff);
    return distSq <= (sphere.radius * sphere.radius);
}

int gerCollideRayVsAABB(GerVec3 origin, GerVec3 dir, GerAABB box, float *outDistance) {
    float tMin = -1e30f, tMax = 1e30f;

    /* X slab */
    if (fabsf(dir.x) < 1e-8f) {
        if (origin.x < box.min.x || origin.x > box.max.x) return 0;
    } else {
        float t1 = (box.min.x - origin.x) / dir.x;
        float t2 = (box.max.x - origin.x) / dir.x;
        if (t1 > t2) { float tmp = t1; t1 = t2; t2 = tmp; }
        if (t1 > tMin) tMin = t1;
        if (t2 < tMax) tMax = t2;
        if (tMin > tMax) return 0;
    }

    /* Y slab */
    if (fabsf(dir.y) < 1e-8f) {
        if (origin.y < box.min.y || origin.y > box.max.y) return 0;
    } else {
        float t1 = (box.min.y - origin.y) / dir.y;
        float t2 = (box.max.y - origin.y) / dir.y;
        if (t1 > t2) { float tmp = t1; t1 = t2; t2 = tmp; }
        if (t1 > tMin) tMin = t1;
        if (t2 < tMax) tMax = t2;
        if (tMin > tMax) return 0;
    }

    /* Z slab */
    if (fabsf(dir.z) < 1e-8f) {
        if (origin.z < box.min.z || origin.z > box.max.z) return 0;
    } else {
        float t1 = (box.min.z - origin.z) / dir.z;
        float t2 = (box.max.z - origin.z) / dir.z;
        if (t1 > t2) { float tmp = t1; t1 = t2; t2 = tmp; }
        if (t1 > tMin) tMin = t1;
        if (t2 < tMax) tMax = t2;
        if (tMin > tMax) return 0;
    }

    if (tMax < 0.0f) return 0; /* box is behind the ray origin */

    if (outDistance) *outDistance = (tMin >= 0.0f) ? tMin : tMax;
    return 1;
}

int gerCollideRayVsSphere(GerVec3 origin, GerVec3 dir, GerSphere sphere, float *outDistance) {
    GerVec3 m = gerVec3Sub(origin, sphere.center);
    float b = gerVec3Dot(m, dir);
    float c = gerVec3Dot(m, m) - sphere.radius * sphere.radius;

    if (c > 0.0f && b > 0.0f) return 0; /* ray starts outside and points away */

    float dirLenSq = gerVec3Dot(dir, dir);
    if (dirLenSq < 1e-12f) return 0;

    float discr = b * b - dirLenSq * c;
    if (discr < 0.0f) return 0;

    float t = (-b - sqrtf(discr)) / dirLenSq;
    if (t < 0.0f) t = 0.0f;

    if (outDistance) *outDistance = t;
    return 1;
}
